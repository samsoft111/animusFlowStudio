/* AeroSpace Theme Interactions & GPU Optimized FX */
document.addEventListener('DOMContentLoaded', () => {
  console.log('AeroSpace theme loaded.');
  
  // ── Preloader Consola Terminal Script ──
  const logContainer = document.getElementById('preloader-terminal-log');
  const preloader = document.getElementById('aerospace-preloader');
  if (preloader && sessionStorage.getItem('aerospace_booted')) {
    // Boot console ja correu nesta sessao — remove instantaneamente (sem ecra preto nas navegacoes internas)
    preloader.remove();
  } else if (logContainer && preloader) {
    // Marca como arrancado logo no inicio para navegacoes seguintes saltarem o boot
    sessionStorage.setItem('aerospace_booted', '1');
    const logs = [
      'AEROSPACE COCKPIT SYSTEM INITIALIZATION...',
      'ESTABLISHING ENCRYPTED SAT-LINK [GEO-ORBIT-04]... OK',
      'AVIONICS INTEGRITY SURVEY... OK',
      'AUTONOMOUS FLIGHT ALGORITHM LOCK... OK',
      'LIDAR COLLISION GRID SCAN... OK',
      'GPS SIGNAL LOCK: COORDINATES RESOLVED.',
      'BOOT COMPLETE. ENTERING OPERATIONAL RADAR INTERFACE.'
    ];
    let i = 0;
    function addLine() {
      if (i < logs.length) {
        const div = document.createElement('div');
        div.className = 'terminal-line';
        div.textContent = `> ${logs[i]}`;
        logContainer.appendChild(div);
        logContainer.scrollTop = logContainer.scrollHeight;
        i++;
        setTimeout(addLine, 100 + Math.random() * 100);
      } else {
        setTimeout(() => {
          preloader.style.opacity = '0';
          setTimeout(() => preloader.remove(), 800);
        }, 400);
      }
    }
    addLine();
  }

  // ── Screensaver Toggle on Hover/Touch ──
  const heroEl = document.querySelector('.aerospace-hero');
  if (heroEl) {
    // Desktop: o CSS faz o screensaver recuar ao passar o cursor (hover) OU ao focar com teclado (:focus-within), e REGRESSAR ao sair.
    // Tactil (sem hover): primeiro toque revela, ja que nao existe hover nem foco.
    const revealHero = () => heroEl.classList.add('hero-revealed');
    if (!heroEl.classList.contains('hero-internal') && window.matchMedia('(hover: none)').matches) {
      ['pointerdown','touchstart'].forEach(ev => window.addEventListener(ev, revealHero, { once: true, passive: true }));
    }
  }

  // ── Background Slide Rotation (Gallery mode) ──
  const slides = document.querySelectorAll('.screensaver-gallery .slide-item');
  if (slides.length > 1) {
    let currentSlide = 0;
    setInterval(() => {
      slides[currentSlide].classList.remove('active-slide');
      currentSlide = (currentSlide + 1) % slides.length;
      slides[currentSlide].classList.add('active-slide');
    }, 5000);
  }

  // ── Grelha 3D Interativa com Perspetiva (Laser Mesh via Canvas) ──
  const canvas = document.getElementById('mesh-grid-3d-canvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let width = canvas.width = canvas.offsetWidth;
    let height = canvas.height = canvas.offsetHeight;
    
    window.addEventListener('resize', () => {
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    });

    let mouse = { x: width / 2, y: height / 2, tx: width / 2, ty: height / 2, speed: 0 };
    let lastMouse = { x: width / 2, y: height / 2 };
    
    document.addEventListener('mousemove', (e) => {
      const rect = canvas.getBoundingClientRect();
      mouse.tx = e.clientX - rect.left;
      mouse.ty = e.clientY - rect.top;
    });

    let time = 0;
    function drawGrid3D() {
      ctx.clearRect(0, 0, width, height);
      
      // Suavização do movimento do rato
      mouse.x += (mouse.tx - mouse.x) * 0.08;
      mouse.y += (mouse.ty - mouse.y) * 0.08;
      
      // Cálculo da velocidade do rato
      const dx = mouse.x - lastMouse.x;
      const dy = mouse.y - lastMouse.y;
      const speed = Math.sqrt(dx * dx + dy * dy);
      mouse.speed += (speed - mouse.speed) * 0.05;
      lastMouse.x = mouse.x;
      lastMouse.y = mouse.y;

      time += 0.015 + (mouse.speed * 0.001);
      
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.15)'; // Cor ciano com opacidade
      ctx.lineWidth = 1;
      
      const cols = 24;
      const rows = 16;
      const points = [];
      
      // Criar malha de pontos
      for (let r = 0; r <= rows; r++) {
        points[r] = [];
        for (let c = 0; c <= cols; c++) {
          const nx = c / cols;
          const ny = r / rows;
          
          // Ponto de fuga no centro-superior
          const cx = width / 2;
          const cy = height * 0.25;
          
          // Coordenadas base
          const bx = width * nx;
          const by = height * ny;
          
          // Distância ao ponto de fuga
          const rx = bx - cx;
          const ry = by - cy;
          
          // Escala de perspetiva com base em Y (profundidade)
          const depth = 0.15 + (ny * 0.85);
          const px = cx + rx * depth;
          const py = cy + ry * depth;
          
          // Distorção por onda e proximidade do rato
          const distToMouse = Math.sqrt((px - mouse.x) * (px - mouse.x) + (py - mouse.y) * (py - mouse.y));
          const mouseInfluence = Math.max(0, 180 - distToMouse) / 180;
          
          const wave = Math.sin(nx * 8 + ny * 6 + time) * 10 * depth;
          const ripple = Math.sin(distToMouse * 0.04 - time * 4) * 20 * mouseInfluence * (1 + mouse.speed * 0.08);
          
          points[r][c] = {
            x: px,
            y: py + wave + ripple
          };
        }
      }
      
      // Desenhar linhas de perspetiva (colunas)
      for (let c = 0; c <= cols; c++) {
        ctx.beginPath();
        ctx.moveTo(points[0][c].x, points[0][c].y);
        for (let r = 1; r <= rows; r++) {
          ctx.lineTo(points[r][c].x, points[r][c].y);
        }
        ctx.stroke();
      }
      
      // Desenhar linhas de profundidade (linhas)
      for (let r = 0; r <= rows; r++) {
        ctx.beginPath();
        ctx.moveTo(points[r][0].x, points[r][0].y);
        for (let c = 1; c <= cols; c++) {
          ctx.lineTo(points[r][c].x, points[r][c].y);
        }
        ctx.stroke();
      }
      
      requestAnimationFrame(drawGrid3D);
    }
    drawGrid3D();
  }

  // ── Blueprint Hotspots Click Handler ──
  const hotspots = document.querySelectorAll('.hotspot-dot');
  const bTitle = document.getElementById('blueprint-item-title');
  const bDesc = document.getElementById('blueprint-item-desc');
  hotspots.forEach(dot => {
    dot.addEventListener('click', function(e) {
      e.preventDefault();
      hotspots.forEach(h => h.classList.remove('active-hotspot'));
      this.classList.add('active-hotspot');
      playClickChirp();
      
      if (bTitle && bDesc) {
        bTitle.textContent = this.getAttribute('data-title');
        bDesc.textContent = this.getAttribute('data-desc');
      }
    });
  });

  // ── Circular Menu Mobile Touch UX ──
  const satNodeContainers = document.querySelectorAll('.sat-node-container');
  satNodeContainers.forEach(container => {
    const mainLink = container.querySelector('.sat-node');
    const hasSubOrbits = container.querySelector('.sub-orbits') !== null;
    
    if (mainLink && hasSubOrbits) {
      mainLink.addEventListener('click', function(e) {
        if (window.innerWidth <= 640) {
          const isOpened = container.classList.contains('touch-open');
          if (!isOpened) {
            e.preventDefault();
            satNodeContainers.forEach(c => c.classList.remove('touch-open'));
            container.classList.add('touch-open');
            playClickChirp();
          }
        }
      });
    }
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('.sat-node-container')) {
      satNodeContainers.forEach(c => c.classList.remove('touch-open'));
    }
  });

  // ── Movable Drag/Drop widgets logic ──
  setupDraggableWidget('tech-chat-popup', 'chat-drag-handle');
  setupDraggableWidget('tech-telemetry-popup', 'telemetry-drag-handle');
  
  function setupDraggableWidget(popupId, handleId) {
    const el = document.getElementById(popupId);
    const handle = document.getElementById(handleId);
    if (!el || !handle) return;

    let active = false;
    let currentX = 0;
    let currentY = 0;
    let initialX = 0;
    let initialY = 0;
    let xOffset = 0;
    let yOffset = 0;

    handle.addEventListener('mousedown', dragStart, false);
    document.addEventListener('mouseup', dragEnd, false);
    document.addEventListener('mousemove', drag, false);

    handle.addEventListener('touchstart', dragStart, { passive: false });
    document.addEventListener('touchend', dragEnd, { passive: false });
    document.addEventListener('touchmove', drag, { passive: false });

    function dragStart(e) {
      if (window.innerWidth <= 640) return; // Disable dragging on mobile
      if (el.classList.contains('collapsed')) return;
      if (e.target.tagName === 'BUTTON') return;

      if (e.type === 'touchstart') {
        initialX = e.touches[0].clientX - xOffset;
        initialY = e.touches[0].clientY - yOffset;
      } else {
        initialX = e.clientX - xOffset;
        initialY = e.clientY - yOffset;
      }
      active = true;
    }

    function dragEnd() {
      initialX = currentX;
      initialY = currentY;
      active = false;
    }

    function drag(e) {
      if (active) {
        e.preventDefault();
        if (e.type === 'touchmove') {
          currentX = e.touches[0].clientX - initialX;
          currentY = e.touches[0].clientY - initialY;
        } else {
          currentX = e.clientX - initialX;
          currentY = e.clientY - initialY;
        }
        xOffset = currentX;
        yOffset = currentY;
        el.style.transform = `translate3d(${currentX}px, ${currentY}px, 0)`;
      }
    }
  }

  // ── Telemetria Operacional Cockpit em Tempo Real ──
  const windEl = document.getElementById('telemetry-wind');
  const dronesEl = document.getElementById('telemetry-drones');
  const altEl = document.getElementById('telemetry-alt');
  const hudAltVal = document.getElementById('hud-val-alt');
  const hudSpdVal = document.getElementById('hud-val-spd');
  const hudBatVal = document.getElementById('hud-val-bat');
  const hudLatVal = document.getElementById('hud-val-lat');
  const hudLonVal = document.getElementById('hud-val-lon');

  // Valores iniciais e base
  let currentWind = 14;
  let currentAlt = 120;
  let currentDrones = 7;
  let currentBat = 88;
  
  // Coordenadas base de Luanda (Edifício AeroSpace)
  let latBase = -8.8124;
  let lonBase = 13.2306;

  function formatDMS(val, isLat) {
    const absVal = Math.abs(val);
    const degrees = Math.floor(absVal);
    const minutes = Math.floor((absVal - degrees) * 60);
    const seconds = Math.round(((absVal - degrees) * 60 - minutes) * 60);
    let dir = '';
    if (isLat) {
      dir = val >= 0 ? 'N' : 'S';
    } else {
      dir = val >= 0 ? 'E' : 'W';
    }
    return `${String(degrees).padStart(2, '0')}°${String(minutes).padStart(2, '0')}'${String(seconds).padStart(2, '0')}"${dir}`;
  }

  setInterval(() => {
    // 1. Velocidade do vento oscila suavemente
    currentWind += (Math.random() > 0.5 ? 1 : -1) * (Math.random() > 0.5 ? 2 : 1);
    currentWind = Math.max(8, Math.min(32, currentWind));
    if (windEl) windEl.textContent = `${currentWind} km/h`;
    if (hudSpdVal) hudSpdVal.textContent = `${currentWind + 28}km/h`; // Velocidade do drone = vento + cruzeiro

    // 2. Altitude flutua ligeiramente
    currentAlt += (Math.random() > 0.5 ? 1 : -1) * Math.floor(Math.random() * 3);
    currentAlt = Math.max(105, Math.min(135, currentAlt));
    if (altEl) altEl.textContent = `${currentAlt}m`;
    if (hudAltVal) hudAltVal.textContent = `${currentAlt + 4}m`;

    // 3. Drones ativos mudam ocasionalmente
    if (Math.random() > 0.85) {
      currentDrones += Math.random() > 0.5 ? 1 : -1;
      currentDrones = Math.max(4, Math.min(12, currentDrones));
      if (dronesEl) dronesEl.textContent = `${String(currentDrones).padStart(2, '0')} ONLINE`;
    }

    // 4. Bateria drena muito lentamente (e volta a carregar após 20% para demo)
    currentBat -= 0.1;
    if (currentBat < 20) currentBat = 98;
    if (hudBatVal) hudBatVal.textContent = `${Math.round(currentBat)}%`;

    // 5. Coordenadas GPS flutuam simulando desvio orbital/vento
    const latOffset = (Math.random() - 0.5) * 0.0008;
    const lonOffset = (Math.random() - 0.5) * 0.0008;
    if (hudLatVal) hudLatVal.textContent = formatDMS(latBase + latOffset, true);
    if (hudLonVal) hudLonVal.textContent = formatDMS(lonBase + lonOffset, false);

  }, 2500);
});

// ── Synthesized Sound FX (Highly Optimized Audio API) ──
let soundMuted = localStorage.getItem('aerospace_sound_muted') === 'true';
let audioCtx = null;

// Inicializa o botão com base no localStorage
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.querySelector('.sound-toggle-btn');
  if (btn) {
    btn.textContent = soundMuted ? '🔇 Mudo' : '🔊 Áudio';
  }
});

function playSynthSound(freq, type = 'sine', duration = 0.1, vol = 0.05) {
  if (soundMuted) return;
  try {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') audioCtx.resume();
    
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    
    osc.type = type;
    osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
    gain.gain.setValueAtTime(vol, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
    
    osc.connect(gain); gain.connect(audioCtx.destination);
    osc.start(); osc.stop(audioCtx.currentTime + duration);
  } catch (err) {}
}

function playHoverChirp() { playSynthSound(580, 'sine', 0.06, 0.015); }
function playClickChirp() { playSynthSound(750, 'triangle', 0.1, 0.025); }
function triggerPingSound() { playSynthSound(980, 'sine', 0.8, 0.035); }

function toggleSoundMute(e) {
  if (e) e.stopPropagation();
  soundMuted = !soundMuted;
  localStorage.setItem('aerospace_sound_muted', soundMuted);
  const btn = document.querySelector('.sound-toggle-btn');
  if (btn) {
    btn.textContent = soundMuted ? '🔇 Mudo' : '🔊 Áudio';
  }
}

// ── Chat Popup Action Controller ──
function toggleChatCollapse(e) {
  if (e) e.stopPropagation();
  const chat = document.getElementById('tech-chat-popup');
  if (chat) chat.classList.toggle('collapsed');
}

function toggleChatOpen(open, e) {
  if (e) e.stopPropagation();
  const chat = document.getElementById('tech-chat-popup');
  const trigger = document.getElementById('chat-trigger-btn');
  if (chat) {
    if (open) {
      chat.classList.remove('collapsed');
      chat.style.display = 'flex';
      if (trigger) trigger.style.display = 'none';
    } else {
      chat.style.display = 'none';
      if (trigger) trigger.style.display = 'block';
    }
  }
}

// ── Telemetry Widget Action Controller ──
function toggleTelemetryCollapse(e) {
  if (e) e.stopPropagation();
  const tel = document.getElementById('tech-telemetry-popup');
  if (tel) tel.classList.toggle('collapsed');
}

function toggleTelemetryOpen(open, e) {
  if (e) e.stopPropagation();
  const tel = document.getElementById('tech-telemetry-popup');
  const trigger = document.getElementById('telemetry-trigger-btn');
  if (tel) {
    if (open) {
      tel.classList.remove('collapsed');
      tel.style.display = 'flex';
      if (trigger) trigger.style.display = 'none';
    } else {
      tel.style.display = 'none';
      if (trigger) trigger.style.display = 'block';
    }
  }
}

function handleChatSubmit(e) {
  e.preventDefault();
  const input = document.getElementById('chat-popup-text-input');
  const container = document.getElementById('chat-messages-container');
  if (!input || !input.value.trim() || !container) return;
  
  const userText = input.value.trim();
  input.value = '';
  
  const userDiv = document.createElement('div');
  userDiv.className = 'msg user';
  userDiv.textContent = userText;
  container.appendChild(userDiv);
  container.scrollTop = container.scrollHeight;
  
  setTimeout(() => {
    const replyDiv = document.createElement('div');
    replyDiv.className = 'msg agent';
    const lower = userText.toLowerCase();
    if (lower.includes('preco') || lower.includes('custo') || lower.includes('preço')) {
      replyDiv.textContent = 'As nossas soluções operacionais dependem do plano de voo e peso de carga. Introduza a directiva "agendar estudo" ou envie uma mensagem no contacto para um orçamento.';
    } else if (lower.includes('drone') || lower.includes('frota')) {
      replyDiv.textContent = 'Operamos aeronaves eléctricas de carga pesada Orion-X com asas fixas e rotores integrados para transição vertical e autonomias de até 150 km.';
    } else if (lower.includes('contacto') || lower.includes('email') || lower.includes('falar')) {
      replyDiv.textContent = 'Pode contactar a nossa mesa operacional pelo formulário no fundo da página ou diretamente pelo email: ops@aerospace.io';
    } else {
      replyDiv.textContent = `Directiva "${userText}" registada. Encaminhando para o Centro de Comando de Operações Aeroespaciais...`;
    }
    container.appendChild(replyDiv);
    container.scrollTop = container.scrollHeight;
    playSynthSound(600, 'sine', 0.15, 0.02);
  }, 1000);
}

// ── Web Speech API Voice Controller ──
let recognition = null;
let voiceActive = false;

function initVoiceCommand() {
  const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Speech) return;
  recognition = new Speech();
  recognition.lang = 'pt-PT';
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onstart = () => {
    voiceActive = true;
    document.getElementById('voice-mic-btn').classList.add('mic-active');
    playSynthSound(440, 'triangle', 0.08, 0.02);
  };
  recognition.onend = () => {
    voiceActive = false;
    document.getElementById('voice-mic-btn').classList.remove('mic-active');
  };
  recognition.onresult = (e) => {
    const text = e.results[0][0].transcript.toLowerCase();
    processVoiceCommand(text);
  };
}

function toggleVoiceListen() {
  if (!recognition) initVoiceCommand();
  if (!recognition) return;
  if (voiceActive) recognition.stop(); else recognition.start();
}

function processVoiceCommand(cmd) {
  const container = document.getElementById('chat-messages-container');
  if (container) {
    const userDiv = document.createElement('div');
    userDiv.className = 'msg user';
    userDiv.textContent = `🎙️ [Voz]: "${cmd}"`;
    container.appendChild(userDiv);
    container.scrollTop = container.scrollHeight;
  }
  
  setTimeout(() => {
    const replyDiv = document.createElement('div');
    replyDiv.className = 'msg agent';
    
    if (cmd.includes('contacto') || cmd.includes('falar') || cmd.includes('mensagem')) {
      document.getElementById('contacto')?.scrollIntoView({ behavior: 'smooth' });
      replyDiv.textContent = 'A navegar para o painel de contacto operacional...';
    } else if (cmd.includes('serviço') || cmd.includes('operação') || cmd.includes('missão') || cmd.includes('missõ')) {
      document.getElementById('servicos')?.scrollIntoView({ behavior: 'smooth' });
      replyDiv.textContent = 'A navegar para a secção de serviços e missões...';
    } else if (cmd.includes('sobre') || cmd.includes('empresa') || cmd.includes('história')) {
      document.getElementById('sobre')?.scrollIntoView({ behavior: 'smooth' });
      replyDiv.textContent = 'A navegar para a secção institucional (Sobre Nós)...';
    } else if (cmd.includes('telemetria') || cmd.includes('dados') || cmd.includes('instrumento')) {
      toggleTelemetryOpen(true);
      replyDiv.textContent = 'A inicializar consola de telemetria em tempo real...';
    } else if (cmd.includes('chat') || cmd.includes('suporte') || cmd.includes('ajuda')) {
      toggleChatOpen(true);
      replyDiv.textContent = 'A abrir canal de suporte operacional...';
    } else if (cmd.includes('fechar') || cmd.includes('minimizar')) {
      toggleChatOpen(false);
      toggleTelemetryOpen(false);
      replyDiv.textContent = 'A recolher todos os widgets do cockpit.';
    } else if (cmd.includes('áudio') || cmd.includes('som') || cmd.includes('silenciar') || cmd.includes('mudo')) {
      toggleSoundMute();
      replyDiv.textContent = soundMuted ? 'Áudio do cockpit desativado.' : 'Áudio do cockpit ativado.';
    } else {
      replyDiv.textContent = `Diretiva de voz "${cmd}" reconhecida. Sem acção de atalho local mapeada.`;
    }
    
    container.appendChild(replyDiv);
    container.scrollTop = container.scrollHeight;
    playSynthSound(900, 'sine', 0.2, 0.025);
  }, 800);
}


  // ── Portal Page Transition — Intercept circular menu link clicks ──
  function portalNavigate(href) {
    if (!href || href === '#' || href === window.location.pathname) return;
    document.body.classList.add('portal-exit');
    // Layered synth launch audio
    playSynthSound(260, 'sawtooth', 0.55, 0.06);
    setTimeout(() => playSynthSound(540, 'sine', 0.3, 0.04), 90);
    setTimeout(() => playSynthSound(1100, 'sine', 0.12, 0.025), 210);
    setTimeout(() => { window.location.href = href; }, 490);
  }

  // Attach portal transition to all .portal-link elements
  document.querySelectorAll('.portal-link').forEach(link => {
    link.addEventListener('click', function(e) {
      const href = this.getAttribute('data-portal-href') || this.getAttribute('href');
      // Skip external links (target="_blank") and pure anchors
      if (this.getAttribute('target') === '_blank' || !href || href.startsWith('#')) return;
      e.preventDefault();
      portalNavigate(href);
    });
  });

  // ── Portal Entry — trigger body animation on internal pages ──
  // .portal-active on navbar is set by Blade when on internal page + circular layout
  const portalNavbar = document.querySelector('.normal-navbar.portal-active');
  if (portalNavbar) {
    // Trigger portal entry body animation (CSS handles the rest)
    requestAnimationFrame(() => {
      document.body.classList.add('portal-entry');
      setTimeout(() => {
        document.body.classList.remove('portal-entry');
      }, 600);
    });
  }

  // ── Mobile Menu Toggler ──
window.toggleMobileMenu = function(e) {
  if (e) e.stopPropagation();
  const navbar = document.querySelector('.normal-navbar');
  const btn = document.querySelector('.hamburger-menu-btn');
  if (navbar) {
    const isOpen = navbar.classList.toggle('menu-open');
    if (btn) btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
  }
  playClickChirp();
};

// ── Aerospace Contact Form Handler (SEO-safe, CSRF-protected via @csrf token) ──
window.handleAerospaceContactSubmit = function(e) {
  e.preventDefault();
  const form = document.getElementById('aerospace-contact-form');
  const feedback = document.getElementById('contact-form-feedback');
  const submitBtn = document.getElementById('contact-submit-btn');
  if (!form || !feedback || !submitBtn) return;

  const nome = form.querySelector('#contact-name')?.value.trim();
  const email = form.querySelector('#contact-email')?.value.trim();
  const mensagem = form.querySelector('#contact-message')?.value.trim();

  // --- Client-side validation ---
  if (!nome || nome.length < 2) {
    showFormFeedback(feedback, 'Por favor, introduza o nome da empresa ou entidade.', 'error');
    return;
  }
  const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email || !emailRe.test(email)) {
    showFormFeedback(feedback, 'Por favor, introduza um e-mail de contacto válido.', 'error');
    return;
  }
  if (!mensagem || mensagem.length < 10) {
    showFormFeedback(feedback, 'Descreva a sua missão com pelo menos 10 caracteres.', 'error');
    return;
  }

  // --- Attempt AJAX submission (if route exists) or fallback to mailto ---
  submitBtn.disabled = true;
  submitBtn.textContent = 'A enviar...';

  const csrfToken = form.querySelector('input[name="_token"]')?.value || '';

  fetch('/contacto/enviar', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken, 'Accept': 'application/json' },
    body: JSON.stringify({ nome, email, mensagem })
  })
  .then(r => {
    if (!r.ok) throw new Error('Network error');
    return r.json();
  })
  .then(data => {
    showFormFeedback(feedback, data.message || form.getAttribute('data-success') || '✅ Missão submetida com sucesso!', 'success');
    form.reset();
    submitBtn.disabled = false;
    submitBtn.textContent = form.querySelector('button[type="submit"]')?.textContent || 'Submeter Plano de Missão';
    playClickChirp();
  })
  .catch(() => {
    // Graceful fallback: open mailto
    const subject = encodeURIComponent(`Plano de Missão — ${nome}`);
    const body = encodeURIComponent(`Nome: ${nome}\nE-mail: ${email}\n\nMensagem:\n${mensagem}`);
    const destEmail = form.getAttribute('data-mailto') || 'ops@aerospace.io'; window.location.href = `mailto:${destEmail}?subject=${subject}&body=${body}`;
    showFormFeedback(feedback, '📨 O seu e-mail padrão foi aberto. Aguardamos a sua mensagem!', 'info');
    submitBtn.disabled = false;
    submitBtn.textContent = form.querySelector('button[type="submit"]')?.textContent || 'Submeter Plano de Missão';
  });
};

function showFormFeedback(el, msg, type) {
  if (!el) return;
  el.textContent = msg;
  el.className = `text-xs py-2 ${type === 'error' ? 'text-red-400' : type === 'success' ? 'text-emerald-400' : 'text-cyan-400'}`;
  el.classList.remove('hidden');
  setTimeout(() => el.classList.add('hidden'), 7000);
}

function handleSupportFormSubmit(e){ if(e) e.preventDefault(); try{ if(typeof playClickChirp==='function') playClickChirp(); }catch(_){ } var f=e&&e.target; var body=f?f.closest('.chat-popup-body'):null; if(body){ body.innerHTML='<div class="msg system" style="text-align:center;padding:24px 12px;">✓ Mensagem enviada. A nossa equipa entrará em contacto.</div>'; } return false; }

/* ── Sticky Header on Scroll ── */
window.addEventListener('scroll', function() {
  const navbar = document.querySelector('.normal-navbar.is-sticky');
  if (navbar) {
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  }
});

/* ── Contact Detail Form Handler ── */
window.handleAerospaceDetailFormSubmit = function(e) {
  e.preventDefault();
  const form = document.getElementById('aerospace-contact-detail-form');
  const feedback = document.getElementById('detail-form-feedback');
  const submitBtn = document.getElementById('detail-submit-btn');
  if (!form || !feedback || !submitBtn) return;

  const nome = form.querySelector('#detail-name')?.value.trim();
  const email = form.querySelector('#detail-email')?.value.trim();
  const mensagem = form.querySelector('#detail-message')?.value.trim();
  const servico = form.querySelector('#detail-service')?.value || '';

  const showFb = (msg, type) => {
    if (!feedback) return;
    feedback.textContent = msg;
    feedback.className = 'text-xs py-2 rounded-lg px-3 ' +
      (type === 'error' ? 'bg-red-500/10 text-red-400' :
       type === 'success' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-cyan-500/10 text-cyan-400');
    feedback.classList.remove('hidden');
    if (type !== 'error') setTimeout(() => feedback.classList.add('hidden'), 7000);
  };

  if (!nome || nome.length < 2) { showFb('Por favor, introduza o nome da empresa ou entidade.', 'error'); return; }
  const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email || !emailRe.test(email)) { showFb('Por favor, introduza um e-mail válido.', 'error'); return; }
  if (!mensagem || mensagem.length < 10) { showFb('Descreva a sua necessidade com pelo menos 10 caracteres.', 'error'); return; }

  submitBtn.disabled = true;
  const originalText = submitBtn.textContent;
  submitBtn.textContent = 'A enviar...';

  const csrfToken = form.querySelector('input[name="_token"]')?.value || '';
  const successMsg = form.getAttribute('data-success') || '✅ Mensagem enviada com sucesso!';
  const destEmail = form.getAttribute('data-mailto') || 'ops@aerospace.io';

  fetch('/contacto/enviar', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken, 'Accept': 'application/json' },
    body: JSON.stringify({ nome, email, mensagem, servico })
  })
  .then(r => { if (!r.ok) throw new Error('Network error'); return r.json(); })
  .then(data => {
    showFb(data.message || successMsg, 'success');
    form.reset();
    submitBtn.disabled = false;
    submitBtn.textContent = originalText;
    try { playClickChirp(); } catch(_) {}
  })
  .catch(() => {
    const subject = encodeURIComponent('Pedido de Informação — ' + nome);
    const body = encodeURIComponent('Nome: ' + nome + '\nE-mail: ' + email + '\nServiço: ' + servico + '\n\nMensagem:\n' + mensagem);
    window.location.href = 'mailto:' + destEmail + '?subject=' + subject + '&body=' + body;
    showFb('📨 O seu e-mail padrão foi aberto. Aguardamos a sua mensagem!', 'info');
    submitBtn.disabled = false;
    submitBtn.textContent = originalText;
  });
};


/* ── Newsletter Form Handler ── */
window.handleNewsletterSubmit = function(e) {
  e.preventDefault();
  const form = document.getElementById('aerospace-newsletter-form');
  const emailInput = document.getElementById('newsletter-email');
  const feedback = document.getElementById('newsletter-feedback');
  const btn = document.getElementById('newsletter-submit-btn');
  if (!form || !emailInput || !feedback || !btn) return;

  const email = emailInput.value.trim();
  const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email || !emailRe.test(email)) {
    feedback.textContent = 'Por favor, introduza um e-mail válido.';
    feedback.className = 'text-xs mt-3 py-1 text-red-400';
    feedback.classList.remove('hidden');
    return;
  }

  btn.disabled = true;
  const originalText = btn.textContent;
  btn.textContent = 'A subscrever...';

  const csrfToken = form.querySelector('input[name="_token"]')?.value || '';
  const successMsg = form.getAttribute('data-success') || '📡 Subscrição efectuada com sucesso!';

  fetch('/newsletter/subscrever', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken, 'Accept': 'application/json' },
    body: JSON.stringify({ email })
  })
  .then(r => { if (!r.ok) throw new Error('Network error'); return r.json(); })
  .then(data => {
    feedback.textContent = data.message || successMsg;
    feedback.className = 'text-xs mt-3 py-1 text-emerald-400';
    feedback.classList.remove('hidden');
    form.reset();
    btn.disabled = false;
    btn.textContent = originalText;
    try { playClickChirp(); } catch(_) {}
  })
  .catch(() => {
    feedback.textContent = '📨 Subscrição registada. Entraremos em contacto brevemente.';
    feedback.className = 'text-xs mt-3 py-1 text-cyan-400';
    feedback.classList.remove('hidden');
    btn.disabled = false;
    btn.textContent = originalText;
  });
};


/* ── Support Form Handler ── */
window.handleSupportFormSubmit = function(e) {
  if (e) e.preventDefault();
  const form = e && e.target;
  if (!form) return false;

  const nome = form.querySelector('input[name="nome"]')?.value.trim();
  const email = form.querySelector('input[name="email"]')?.value.trim();
  const mensagem = form.querySelector('textarea[name="mensagem"]')?.value.trim();

  if (!nome || !email || !mensagem) {
    const errDiv = form.querySelector('.chat-support-error') || document.createElement('div');
    errDiv.className = 'chat-support-error msg system';
    errDiv.style.color = '#f87171';
    errDiv.style.fontSize = '0.75rem';
    errDiv.textContent = '⚠️ Por favor, preencha todos os campos.';
    if (!form.querySelector('.chat-support-error')) form.appendChild(errDiv);
    return false;
  }

  const body = form.closest('.chat-popup-body');
  const csrfToken = form.querySelector('input[name="_token"]')?.value || '';
  const successMsg = form.getAttribute('data-success') || 'Mensagem enviada! A nossa equipa entrará em contacto em breve.';

  if (body) {
    body.innerHTML = '<div class="msg system" style="text-align:center;padding:32px 16px;"><div style="font-size:2rem;margin-bottom:8px;">✅</div><div style="color:#34d399;font-weight:600;margin-bottom:4px;">' + successMsg + '</div></div>';
  }

  fetch('/contacto/enviar', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken, 'Accept': 'application/json' },
    body: JSON.stringify({ nome, email, mensagem })
  }).catch(() => {});

  try { playClickChirp(); } catch(_) {}
  return false;
};


/* ── 3D Gallery Carousel Slider ── */
window.initAerospace3DGallery = function() {
  const scene = document.querySelector('.gallery-3d-scene');
  const items = document.querySelectorAll('.gallery-3d-item');
  const dotsContainer = document.querySelector('.gallery-3d-dots');
  if (!scene || items.length === 0) return;

  let currentIndex = 0;
  const count = items.length;
  const angleStep = 360 / count;
  let radius = 0;
  
  const radiusMult = parseFloat(scene.getAttribute('data-radius-multiplier') || '1.0');
  const soundFx = scene.getAttribute('data-sound-fx') === 'true';
  let isInit = true;

  const recalcRadius = () => { 
    radius = Math.round((scene.offsetWidth || 280) / 2 / Math.tan(Math.PI / count) * radiusMult); 
  };
  recalcRadius();

  if (dotsContainer) {
    dotsContainer.innerHTML = '';
    for (let i = 0; i < count; i++) {
      const dot = document.createElement('span');
      dot.className = 'gallery-3d-dot' + (i === 0 ? ' active' : '');
      dot.addEventListener('click', () => {
        currentIndex = i;
        updateCarousel();
        resetAutoRotate();
      });
      dotsContainer.appendChild(dot);
    }
  }

  function playGallerySound(type) {
    if (!soundFx || typeof playSynthSound !== 'function' || soundMuted) return;
    if (type === 'slide') {
      playSynthSound(680, 'sine', 0.08, 0.012);
    }
  }

  function updateCarousel() {
    recalcRadius();
    scene.style.transform = 'translateZ(-' + radius + 'px) rotateY(' + (-currentIndex * angleStep) + 'deg)';

    const dots = document.querySelectorAll('.gallery-3d-dot');
    dots.forEach((dot, idx) => {
      if (idx === currentIndex) dot.classList.add('active');
      else dot.classList.remove('active');
    });

    items.forEach((item, idx) => {
      const angle = idx * angleStep;
      item.style.transform = 'rotateY(' + angle + 'deg) translateZ(' + radius + 'px)';

      let diff = Math.abs(idx - currentIndex);
      if (diff > count / 2) diff = count - diff;

      if (idx === currentIndex) {
        item.classList.add('active-item');
        item.style.opacity = '1';
        item.style.filter = 'none';
        item.style.zIndex = '2';
      } else {
        item.classList.remove('active-item');
        item.style.opacity = diff > 1 ? '0.3' : '0.6';
        item.style.filter = 'blur(1px) grayscale(45%)';
        item.style.zIndex = '1';
      }
    });

    if (!isInit) {
      playGallerySound('slide');
    }
    isInit = false;
  }

  updateCarousel();
  window.addEventListener('resize', updateCarousel);
  window.addEventListener('load', updateCarousel);

  window.rotate3DGallery = function(direction) {
    if (direction === 'next') currentIndex = (currentIndex + 1) % count;
    else currentIndex = (currentIndex - 1 + count) % count;
    updateCarousel();
    resetAutoRotate();
  };

  const autoRotateEnabled = scene.getAttribute('data-auto-rotate') === 'true';
  const autoplaySpeed = parseInt(scene.getAttribute('data-autoplay-speed') || '5000');
  let rotateInterval;

  function startAutoRotate() {
    if (autoRotateEnabled) {
      rotateInterval = setInterval(() => {
        currentIndex = (currentIndex + 1) % count;
        updateCarousel();
      }, autoplaySpeed);
    }
  }

  function resetAutoRotate() {
    if (rotateInterval) {
      clearInterval(rotateInterval);
      startAutoRotate();
    }
  }

  startAutoRotate();

  const tiltEnabled = scene.getAttribute('data-tilt') === 'true';
  if (tiltEnabled) {
    items.forEach(item => {
      item.addEventListener('mousemove', (e) => {
        const itemIndex = parseInt(item.getAttribute('data-index') || '0');
        if (itemIndex !== currentIndex) return;
        const rect = item.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const xc = rect.width / 2;
        const yc = rect.height / 2;
        const angleX = (yc - y) / 10;
        const angleY = (x - xc) / 10;
        const baseAngle = itemIndex * angleStep;
        item.style.transform = 'rotateY(' + baseAngle + 'deg) translateZ(' + radius + 'px) rotateX(' + angleX + 'deg) rotateY(' + angleY + 'deg)';
      });
    });
  }

  // Drag & Swipe Navigation com Inércia
  const swipeEnabled = scene.getAttribute('data-swipe-enabled') === 'true';
  if (swipeEnabled) {
    let isDragging = false;
    let startX = 0;
    let velocity = 0;
    let lastX = 0;
    let lastTime = 0;

    scene.addEventListener('mousedown', dragStart);
    scene.addEventListener('touchstart', dragStart, { passive: true });

    function dragStart(e) {
      isDragging = true;
      startX = e.type === 'touchstart' ? e.touches[0].clientX : e.clientX;
      lastX = startX;
      lastTime = Date.now();
      velocity = 0;
      if (rotateInterval) clearInterval(rotateInterval);
    }

    document.addEventListener('mousemove', dragMove);
    document.addEventListener('touchmove', dragMove, { passive: false });

    function dragMove(e) {
      if (!isDragging) return;
      const x = e.type === 'touchmove' ? e.touches[0].clientX : e.clientX;
      const deltaX = x - lastX;
      const now = Date.now();
      const dt = now - lastTime;
      if (dt > 0) {
        velocity = deltaX / dt;
      }
      lastX = x;
      lastTime = now;

      const rotationOffset = (x - startX) * 0.12; 
      scene.style.transform = 'translateZ(-' + radius + 'px) rotateY(' + (-currentIndex * angleStep + rotationOffset) + 'deg)';
    }

    document.addEventListener('mouseup', dragEnd);
    document.addEventListener('touchend', dragEnd);

    function dragEnd(e) {
      if (!isDragging) return;
      isDragging = false;
      
      const threshold = 0.4;
      const dragDistance = lastX - startX;
      if (Math.abs(velocity) > threshold) {
        if (velocity > 0) {
          currentIndex = (currentIndex - 1 + count) % count;
        } else {
          currentIndex = (currentIndex + 1) % count;
        }
      } else if (Math.abs(dragDistance) > 60) {
        if (dragDistance > 0) {
          currentIndex = (currentIndex - 1 + count) % count;
        } else {
          currentIndex = (currentIndex + 1) % count;
        }
      }
      updateCarousel();
      resetAutoRotate();
    }
  }
};

/* ── Galeria Lightbox + Swipe ── */
window.AeroGalleryLightbox = (function () {
  let overlay = null, imgEl, capTitle, capText, counter, list = [], idx = 0, options = {};

  function build() {
    if (overlay) return;
    overlay = document.createElement('div');
    overlay.className = 'gallery-lightbox';
    overlay.innerHTML =
      '<button class="glb-close" aria-label="Fechar">✕</button>' +
      '<button class="glb-nav glb-prev" aria-label="Anterior">❮</button>' +
      '<figure class="glb-figure"><img class="glb-img" alt=""/>' +
      '<figcaption class="glb-cap"><span class="glb-counter"></span>' +
      '<span class="glb-cap-title"></span><span class="glb-cap-text"></span></figcaption></figure>' +
      '<button class="glb-nav glb-next" aria-label="Seguinte">❯</button>';
    document.body.appendChild(overlay);
    imgEl = overlay.querySelector('.glb-img');
    capTitle = overlay.querySelector('.glb-cap-title');
    capText = overlay.querySelector('.glb-cap-text');
    counter = overlay.querySelector('.glb-counter');
    overlay.querySelector('.glb-close').addEventListener('click', close);
    overlay.querySelector('.glb-prev').addEventListener('click', function (e) { e.stopPropagation(); step(-1); });
    overlay.querySelector('.glb-next').addEventListener('click', function (e) { e.stopPropagation(); step(1); });
    overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
    document.addEventListener('keydown', function (e) {
      if (!overlay.classList.contains('open')) return;
      if (e.key === 'Escape') close();
      else if (e.key === 'ArrowLeft') step(-1);
      else if (e.key === 'ArrowRight') step(1);
    });
    let sx = 0;
    overlay.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
    overlay.addEventListener('touchend', function (e) {
      const dx = e.changedTouches[0].clientX - sx;
      if (Math.abs(dx) > 40) step(dx < 0 ? 1 : -1);
    }, { passive: true });
  }

  function render() {
    const it = list[idx];
    if (!it) return;
    imgEl.src = it.src;
    imgEl.alt = it.alt || '';
    capTitle.textContent = it.alt || '';
    capText.textContent = it.caption || '';
    counter.textContent = (idx + 1) + ' / ' + list.length;
    const navs = overlay.querySelectorAll('.glb-nav');
    navs.forEach(function (b) { b.style.display = list.length > 1 ? '' : 'none'; });

    // Trigger laser scanner animation
    const fig = overlay.querySelector('.glb-figure');
    if (fig) {
      const oldScanner = fig.querySelector('.glb-scanner');
      if (oldScanner) oldScanner.remove();
      
      const scanner = document.createElement('div');
      scanner.className = 'glb-scanner';
      fig.appendChild(scanner);
      setTimeout(() => scanner.remove(), 1200);
    }
  }

  function step(d) { 
    idx = (idx + d + list.length) % list.length; 
    render(); 
    if (options.soundFx && typeof playSynthSound === 'function' && !soundMuted) {
      playSynthSound(720, 'sine', 0.06, 0.012);
    }
  }

  function open(items, i, opts) {
    build();
    list = items || [];
    idx = i || 0;
    options = opts || {};
    
    if (overlay) {
      overlay.style.setProperty('--gallery-lightbox-blur', options.blur || '12px');
    }
    
    render();
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    
    if (options.soundFx && typeof playSynthSound === 'function' && !soundMuted) {
      // Sonar Sweep sound
      playSynthSound(880, 'sine', 0.4, 0.015);
      setTimeout(() => playSynthSound(1200, 'sine', 0.2, 0.01), 80);
    } else {
      try { playClickChirp(); } catch (_) {}
    }
  }

  function close() {
    if (!overlay) return;
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }

  return { open: open, close: close };
})();

window.initAerospaceGalleryLightbox = function () {
  const containers = document.querySelectorAll('.gallery-3d-scene, .gallery-masonry, .gallery-grid');
  containers.forEach(function (container) {
    const imgs = Array.prototype.slice.call(container.querySelectorAll('img'));
    if (!imgs.length) return;
    
    const soundFx = container.getAttribute('data-sound-fx') !== 'false';
    const blurVal = container.style.getPropertyValue('--gallery-lightbox-blur') || '12px';

    const list = imgs.map(function (im) {
      return { src: im.getAttribute('src'), alt: im.getAttribute('alt') || '', caption: im.getAttribute('data-caption') || '' };
    });
    imgs.forEach(function (im, i) {
      if (im.dataset.lbBound) return;
      im.dataset.lbBound = '1';
      im.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        window.AeroGalleryLightbox.open(list, i, { soundFx: soundFx, blur: blurVal });
      });
    });
  });

  const vp = document.querySelector('.gallery-3d-viewport');
  if (vp && !vp.dataset.swipeBound) {
    vp.dataset.swipeBound = '1';
    let sx = 0, sy = 0;
    vp.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; }, { passive: true });
    vp.addEventListener('touchend', function (e) {
      const dx = e.changedTouches[0].clientX - sx;
      const dy = e.changedTouches[0].clientY - sy;
      if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy) && window.rotate3DGallery) {
        window.rotate3DGallery(dx < 0 ? 'next' : 'prev');
      }
    }, { passive: true });
  }
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => window.initAerospace3DGallery());
} else {
  window.initAerospace3DGallery();
}

/* ── Galeria Lightbox + Swipe ── */
window.AeroGalleryLightbox = (function () {
  let overlay = null, imgEl, capTitle, capText, counter, list = [], idx = 0;

  function build() {
    if (overlay) return;
    overlay = document.createElement('div');
    overlay.className = 'gallery-lightbox';
    overlay.innerHTML =
      '<button class="glb-close" aria-label="Fechar">✕</button>' +
      '<button class="glb-nav glb-prev" aria-label="Anterior">❮</button>' +
      '<figure class="glb-figure"><img class="glb-img" alt=""/>' +
      '<figcaption class="glb-cap"><span class="glb-counter"></span>' +
      '<span class="glb-cap-title"></span><span class="glb-cap-text"></span></figcaption></figure>' +
      '<button class="glb-nav glb-next" aria-label="Seguinte">❯</button>';
    document.body.appendChild(overlay);
    imgEl = overlay.querySelector('.glb-img');
    capTitle = overlay.querySelector('.glb-cap-title');
    capText = overlay.querySelector('.glb-cap-text');
    counter = overlay.querySelector('.glb-counter');
    overlay.querySelector('.glb-close').addEventListener('click', close);
    overlay.querySelector('.glb-prev').addEventListener('click', function (e) { e.stopPropagation(); step(-1); });
    overlay.querySelector('.glb-next').addEventListener('click', function (e) { e.stopPropagation(); step(1); });
    overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
    document.addEventListener('keydown', function (e) {
      if (!overlay.classList.contains('open')) return;
      if (e.key === 'Escape') close();
      else if (e.key === 'ArrowLeft') step(-1);
      else if (e.key === 'ArrowRight') step(1);
    });
    let sx = 0;
    overlay.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
    overlay.addEventListener('touchend', function (e) {
      const dx = e.changedTouches[0].clientX - sx;
      if (Math.abs(dx) > 40) step(dx < 0 ? 1 : -1);
    }, { passive: true });
  }

  function render() {
    const it = list[idx];
    if (!it) return;
    imgEl.src = it.src;
    imgEl.alt = it.alt || '';
    capTitle.textContent = it.alt || '';
    capText.textContent = it.caption || '';
    counter.textContent = (idx + 1) + ' / ' + list.length;
    const navs = overlay.querySelectorAll('.glb-nav');
    navs.forEach(function (b) { b.style.display = list.length > 1 ? '' : 'none'; });
  }

  function step(d) { idx = (idx + d + list.length) % list.length; render(); }

  function open(items, i) {
    build();
    list = items || [];
    idx = i || 0;
    render();
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    try { playClickChirp(); } catch (_) {}
  }

  function close() {
    if (!overlay) return;
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }

  return { open: open, close: close };
})();

window.initAerospaceGalleryLightbox = function () {
  const containers = document.querySelectorAll('.gallery-3d-scene, .gallery-masonry, .gallery-grid');
  containers.forEach(function (container) {
    const imgs = Array.prototype.slice.call(container.querySelectorAll('img'));
    if (!imgs.length) return;
    const list = imgs.map(function (im) {
      return { src: im.getAttribute('src'), alt: im.getAttribute('alt') || '', caption: im.getAttribute('data-caption') || '' };
    });
    imgs.forEach(function (im, i) {
      if (im.dataset.lbBound) return;
      im.dataset.lbBound = '1';
      im.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        window.AeroGalleryLightbox.open(list, i);
      });
    });
  });

  const vp = document.querySelector('.gallery-3d-viewport');
  if (vp && !vp.dataset.swipeBound) {
    vp.dataset.swipeBound = '1';
    let sx = 0, sy = 0;
    vp.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; }, { passive: true });
    vp.addEventListener('touchend', function (e) {
      const dx = e.changedTouches[0].clientX - sx;
      const dy = e.changedTouches[0].clientY - sy;
      if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy) && window.rotate3DGallery) {
        window.rotate3DGallery(dx < 0 ? 'next' : 'prev');
      }
    }, { passive: true });
  }
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => window.initAerospaceGalleryLightbox());
} else {
  window.initAerospaceGalleryLightbox();
}
