@php
  $c = $content ?? [];
  $heading = $c['heading'] ?? 'Pronto para Lançar a Missão?';
  $text = $c['text'] ?? $c['subheading'] ?? 'Solicite o estudo de viabilidade da sua operação de tráfego aéreo. Entraremos em contacto para detalhar o plano de voo.';
  $btnText = $c['button_text'] ?? $theme->layout_config['contact_form_btn_text'] ?? 'Submeter Plano de Missão';
  
  $phName    = $theme->layout_config['contact_form_placeholder_name']    ?? 'Nome da Empresa / Entidade';
  $phEmail   = $theme->layout_config['contact_form_placeholder_email']   ?? 'E-mail de Contacto';
  $phMessage = $theme->layout_config['contact_form_placeholder_message'] ?? 'Descreva a sua missão (ex: rota de transporte de 100km)';
  $formMailto = $theme->layout_config['contact_mailto'] ?? 'ops@aerospace.ao';
  $formSuccess = $theme->layout_config['contact_form_success_message'] ?? '✅ Missão submetida com sucesso! A nossa equipa de operações entrará em contacto em breve.';
  
  $secBg = $c['bg_color'] ?? $settings['bg_color'] ?? $c['custom_bg_color'] ?? null;
  $secText = $c['text_color'] ?? $settings['text_color'] ?? null;
@endphp
<section id="contacto" class="py-20 bg-gradient-to-br from-[#0F172A] to-[#070C18] border-t border-white/5 relative" style="@if($secBg) background: {{ $secBg }} !important; @endif @if($secText) color: {{ $secText }} !important; @endif">
  <div class="max-w-4xl mx-auto px-6 text-center">
    <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-semibold uppercase tracking-wider mb-6">
      ⚡ Pronto para Operar
    </div>
    <h2 class="text-3xl md:text-4xl font-bold text-white mb-6 font-heading">{{ $heading }}</h2>
    <p class="text-slate-400 max-w-xl mx-auto mb-10">{{ $text }}</p>
    <form id="aerospace-contact-form" class="max-w-md mx-auto space-y-4" novalidate
          onsubmit="handleAerospaceContactSubmit(event)"
          data-mailto="{{ $formMailto }}"
          data-success="{{ $formSuccess }}">
      @csrf
      <div class="text-left">
        <label for="contact-name" class="sr-only">Nome da Empresa ou Entidade</label>
        <input type="text" id="contact-name" name="nome" placeholder="{{ $phName }}" class="contact-input" required autocomplete="organization">
      </div>
      <div class="text-left">
        <label for="contact-email" class="sr-only">E-mail de Contacto</label>
        <input type="email" id="contact-email" name="email" placeholder="{{ $phEmail }}" class="contact-input" required autocomplete="email">
      </div>
      <div class="text-left">
        <label for="contact-message" class="sr-only">Descrição da Missão</label>
        <textarea id="contact-message" name="mensagem" placeholder="{{ $phMessage }}" rows="3" class="contact-input" required></textarea>
      </div>
      <div id="contact-form-feedback" class="text-xs py-2 hidden"></div>
      <button type="submit" id="contact-submit-btn" class="contact-btn w-full">{{ $btnText }}</button>
    </form>

    <!-- Google Map Container -->
    @if($theme->layout_config['contact_show_map'] ?? true)
      <div class="contact-map-container mt-12">
        <iframe src="{{ $theme->layout_config['contact_map_iframe'] ?? '' }}" title="Localização AeroSpace — Luanda, Angola" width="100%" height="350" style="border:0; border-radius:1rem; opacity:0.85;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div>
    @endif

    <!-- Newsletter Subscription -->
    @if($theme->layout_config['contact_show_newsletter'] ?? true)
      <div class="contact-newsletter-container mt-16 pt-12 border-t border-white/5">
        <h3 class="text-xl font-bold text-white mb-2 font-heading">{{ $theme->layout_config['newsletter_title'] ?? 'Subscrever Boletim Operacional' }}</h3>
        <p class="text-slate-400 text-xs mb-6 max-w-md mx-auto">{{ $theme->layout_config['newsletter_description'] ?? 'Receba novidades sobre espaço aéreo, legislação de drones e atualizações de investigação tecnológica.' }}</p>
        <form id="aerospace-newsletter-form" class="flex flex-col sm:flex-row gap-2 max-w-md mx-auto" novalidate
              onsubmit="handleNewsletterSubmit(event)"
              data-success="{{ $theme->layout_config['newsletter_success_message'] ?? '📡 Subscrição efectuada! Receberá o próximo boletim operacional em breve.' }}">
          @csrf
          <label for="newsletter-email" class="sr-only">Endereço de e-mail</label>
          <input type="email" id="newsletter-email" name="email" placeholder="Introduza o seu email..." class="contact-input sm:flex-1" required>
          <button type="submit" id="newsletter-submit-btn" class="contact-btn sm:w-auto px-6">{{ $theme->layout_config['newsletter_btn_text'] ?? 'Subscrever' }}</button>
        </form>
        <div id="newsletter-feedback" class="hidden text-xs mt-3 py-1"></div>
      </div>
    @endif
  </div>
</section>