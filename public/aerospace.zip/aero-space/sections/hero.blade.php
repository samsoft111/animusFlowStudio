@php
    $c = $content ?? [];
    $heading = $c['heading'] ?? 'Soberania nos Céus,<br>Precisão na Terra';
    $subheading = $c['subheading'] ?? 'A primeira plataforma integrada de tecnologia aeroespacial focada em logística aérea autónoma de carga e monitorização orbital de alta resolução.';
    $ctaText = $c['cta_text'] ?? 'Os Nossos Serviços';
    $ctaUrl = $c['cta_url'] ?? '/servicos';
    $cta2Text = $c['cta2_text'] ?? 'Entrar em Contacto';
    $cta2Url = $c['cta2_url'] ?? '/contactos';

    $isHome = request()->is('/') || request()->routeIs('home') || str_contains(request()->path(), 'preview-home') || (str_contains(request()->path(), 'preview/theme') && !str_contains(request()->path(), 'sobre') && !str_contains(request()->path(), 'servicos') && !str_contains(request()->path(), 'galeria') && !str_contains(request()->path(), 'contactos'));

    $navHex = ltrim((string)($theme->layout_config['navbar_color'] ?? '#1E293B'), '#');
    if (strlen($navHex) === 3) { $navHex = $navHex[0].$navHex[0].$navHex[1].$navHex[1].$navHex[2].$navHex[2]; }
    $navR = hexdec(substr($navHex, 0, 2)); $navG = hexdec(substr($navHex, 2, 2)); $navB = hexdec(substr($navHex, 4, 2));
    $navOpacity = max(0, min(100, (int)($theme->layout_config['navbar_opacity'] ?? 72))) / 100;
    $navbarBg = "rgba({$navR}, {$navG}, {$navB}, {$navOpacity})";
    $heroBg = $theme->layout_config['hero_bg_color'] ?? '#0F1A2E';

    $hudLat = $theme->layout_config['footer_lat'] ?? '08°50\'S';
    $hudLon = $theme->layout_config['footer_lon'] ?? '13°14\'E';
    if (is_numeric($hudLat)) {
        $hudLatVal = floatval($hudLat);
        $hudLat = sprintf("%02d°%02d'%s", abs((int)$hudLatVal), abs((int)(round(($hudLatVal - (int)$hudLatVal) * 60))), $hudLatVal >= 0 ? 'N' : 'S');
    }
    if (is_numeric($hudLon)) {
        $hudLonVal = floatval($hudLon);
        $hudLon = sprintf("%02d°%02d'%s", abs((int)$hudLonVal), abs((int)(round(($hudLonVal - (int)$hudLonVal) * 60))), $hudLonVal >= 0 ? 'E' : 'W');
    }
@endphp
<section class="aerospace-hero group {{ !$isHome ? 'hero-internal hero-revealed' : '' }}" style="--menu-space-top: {{ (int)($theme->layout_config['menu_space_top'] ?? 24) }}px; --menu-space-bottom: {{ (int)($theme->layout_config['menu_space_bottom'] ?? 24) }}px; --scrim-opacity: {{ (int)($theme->layout_config['screensaver_scrim'] ?? 10) / 100 }}; --scrim-blur: {{ (int)($theme->layout_config['screensaver_blur'] ?? 0) }}px; --video-opacity: {{ (int)($theme->layout_config['screensaver_video_opacity'] ?? 100) / 100 }}; --info-card-top: {{ (int)($theme->layout_config['info_card_top'] ?? 36) }}%; --circular-menu-y: {{ (int)($theme->layout_config['menu_space_top'] ?? 24) - 84 }}px; --navbar-bg: {{ $navbarBg }}; --hero-bg: {{ $heroBg }}; --subpage-padding-top: {{ (int)($theme->layout_config['hero_internal_padding_top'] ?? 50) }}px;">
  <!-- Preloader de Consola de Boot -->
  @if($theme->layout_config['preloader_terminal'] ?? true)
    <div id="aerospace-preloader" class="preloader-terminal">
      <div class="terminal-container">
        <div class="terminal-header">
          <span class="terminal-dot red"></span>
          <span class="terminal-dot yellow"></span>
          <span class="terminal-dot green"></span>
          <span class="terminal-title">{{ strtoupper($siteName ?? 'AEROSPACE') }} COCKPIT INIT v1.0.0</span>
        </div>
        <div class="terminal-body" id="preloader-terminal-log"></div>
      </div>
    </div>
  @endif

  <!-- Background Element Layer based on configuration -->
  <div class="screensaver-container">
    @if(($theme->layout_config['hud_bg_type'] ?? 'video') === 'video')
      <video autoplay loop muted playsinline class="screensaver-video" poster="{{ $theme->layout_config['hud_bg_single_photo'] ?? '/images/aerospace-hero.svg' }}">
        <source src="{{ $theme->layout_config['hud_bg_video'] ?? '/videos/aerospace-fundo.mp4' }}" type="video/mp4">
      </video>
    @elseif(($theme->layout_config['hud_bg_type'] ?? 'video') === 'gallery')
      <div class="screensaver-gallery">
        @foreach(($theme->layout_config['hud_bg_gallery'] ?? []) as $index => $slide)
          <div class="slide-item @if($index === 0) active-slide @endif" style="background-image: url('{{ $slide }}')"></div>
        @endforeach
      </div>
    @elseif(($theme->layout_config['hud_bg_type'] ?? 'video') === 'photo')
      <div class="screensaver-photo" style="background-image: url('{{ $theme->layout_config['hud_bg_single_photo'] ?? '/images/aerospace-hero.svg' }}')"></div>
    @endif

    <!-- HUD Overlay Dashboard (Cockpit telemetry) -->
    @if($theme->layout_config['hud_overlay_enabled'] ?? true)
      <div class="hud-overlay-dashboard">
        <div class="hud-crosshair"></div>
        <div class="hud-horizon-line"></div>
        <div class="hud-telemetry-left">
          ALT: <span id="hud-val-alt">{{ $theme->layout_config['hud_telemetry_alt'] ?? '124m' }}</span><br>
          SPD: <span id="hud-val-spd">{{ $theme->layout_config['hud_telemetry_spd'] ?? '42km/h' }}</span><br>
          BAT: <span id="hud-val-bat">{{ $theme->layout_config['hud_telemetry_bat'] ?? '88%' }}</span><br>
          ALT-HOLD: {{ $theme->layout_config['hud_telemetry_althold'] ?? 'ON' }}
        </div>
        <div class="hud-telemetry-right">
          LAT: <span id="hud-val-lat">{{ $hudLat }}</span><br>
          LNG: <span id="hud-val-lon">{{ $hudLon }}</span><br>
          GPS: {{ $theme->layout_config['hud_telemetry_gps'] ?? 'LOCK' }}<br>
          NAV-LOCK: {{ $theme->layout_config['hud_telemetry_navlock'] ?? 'OK' }}
        </div>
      </div>
    @endif

    <div class="info-panel">
      <div class="info-card animate-pulse">
        <div class="radar-ping"></div>
        <h3 class="font-bold mb-2 tracking-widest" style="font-size: {{ (int)($theme->layout_config['info_card_title_size'] ?? 20) }}px; color: {{ $theme->layout_config['info_card_title_color'] ?? '#FFFFFF' }};">{{ $theme->layout_config['info_card_title_text'] ?? 'AEROSPACE' }}</h3>
        <p class="uppercase tracking-wider mb-3" style="font-size: {{ (int)($theme->layout_config['info_card_subtitle_size'] ?? 12) }}px; color: {{ $theme->layout_config['info_card_subtitle_color'] ?? '#06B6D4' }};">{{ $theme->layout_config['info_card_subtitle_text'] ?? 'Operações & Logística Aérea' }}</p>
        <p style="font-size: {{ (int)($theme->layout_config['info_card_hint_size'] ?? 10) }}px; color: {{ $theme->layout_config['info_card_hint_color'] ?? '#94A3B8' }};">{{ $theme->layout_config['info_card_hint_text'] ?? 'Passe o cursor ou toque no ecrã para aceder' }}</p>
      </div>
    </div>
  </div>

  <!-- Main Content Overlay -->
  <div class="hero-content">
    <!-- Grelha 3D Interativa com Perspetiva (Laser Mesh) -->
    @if($theme->layout_config['interactive_mesh_3d'] ?? true)
      <div class="grid-background-3d-wrap">
        <canvas id="mesh-grid-3d-canvas" class="absolute inset-0 w-full h-full opacity-40 pointer-events-none" style="mix-blend-mode: screen;"></canvas>
        <div class="grid-background-3d" id="mesh-grid-3d" style="display: none;"></div>
      </div>
    @else
      <div class="grid-background"></div>
    @endif
    
    <!-- Normal Navigation Header -->
    @php
      $menuLayoutCfg = $theme->layout_config['menu_layout'] ?? 'circular';
      $effectiveMenuLayout = ($menuLayoutCfg === 'circular' && !$isHome) ? 'normal' : $menuLayoutCfg;
      $effectiveMenuPosition = ($menuLayoutCfg === 'circular' && !$isHome) ? ($theme->layout_config['normal_menu_position'] ?? 'horizontal-right') : ($layout['normal_menu_position'] ?? 'horizontal-right');
      $showNormalMenu = ($effectiveMenuLayout === 'normal');
      $showCircularMenu = ($effectiveMenuLayout === 'circular');
    @endphp
    <header class="normal-navbar pos-{{ $effectiveMenuPosition }} @if($theme->layout_config['header_sticky'] ?? true) is-sticky @endif @if(!$showNormalMenu) hidden-navbar @endif @if(!$isHome && $menuLayoutCfg === 'circular') portal-active @endif">
      <button class="hamburger-menu-btn" onclick="toggleMobileMenu(event)" aria-label="Abrir menu de navegação" aria-expanded="false">
        <span></span>
        <span></span>
        <span></span>
      </button>
      <div class="logo-area">
        @php
          $logoType = $theme->layout_config['logo_type'] ?? 'both';
          $logoHeight = ($theme->layout_config['logo_height'] ?? 36) . 'px';
          $logoTextSize = ($theme->layout_config['logo_text_size'] ?? 20) . 'px';
          $logoTextWeight = $theme->layout_config['logo_text_weight'] ?? 'bold';
          $siteName = $site_name ?? 'AeroSpace';
          $homepageUrl = $site_homepage_url ?? '/';
        @endphp

        @if($logoType === 'image' || $logoType === 'both')
          <a href="{{ $homepageUrl }}" class="logo-img-link">
            <img src="{{ $theme->layout_config['logo_image_light'] ?? '/images/aerospace-logo.svg' }}" 
                 alt="{{ $siteName }}" 
                 style="height: {{ $logoHeight }};"
                 class="logo-light" />
            @if(!empty($theme->layout_config['logo_image_dark']))
              <img src="{{ $theme->layout_config['logo_image_dark'] }}" 
                   alt="{{ $siteName }}" 
                   style="height: {{ $logoHeight }};"
                   class="logo-dark hidden" />
            @endif
          </a>
        @endif

        @if($logoType === 'text' || $logoType === 'both')
          <a href="{{ $homepageUrl }}" class="logo-text-link" style="font-size: {{ $logoTextSize }}; font-weight: {{ $logoTextWeight }};">
            {{ $siteName }}
          </a>
        @endif
      </div>
      <nav class="horizontal-links">
        <ul>
          @foreach($nav_links ?? [] as $link)
            @php
              $children = $link['children'] ?? [];
              $isActive = request()->is(ltrim($link['url'], '/')) || (request()->is('/') && $link['url'] === '/');
            @endphp
            <li>
              <a href="{{ $link['url'] }}" class="{{ $isActive ? 'active' : '' }}" onmouseenter="playHoverChirp()" @if(($link['target'] ?? '_self') === '_blank') target="_blank" @endif>
                {{ $link['label'] }} @if(!empty($children)) ▾ @endif
              </a>
              @if(!empty($children))
                <ul class="normal-dropdown">
                  @foreach($children as $child)
                    <li>
                      <a href="{{ $child['url'] }}" onmouseenter="playHoverChirp()" @if(($child['target'] ?? '_self') === '_blank') target="_blank" @endif>
                        {{ $child['label'] }}
                      </a>
                    </li>
                  @endforeach
                </ul>
              @endif
            </li>
          @endforeach
        </ul>
      </nav>
      <div class="flex items-center gap-4">
        <button class="sound-toggle-btn text-xs bg-white/5 hover:bg-white/10 px-2 py-1 rounded border border-white/10 text-slate-400" onclick="toggleSoundMute(event)">🔊 Áudio</button>
      </div>
    </header>

    
    <!-- Circular Navigation (HOME centro + 4 Satélites) -->
    @php
      $hubTitle = $theme->layout_config['circular_menu_hub_text'] ?? 'HOME';
      $hubDesc = $theme->layout_config['circular_menu_hub_desc'] ?? 'Central Hub';
      $hubColor = $theme->layout_config['circular_menu_hub_color'] ?? '#06B6D4';

      $hubR = 6; $hubG = 182; $hubB = 212;
      $hubHex = ltrim($hubColor, '#');
      if (preg_match('/^[0-9a-fA-F]{6}$/', $hubHex)) {
          $hubR = hexdec(substr($hubHex, 0, 2));
          $hubG = hexdec(substr($hubHex, 2, 2));
          $hubB = hexdec(substr($hubHex, 4, 2));
      }

      $satBg = $theme->layout_config['circular_menu_bg'] ?? 'rgba(15, 23, 42, 0.85)';
      $satTextColor = $theme->layout_config['circular_menu_text_color'] ?? '#FFFFFF';
      $satDescColor = $theme->layout_config['circular_menu_desc_color'] ?? '#94A3B8';
      $satFontSize = ($theme->layout_config['circular_menu_font_size'] ?? 13) . 'px';

      $satWeightVal = $theme->layout_config['circular_menu_font_weight'] ?? 'bold';
      $weightMap = ['normal' => '400', 'medium' => '500', 'semibold' => '600', 'bold' => '700', 'extrabold' => '800'];
      $satFontWeight = $weightMap[$satWeightVal] ?? '700';
    @endphp
    <div class="circular-menu-wrapper @if(!$showCircularMenu) hidden-menu @endif" style="
      --hub-color: {{ $hubColor }};
      --hub-color-rgb: {{ $hubR }}, {{ $hubG }}, {{ $hubB }};
      --sat-bg: {{ $satBg }};
      --sat-text-color: {{ $satTextColor }};
      --sat-desc-color: {{ $satDescColor }};
      --sat-font-size: {{ $satFontSize }};
      --sat-font-weight: {{ $satFontWeight }};
    ">
      <div class="radar-circles"></div>
      <div class="radial-grid"></div>

      <!-- Central Hub (Home) -->
      <a href="/" class="menu-hub-node" onmouseenter="playHoverChirp()" onclick="playClickChirp()">
        <span class="node-title">{{ $hubTitle }}</span>
        <span class="node-desc">{{ $hubDesc }}</span>
        <div class="hub-glow"></div>
      </a>

      <!-- Satellite Orbiting Nodes -->
      <div class="satellite-orbits">
        @php
          $defaultSats = [
            ['label' => 'Serviços', 'url' => '/servicos', 'icon' => '🛸', 'desc' => 'Operações Aéreas'],
            ['label' => 'Galeria',  'url' => '/galeria',  'icon' => '🖼️', 'desc' => 'Missões & Media'],
            ['label' => 'Contactos','url' => '/contactos','icon' => '📡', 'desc' => 'Centro de Controlo'],
            ['label' => 'Sobre',    'url' => '/sobre',    'icon' => '🌐', 'desc' => 'Missão & Equipa']
          ];
          $menuLinks = $nav_links ?? [];
        @endphp
        @for($i = 0; $i < 4; $i++)
          @php
            $link = $menuLinks[$i] ?? null;
            $title = $link['label'] ?? $defaultSats[$i]['label'];
            $url = $link['url'] ?? $defaultSats[$i]['url'];
            $icon = $theme->layout_config['circular_menu_sat' . ($i + 1) . '_icon'] ?? $defaultSats[$i]['icon'];
            $desc = $theme->layout_config['circular_menu_sat' . ($i + 1) . '_desc'] ?? $defaultSats[$i]['desc'];
            $color = $theme->layout_config['circular_menu_sat' . ($i + 1) . '_color'] ?? '#06B6D4';

            $satR = 6; $satG = 182; $satB = 212;
            $hexColor = ltrim($color, '#');
            if (preg_match('/^[0-9a-fA-F]{6}$/', $hexColor)) {
                $satR = hexdec(substr($hexColor, 0, 2));
                $satG = hexdec(substr($hexColor, 2, 2));
                $satB = hexdec(substr($hexColor, 4, 2));
            }
          @endphp
          <div class="sat-node-container sat-{{ $i + 1 }} group/sat" style="
            --sat-color: {{ $color }};
            --sat-color-rgb: {{ $satR }}, {{ $satG }}, {{ $satB }};
          ">
            <a href="{{ $url }}" class="sat-node portal-link" onmouseenter="playHoverChirp()" data-portal-href="{{ $url }}">
              <div class="sat-icon">{{ $icon }}</div>
              <div class="sat-text">
                <span class="sat-title">{{ $title }}</span>
                <span class="sat-desc">{{ $desc }}</span>
              </div>
            </a>
          </div>
        @endfor
      </div>
    </div>


    <!-- Main Headline area -->
    <div class="hero-text-area">
      <h1 class="glitch-title">{!! $heading !!}</h1>
      <p class="hero-subtitle">{{ $subheading }}</p>
      <div class="flex justify-center gap-4 mt-8">
        @if(!empty($ctaText))
          <a href="{{ $ctaUrl }}" class="hero-btn-primary" onclick="playClickChirp()">{{ $ctaText }}</a>
        @endif
        @if(!empty($cta2Text))
          <a href="{{ $cta2Url }}" class="hero-btn-secondary" onclick="playClickChirp()">{{ $cta2Text }}</a>
        @endif
      </div>
    </div>
  </div>

  <!-- JSON-LD Structured Data (SEO: Organization + WebSite Schema) -->
  <script type="application/ld+json">
  {
    "@@context": "https://schema.org",
    "@@graph": [
      {
        "@@type": "Organization",
        "name": "{{ $site->name ?? 'AeroSpace' }}",
        "url": "{{ config('app.url') }}",
        "logo": "{{ config('app.url') }}/images/aerospace-logo.svg",
        "description": "{{ $seo->description ?? 'Logística autónoma de carga, transporte vertical e monitorização orbital.' }}",
        "address": {
          "@@type": "PostalAddress",
          "addressLocality": "Luanda",
          "addressCountry": "AO"
        },
        "sameAs": []
      },
      {
        "@@type": "WebSite",
        "name": "{{ $site->name ?? 'AeroSpace' }}",
        "url": "{{ config('app.url') }}",
        "potentialAction": {
          "@@type": "SearchAction",
          "target": "{{ config('app.url') }}/?s={search_term_string}",
          "query-input": "required name=search_term_string"
        }
      }
    ]
  }
  </script>

  <!-- Draggable Popup Chat Support -->
  @if($theme->layout_config['chat_popup_enabled'] ?? true)
    <div id="tech-chat-popup" class="chat-popup collapsed">
      <div class="chat-popup-header" id="chat-drag-handle">
        <div class="flex items-center gap-2">
          <span class="chat-status-indicator animate-pulse"></span>
          <span class="font-heading font-bold text-xs tracking-wider">SUPORTE AERO</span>
        </div>
        <div class="flex gap-2 items-center">
          <button class="chat-toggle-size" onclick="toggleChatCollapse(event)">▢</button>
          <button class="chat-close" onclick="toggleChatOpen(false, event)">×</button>
        </div>
      </div>
      <div class="chat-popup-body">
        @if(($theme->layout_config['chat_popup_mode'] ?? 'ai') === 'form')
        <form class="chat-input-area" style="flex-direction:column;align-items:stretch;gap:8px;" onsubmit="handleSupportFormSubmit(event)">
          <input type="text" name="nome" placeholder="Nome" required class="chat-input-field">
          <input type="email" name="email" placeholder="Email" required class="chat-input-field">
          <textarea name="mensagem" rows="3" placeholder="A sua mensagem..." required class="chat-input-field" style="resize:none;"></textarea>
          <button type="submit" class="chat-send-btn" style="width:100%;" onclick="playClickChirp()">Enviar ➔</button>
        </form>
        @else
        <div class="chat-messages" id="chat-messages-container">
          <div class="msg system">Canal encriptado de assistência ativo. Como posso auxiliar a sua missão?</div>
        </div>
        <div class="chat-voice-suggestions text-[9px] text-slate-500 font-mono p-2 border-t border-white/5 bg-slate-950/20">
          Diretivas de Voz: <span class="text-cyan-400">"ir para sobre"</span> | <span class="text-cyan-400">"serviços"</span> | <span class="text-cyan-400">"telemetria"</span> | <span class="text-cyan-400">"áudio"</span> | <span class="text-cyan-400">"fechar"</span>
        </div>
        <form class="chat-input-area" onsubmit="handleChatSubmit(event)">
          <input type="text" id="chat-popup-text-input" placeholder="Introduzir directiva..." class="chat-input-field">
          @if($theme->layout_config['chat_voice_commands'] ?? true)
            <button type="button" id="voice-mic-btn" class="chat-send-btn bg-slate-700/50 hover:bg-slate-700" onclick="toggleVoiceListen()" title="Comando de Voz">🎙️</button>
          @endif
          <button type="submit" class="chat-send-btn" onclick="playClickChirp()">➔</button>
        </form>
        @endif
      </div>
    </div>
    <button id="chat-trigger-btn" onclick="toggleChatOpen(true, event)">💬 Canal de Apoio</button>
  @endif

  @if($theme->layout_config['telemetry_enabled'] ?? false)
  <!-- Draggable Live Telemetry Widget -->
  <div id="tech-telemetry-popup" class="chat-popup collapsed">
    <div class="chat-popup-header" id="telemetry-drag-handle">
      <div class="flex items-center gap-2">
        <span class="chat-status-indicator yellow animate-pulse"></span>
        <span class="font-heading font-bold text-xs tracking-wider">TELEMETRIA LIVE</span>
      </div>
      <div class="flex gap-2">
        <button class="chat-toggle-size" onclick="toggleTelemetryCollapse(event)">▢</button>
        <button class="chat-close" onclick="toggleTelemetryOpen(false, event)">×</button>
      </div>
    </div>
    <div class="chat-popup-body">
      <div class="space-y-4 text-left font-mono text-[10px] text-slate-400">
        <div class="flex justify-between border-b border-white/5 pb-1">
          <span>SAT-LINK STATUS:</span> <span class="text-[#06b6d4]">{{ $theme->layout_config['hud_telemetry_navlock'] ?? 'CONNECTED (100%)' }}</span>
        </div>
        <div class="flex justify-between border-b border-white/5 pb-1">
          <span>DRONES OPERACIONAIS:</span> <span class="text-emerald-400" id="telemetry-drones">{{ $theme->layout_config['hud_telemetry_drones_count'] ?? '07 ONLINE' }}</span>
        </div>
        <div class="flex justify-between border-b border-white/5 pb-1">
          <span>VELOCIDADE DO VENTO:</span> <span id="telemetry-wind">{{ $theme->layout_config['hud_telemetry_spd'] ?? '14 km/h' }}</span>
        </div>
        <div class="flex justify-between border-b border-white/5 pb-1">
          <span>ALTITUDE MÉDIA:</span> <span id="telemetry-alt">{{ $theme->layout_config['hud_telemetry_alt'] ?? '120m' }}</span>
        </div>
        <div class="flex justify-between">
          <span>SINAL GPS:</span> <span class="text-emerald-400">{{ $theme->layout_config['hud_telemetry_gps'] ?? 'EXCELENTE' }}</span>
        </div>
        <div class="mt-4 pt-2 border-t border-white/10 text-center">
          <button class="px-2 py-1 rounded bg-[#06b6d4]/10 border border-[#06b6d4]/30 text-[#06b6d4] text-[9px] hover:bg-[#06b6d4]/20 transition" onclick="triggerPingSound()">Sonar Ping Manual</button>
        </div>
      </div>
    </div>
  </div>
  <button id="telemetry-trigger-btn" onclick="toggleTelemetryOpen(true, event)">📊 Telemetria</button>
  @endif
</section>