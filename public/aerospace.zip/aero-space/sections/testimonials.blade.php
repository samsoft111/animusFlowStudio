@php
  $c = $content ?? [];
  $heading = $c['heading'] ?? 'O Que Dizem os Nossos Parceiros';
  $items = $c['items'] ?? [
    ['quote' => 'A AeroSpace transformou completamente a nossa operação de distribuição logística. Os drones chegam antes do prazo, com precisão surpreendente.', 'name' => 'Carlos Fernandes', 'role' => 'Director de Operações', 'company' => 'Grupo Logística Angola'],
    ['quote' => 'A cartografia orbital reduziu em 40% o tempo de planeamento das nossas obras. Tecnologia sem igual no mercado africano.', 'name' => 'Eng.ª Sofia Mendes', 'role' => 'Engenheira Chefe', 'company' => 'Construções INGA'],
    ['quote' => 'Monitorização em tempo real, equipa disponível 24/7 e tecnologia de ponta. Recomendo a AeroSpace sem reservas para missões críticas.', 'name' => 'Maj. António Silva', 'role' => 'Coordenador de Segurança', 'company' => 'Ministério do Interior']
  ];
  
  $secBg = $c['bg_color'] ?? $settings['bg_color'] ?? $c['custom_bg_color'] ?? null;
  $secText = $c['text_color'] ?? $settings['text_color'] ?? null;
@endphp
<section class="py-24 bg-[#030712] relative overflow-hidden" style="@if($secBg) background: {{ $secBg }} !important; @endif @if($secText) color: {{ $secText }} !important; @endif">
  <div class="absolute inset-0 opacity-[0.03]" style="background-image:radial-gradient(#06B6D4 1px,transparent 1px);background-size:24px 24px"></div>
  <div class="max-w-6xl mx-auto px-6 relative z-10">
    <div class="text-center mb-16">
      <span class="inline-flex items-center gap-2 text-[11px] font-mono uppercase tracking-[0.25em] text-[#06B6D4] mb-4">
        <span class="w-2 h-2 rounded-full bg-[#06B6D4] animate-pulse"></span> Parceiros & Clientes
      </span>
      <h2 class="text-4xl font-bold text-white font-heading">{{ $heading }}</h2>
    </div>
    <div class="grid md:grid-cols-3 gap-8">
      @foreach($items as $item)
        @php
          $initials = '';
          foreach (explode(' ', $item['name']) as $w) {
              $initials .= strtoupper(substr($w, 0, 1));
          }
          $initials = substr($initials, 0, 2);
        @endphp
        <div class="bg-[#070C18] border border-white/8 rounded-2xl p-8 relative group hover:border-[#06B6D4]/30 transition-all duration-300">
          <div class="absolute top-6 right-6 text-[#06B6D4]/20 text-5xl font-serif">"</div>
          @php
            $stars = (int)($item['rating'] ?? $item['stars'] ?? 5);
          @endphp
          <div class="flex gap-1 mb-4 text-[#06B6D4]">
            @for($i = 0; $i < 5; $i++)
              <span class="{{ $i < $stars ? 'text-[#06B6D4]' : 'text-slate-700/60' }}">★</span>
            @endfor
          </div>
          <p class="text-slate-300 text-sm leading-relaxed mb-6 italic">"{{ $item['quote'] }}"</p>
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-[#2563EB] to-[#06B6D4] flex items-center justify-center text-white font-bold text-sm">{{ $initials }}</div>
            <div>
              <div class="text-white font-semibold text-sm">{{ $item['name'] }}</div>
              <div class="text-slate-500 text-xs">{{ $item['role'] }} · {{ $item['company'] }}</div>
            </div>
          </div>
        </div>
      @endforeach
    </div>
  </div>
</section>