@php
  $c = $content ?? [];
  $heading = $c['heading'] ?? 'A Nossa Equipa de Comando';
  $subtext = $c['subtext'] ?? 'Engenheiros, cientistas e visionários com décadas de experiência aeroespacial e tecnológica.';
  $items = $c['items'] ?? [
    ['name' => 'Dr. Miguel Afonso', 'role' => 'CEO & Co-Fundador', 'bio' => 'Doutorado em Engenharia Aeroespacial pelo IST Lisboa. Ex-investigador da ESA.'],
    ['name' => 'Eng.ª Beatriz Nkosi', 'role' => 'CTO & Co-Fundadora', 'bio' => 'Especialista em sistemas de IA embarcada e autonomia de voo. Mestre em Robótica.'],
    ['name' => 'Cmdt. João Lopes', 'role' => 'Director de Operações', 'bio' => '20 anos de experiência militar em operações aéreas. Certificado ANAC/CAA.'],
    ['name' => 'Dra. Ana Fernandes', 'role' => 'Directora Comercial', 'bio' => 'MBA pela Nova SBE. Especialista em parcerias estratégicas em mercados emergentes.']
  ];
  
  $secBg = $c['bg_color'] ?? $settings['bg_color'] ?? $c['custom_bg_color'] ?? null;
  $secText = $c['text_color'] ?? $settings['text_color'] ?? null;
@endphp
<section class="py-24 bg-gradient-to-b from-[#030712] to-[#070C18] relative overflow-hidden" style="@if($secBg) background: {{ $secBg }} !important; @endif @if($secText) color: {{ $secText }} !important; @endif">
  <div class="absolute inset-0 opacity-[0.03]" style="background-image:radial-gradient(#06B6D4 1px,transparent 1px);background-size:32px 32px"></div>
  <div class="max-w-6xl mx-auto px-6 relative z-10">
    <div class="text-center mb-16">
      <span class="inline-flex items-center gap-2 text-[11px] font-mono uppercase tracking-[0.25em] text-[#06B6D4] mb-4">
        <span class="w-2 h-2 rounded-full bg-[#06B6D4] animate-pulse"></span> Liderança
      </span>
      <h2 class="text-4xl font-bold text-white font-heading">{{ $heading }}</h2>
      @if(!empty($subtext))
        <p class="text-slate-400 mt-4 max-w-xl mx-auto text-sm">{{ $subtext }}</p>
      @endif
    </div>
    <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
      @foreach($items as $item)
        @php
          $initials = '';
          foreach (explode(' ', $item['name']) as $w) {
              $initials .= strtoupper(substr($w, 0, 1));
          }
          $initials = substr($initials, 0, 2);
        @endphp
        <div class="bg-[#070C18] border border-white/8 rounded-2xl p-6 text-center group hover:border-[#06B6D4]/30 transition-all duration-300">
          @if(!empty($item['image']) || !empty($item['photo']))
            <img src="{{ $item['image'] ?? $item['photo'] }}" alt="{{ $item['name'] }}" class="w-16 h-16 rounded-2xl object-cover mx-auto mb-4 group-hover:scale-105 transition-transform duration-300 border border-white/10" />
          @else
            <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#2563EB] to-[#06B6D4] flex items-center justify-center text-white font-bold text-xl mx-auto mb-4 group-hover:scale-105 transition-transform duration-300">{{ $initials }}</div>
          @endif
          <div class="text-white font-semibold font-heading">{{ $item['name'] }}</div>
          <div class="text-[#06B6D4] text-xs font-mono uppercase tracking-wider mt-1 mb-3">{{ $item['role'] }}</div>
          <p class="text-slate-500 text-xs leading-relaxed">{{ $item['bio'] ?? $item['text'] ?? '' }}</p>
          @if(!empty($item['linkedin']) || !empty($item['url']))
            <a href="{{ $item['linkedin'] ?? $item['url'] }}" target="_blank" class="inline-flex items-center gap-1 mt-4 text-[10px] text-slate-600 hover:text-[#06B6D4] transition-colors font-mono uppercase tracking-wider">LinkedIn ↗</a>
          @endif
        </div>
      @endforeach
    </div>
  </div>
</section>