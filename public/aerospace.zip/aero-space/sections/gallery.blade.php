@php
  $c = $content ?? [];
  $heading = $c['heading'] ?? 'Arquivo Visual';
  $images = $c['images'] ?? [
    ['src' => 'https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=800&q=80', 'alt' => 'Drone de carga em voo', 'caption' => 'Drone Série AX-7 — Missão Malanje, 2024'],
    ['src' => 'https://images.unsplash.com/photo-1518623489648-a173ef7824f3?w=800&q=80', 'alt' => 'Aterragem de precisão', 'caption' => 'Aterragem em zona remota — Uíge, 2024'],
    ['src' => 'https://images.unsplash.com/photo-1601618440254-abf3e87f87e8?w=800&q=80', 'alt' => 'Frota em hangar', 'caption' => 'Hangar Central — Luanda, 2025']
  ];
  
  $secBg = $c['bg_color'] ?? $settings['bg_color'] ?? $c['custom_bg_color'] ?? null;
  $secText = $c['text_color'] ?? $settings['text_color'] ?? null;
@endphp
<section class="py-12 bg-[#030712] relative overflow-hidden" style="@if($secBg) background: {{ $secBg }} !important; @endif @if($secText) color: {{ $secText }} !important; @endif">
  <div class="max-w-6xl mx-auto px-6">
    <h3 class="text-sm font-mono uppercase tracking-wider text-[#06B6D4] mb-3 flex items-center gap-3">
      <span class="w-8 h-px bg-[#06B6D4]/40"></span> {{ $heading }}
    </h3>
    @php
      $layout = $theme->layout_config['gallery_layout'] ?? '3d-carousel';
      $autoRotate = ($theme->layout_config['gallery_auto_rotate'] ?? true) ? 'true' : 'false';
      $tilt = ($theme->layout_config['gallery_tilt_enabled'] ?? true) ? 'true' : 'false';
      $autoplaySpeed = $theme->layout_config['gallery_autoplay_speed'] ?? 5000;
      $hoverZoom = $theme->layout_config['gallery_hover_zoom'] ?? true;
      $colsDesktop = $theme->layout_config['gallery_columns_desktop'] ?? 3;
      $gap = $theme->layout_config['gallery_gap'] ?? 16;
      
      $hologram = $theme->layout_config['gallery_hologram_effect'] ?? true;
      $swipe = ($theme->layout_config['gallery_swipe_enabled'] ?? true) ? 'true' : 'false';
      $radiusMult = ($theme->layout_config['gallery_3d_radius_multiplier'] ?? 100) / 100;
      $lightboxBlur = $theme->layout_config['gallery_lightbox_blur'] ?? 12;
      $soundFx = ($theme->layout_config['gallery_sound_fx'] ?? true) ? 'true' : 'false';
    @endphp

    @if($layout === '3d-carousel')
      <!-- 3D CAROUSEL LAYOUT -->
      <div class="relative pt-0 pb-10">
        <div class="gallery-3d-viewport" style="--gallery-lightbox-blur: {{ $lightboxBlur }}px;">
          <div class="gallery-3d-scene" data-auto-rotate="{{ $autoRotate }}" data-tilt="{{ $tilt }}" data-autoplay-speed="{{ $autoplaySpeed }}" data-radius-multiplier="{{ $radiusMult }}" data-swipe-enabled="{{ $swipe }}" data-sound-fx="{{ $soundFx }}">
            @foreach($images as $index => $img)
              <div class="gallery-3d-item group/item" data-index="{{ $index }}">
                @if($hologram)
                  <div class="hud-hologram-overlay pointer-events-none absolute inset-0 z-10 bg-scanlines opacity-20"></div>
                @endif
                <img src="{{ $img['src'] }}" alt="{{ $img['alt'] ?? '' }}" data-caption="{{ $img['caption'] ?? '' }}" loading="lazy" decoding="async" class="w-full h-full object-cover opacity-75 group-hover/item:opacity-100 {{ $hoverZoom ? 'transition-all duration-500 group-hover/item:scale-105' : 'transition-opacity duration-300' }}" />
                <div class="item-caption opacity-0 group-hover/item:opacity-100 transition-opacity duration-300">
                  <p class="font-bold text-white mb-0.5">{{ $img['alt'] ?? '' }}</p>
                  <p class="text-slate-400 text-[10px]">{{ $img['caption'] ?? '' }}</p>
                </div>
              </div>
            @endforeach
          </div>
          
          <!-- Navegação -->
          <div class="gallery-3d-nav">
            <button class="gallery-3d-btn" onclick="rotate3DGallery('prev')" aria-label="Anterior">❮</button>
            <button class="gallery-3d-btn" onclick="rotate3DGallery('next')" aria-label="Seguinte">❯</button>
          </div>
        </div>
        
        <!-- Pontos Indicadores -->
        <div class="gallery-3d-dots"></div>
      </div>
    @elseif($layout === 'masonry')
      <!-- MASONRY LAYOUT -->
      <div class="gallery-masonry" style="column-count: var(--gallery-cols-desktop, 3); column-gap: var(--gallery-gap, 16px); --gallery-cols-desktop: {{ $colsDesktop }}; --gallery-gap: {{ $gap }}px; --gallery-lightbox-blur: {{ $lightboxBlur }}px;" data-sound-fx="{{ $soundFx }}">
        @foreach($images as $img)
          <div class="gallery-masonry-item group relative overflow-hidden aspect-auto" style="margin-bottom: var(--gallery-gap, 16px);">
            @if($hologram)
              <div class="hud-hologram-overlay pointer-events-none absolute inset-0 z-10 bg-scanlines opacity-15"></div>
            @endif
            <img src="{{ $img['src'] }}" alt="{{ $img['alt'] ?? '' }}" data-caption="{{ $img['caption'] ?? '' }}" loading="lazy" decoding="async" class="w-full object-cover opacity-85 group-hover:opacity-100 {{ $hoverZoom ? 'group-hover:scale-[1.02]' : '' }} transition-all duration-300">
            <div class="absolute inset-0 bg-gradient-to-t from-[#030712]/95 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
              <div>
                <p class="text-white text-xs font-mono font-bold">{{ $img['alt'] ?? '' }}</p>
                <p class="text-slate-400 text-[10px] font-mono mt-0.5">{{ $img['caption'] ?? '' }}</p>
              </div>
            </div>
          </div>
        @endforeach
      </div>
    @else
      <!-- GRID LAYOUT (Default fallback) -->
      <div class="grid grid-cols-1 gallery-grid" style="grid-template-columns: repeat(var(--gallery-cols-desktop, 3), minmax(0, 1fr)); gap: var(--gallery-gap, 16px); --gallery-cols-desktop: {{ $colsDesktop }}; --gallery-gap: {{ $gap }}px; --gallery-lightbox-blur: {{ $lightboxBlur }}px;" data-sound-fx="{{ $soundFx }}">
        @foreach($images as $img)
          <div class="group relative overflow-hidden rounded-xl border border-white/8 aspect-video bg-[#070C18] hover:border-[#06B6D4]/30 transition-all duration-300">
            @if($hologram)
              <div class="hud-hologram-overlay pointer-events-none absolute inset-0 z-10 bg-scanlines opacity-15"></div>
            @endif
            <img src="{{ $img['src'] }}" alt="{{ $img['alt'] ?? '' }}" data-caption="{{ $img['caption'] ?? '' }}" loading="lazy" decoding="async"
                 class="w-full h-full object-cover opacity-80 group-hover:opacity-100 {{ $hoverZoom ? 'group-hover:scale-105' : '' }} transition-all duration-500">
            <div class="absolute inset-0 bg-gradient-to-t from-[#030712]/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
              <div>
                <p class="text-white text-xs font-mono font-bold">{{ $img['alt'] ?? '' }}</p>
                <p class="text-slate-400 text-[10px] font-mono mt-0.5">{{ $img['caption'] ?? '' }}</p>
              </div>
            </div>
          </div>
        @endforeach
      </div>
    @endif
  </div>
</section>