@php
  $c = $content ?? [];
  $heading = $c['heading'] ?? 'Logistica autonoma <span class="text-[#06B6D4]">para alem do horizonte</span>';
  $body = $c['subheading'] ?? $c['body'] ?? 'A AeroSpace opera uma frota de transporte vertical de mercadorias coordenada por inteligencia artificial e monitorizacao orbital em tempo real. Cada entrega e calculada ao milimetro, com redundancia de rota e telemetria continua.';
  $items = $c['items'] ?? [
    'Corredores aereos certificados e geofencing dinamico',
    'Carga util ate 40kg com estabilizacao giroscopica',
    'Rastreio orbital com precisao sub-metrica'
  ];
  
  $secBg = $c['bg_color'] ?? $settings['bg_color'] ?? $c['custom_bg_color'] ?? null;
  $secText = $c['text_color'] ?? $settings['text_color'] ?? null;
@endphp
<section id="sobre" class="py-24 bg-[#030712] relative overflow-hidden" style="@if($secBg) background: {{ $secBg }} !important; @endif @if($secText) color: {{ $secText }} !important; @endif">
  <div class="absolute inset-0 opacity-[0.04]" style="background-image:radial-gradient(#06B6D4 1px,transparent 1px);background-size:28px 28px"></div>
  <div class="max-w-6xl mx-auto px-6 relative z-10">
    <div class="grid md:grid-cols-2 gap-14 items-center">
      <div>
        <span class="inline-flex items-center gap-2 text-[11px] font-mono uppercase tracking-[0.25em] text-[#06B6D4] mb-4">
          <span class="w-2 h-2 rounded-full bg-[#06B6D4] animate-pulse"></span> Missao Orbital
        </span>
        <h2 class="text-4xl md:text-5xl font-bold text-white font-heading leading-tight mb-6">{!! $heading !!}</h2>
        <p class="text-slate-400 text-lg leading-relaxed mb-6">{{ $body }}</p>
        <ul class="space-y-3">
          @foreach($items as $item)
            <li class="flex items-start gap-3 text-slate-300">
              <span class="text-[#06B6D4] mt-1">&#10142;</span>
              {{ is_array($item) ? ($item['title'] ?? '') : $item }}
            </li>
          @endforeach
        </ul>
      </div>
      <div class="relative">
        <div class="rounded-2xl border border-white/10 bg-[#070C18]/70 backdrop-blur p-8 shadow-2xl">
          <div class="flex items-center justify-between mb-6">
            <span class="font-mono text-[10px] uppercase tracking-widest text-slate-500">Status do Sistema</span>
            <span class="font-mono text-[10px] text-emerald-400">&#9679; OPERACIONAL</span>
          </div>
          @php
            $metrics = $c['metrics'] ?? $c['status_bars'] ?? [
              ['label' => 'Integridade da Frota', 'value' => '98%'],
              ['label' => 'Cobertura Orbital', 'value' => '91%'],
              ['label' => 'Eficiência Energética', 'value' => '87%']
            ];
          @endphp
          <div class="space-y-5">
            @foreach($metrics as $m)
              @php
                $valStr = $m['value'] ?? '100%';
                $valInt = (int)preg_replace('/[^0-9]/', '', $valStr);
              @endphp
              <div>
                <div class="flex justify-between text-xs text-slate-400 mb-1">
                  <span>{{ $m['label'] }}</span>
                  <span class="text-[#06B6D4]">{{ $valStr }}</span>
                </div>
                <div class="h-1.5 rounded-full bg-white/5 overflow-hidden">
                  <div class="h-full bg-gradient-to-r from-[#2563EB] to-[#06B6D4]" style="width: {{ $valInt }}%"></div>
                </div>
              </div>
            @endforeach
          </div>
        </div>
      </div>
    </div>
  </div>
</section>