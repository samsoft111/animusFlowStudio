@php
  $c = $content ?? [];
  $heading = $c['heading'] ?? 'Como Funciona';
  $items = $c['items'] ?? [
    ['number' => '01', 'title' => 'Briefing da Missão', 'text' => 'Reunião técnica para definir objectivos, rotas, payload e requisitos específicos da operação.'],
    ['number' => '02', 'title' => 'Planeamento & Licenças', 'text' => 'A nossa equipa trata de toda a burocracia: licenças ANAC, corredores aéreos e planos de contingência.'],
    ['number' => '03', 'title' => 'Execução Autónoma', 'text' => 'Lançamento da missão com monitorização em tempo real pelo nosso centro de controlo em Luanda.'],
    ['number' => '04', 'title' => 'Relatório Técnico', 'text' => 'Entrega de relatório completo com telemetria, imagens, métricas e dados de qualidade da missão.']
  ];
  
  $secBg = $c['bg_color'] ?? $settings['bg_color'] ?? $c['custom_bg_color'] ?? null;
  $secText = $c['text_color'] ?? $settings['text_color'] ?? null;
@endphp
<section class="py-24 bg-[#070C18] relative overflow-hidden" style="@if($secBg) background: {{ $secBg }} !important; @endif @if($secText) color: {{ $secText }} !important; @endif">
  <div class="max-w-4xl mx-auto px-6">
    <div class="text-center mb-16">
      <span class="inline-flex items-center gap-2 text-[11px] font-mono uppercase tracking-[0.25em] text-[#06B6D4] mb-4">
        <span class="w-2 h-2 rounded-full bg-[#06B6D4] animate-pulse"></span> Processo
      </span>
      <h2 class="text-4xl font-bold text-white font-heading">{{ $heading }}</h2>
    </div>
    <div class="space-y-8">
      @foreach($items as $item)
        <div class="flex items-start gap-8 group">
          <div class="flex-shrink-0">
            <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#2563EB] to-[#06B6D4] flex items-center justify-center font-mono font-bold text-white text-sm group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-[#06B6D4]/20">
              {{ $item['number'] ?? sprintf('%02d', $loop->iteration) }}
            </div>
          </div>
          <div class="bg-[#0A0F1E] border border-white/8 rounded-2xl p-6 flex-1 group-hover:border-[#06B6D4]/25 transition-all duration-300">
            <h3 class="text-white font-bold font-heading text-lg mb-2">{{ $item['title'] }}</h3>
            <p class="text-slate-400 text-sm leading-relaxed">{{ $item['text'] }}</p>
          </div>
        </div>
      @endforeach
    </div>
  </div>
</section>