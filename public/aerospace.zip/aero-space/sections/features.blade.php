@php
  $c = $content ?? [];
  $heading = $c['heading'] ?? 'Operações de Altitude';
  $subheading = $c['subtext'] ?? $c['subheading'] ?? 'Substituímos a logística tradicional por voos autónomos inteligentes e cartografia computacional a alta velocidade.';
  $items = $c['items'] ?? [
    ['icon' => '🛸', 'title' => 'Logística Autónoma', 'text' => 'Transporte aéreo de cargas pesadas a longa distância com frotas de aeronaves elétricas não tripuladas de alto desempenho.'],
    ['icon' => '🛰️', 'title' => 'Cartografia Orbital', 'text' => 'Mapeamento terrestre detalhado através de satélite e sensores multiespectrais para análise e inteligência geoespacial crítica.'],
    ['icon' => '👁️', 'title' => 'Vigilância e Reconhecimento', 'text' => 'Patrulhamento aéreo ativo com drones de alta altitude com visores térmicos e telemetria por radar laser em tempo real.']
  ];
  $gridCols = count($items) > 3 ? 'md:grid-cols-2 lg:grid-cols-4' : 'md:grid-cols-3';
  
  $secBg = $c['bg_color'] ?? $settings['bg_color'] ?? $c['custom_bg_color'] ?? null;
  $secText = $c['text_color'] ?? $settings['text_color'] ?? null;
@endphp
<section id="servicos" class="py-24 bg-[#070C18] relative overflow-hidden" style="@if($secBg) background: {{ $secBg }} !important; @endif @if($secText) color: {{ $secText }} !important; @endif">
  <div class="max-w-6xl mx-auto px-6">
    <div class="text-center mb-16">
      <h2 class="text-4xl font-bold tracking-tight text-white font-heading">{{ $heading }}</h2>
      @if(!empty($subheading))
        <p class="mt-4 text-lg text-slate-400 max-w-2xl mx-auto">{{ $subheading }}</p>
      @endif
    </div>
    <div class="grid grid-cols-1 {{ $gridCols }} gap-8">
      @foreach($items as $index => $item)
        <div class="feature-card group/card" onmouseenter="playHoverChirp()">
          <div class="card-glow"></div>
          <span class="card-num">{{ sprintf('%02d', $index + 1) }}</span>
          <h3 class="text-xl font-bold text-white mb-2 font-heading flex items-center gap-2">
            @if(!empty($item['icon']))
              <span class="text-cyan-400 text-lg">{{ $item['icon'] }}</span>
            @endif
            {{ $item['title'] }}
          </h3>
          <p class="text-slate-400 text-sm">{{ $item['text'] }}</p>
        </div>
      @endforeach
    </div>

    <!-- Painel de Especificações Interativo (Drone Hotspots Showcase) -->
    @php
      $blueprintImg = $c['blueprint_image'] ?? null;
      $hotspots = $c['hotspots'] ?? $c['blueprint_hotspots'] ?? [
        ['top' => '13%', 'left' => '13%', 'title' => 'Propulsores Elétricos VTOL', 'desc' => 'Quatro propulsores elétricos independentes de alta eficácia para descolagem e aterragem vertical autónoma em qualquer terreno.'],
        ['top' => '48%', 'left' => '48%', 'title' => 'Processador de IA & LIDAR', 'desc' => 'Núcleo de computação de bordo com sensor LIDAR de alta frequência para desvio dinâmico de obstáculos a 360º durante voos de baixa altitude.', 'active' => true],
        ['top' => '83%', 'left' => '83%', 'title' => 'Módulo de Energia de Lítio-Enxofre', 'desc' => 'Baterias aeroespaciais avançadas com densidade de carga triplicada face ao ião de lítio convencional, garantindo autonomias de até 150 km.']
      ];
      $defaultActiveHs = array_values(array_filter($hotspots, fn($hs) => $hs['active'] ?? false))[0] ?? ($hotspots[0] ?? null);
      $defaultTitle = $defaultActiveHs['title'] ?? 'Processador de IA & LIDAR';
      $defaultDesc = $defaultActiveHs['desc'] ?? '';
    @endphp
    <div class="drone-blueprint-showcase mt-16 border border-white/10 rounded-2xl bg-slate-900/40 p-8 backdrop-blur-md relative overflow-hidden">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        <div class="relative flex justify-center">
          <div class="blueprint-vector">
            @if(!empty($blueprintImg))
              <img src="{{ $blueprintImg }}" alt="Blueprint Inspecção" class="w-64 h-64 object-contain opacity-40" />
            @else
              <!-- SVG Esquema de Drone -->
              <svg class="w-64 h-64 text-cyan-500/15" viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="0.75">
                <circle cx="50" cy="50" r="12" stroke-dasharray="2 2" />
                <circle cx="50" cy="50" r="4" />
                <line x1="15" y1="15" x2="85" y2="85" />
                <line x1="15" y1="85" x2="85" y2="15" />
                <!-- Rotors -->
                <circle cx="15" cy="15" r="8" />
                <circle cx="85" cy="15" r="8" />
                <circle cx="15" cy="85" r="8" />
                <circle cx="85" cy="85" r="8" />
                <!-- Wings -->
                <path d="M25,50 L75,50 M50,25 L50,75" stroke-width="0.5" />
              </svg>
            @endif
            <!-- Interactive Hotspot Dots -->
            @foreach($hotspots as $hs)
              <button class="hotspot-dot @if($hs['active'] ?? false) active-hotspot @endif" 
                      style="top: {{ $hs['top'] }}; left: {{ $hs['left'] }};" 
                      data-title="{{ $hs['title'] }}" 
                      data-desc="{{ $hs['desc'] }}">
                <span class="ping-wave"></span>
              </button>
            @endforeach
          </div>
        </div>
        <div class="blueprint-info text-left">
          <div class="inline-block px-3 py-1 rounded bg-cyan-500/10 border border-cyan-500/20 text-[#06b6d4] text-[10px] uppercase font-bold tracking-widest mb-3">Inspecção de Hardware</div>
          <h3 class="text-2xl font-bold text-white mb-2 font-heading" id="blueprint-item-title">{{ $defaultTitle }}</h3>
          <p class="text-slate-400 text-sm leading-relaxed" id="blueprint-item-desc">{{ $defaultDesc }}</p>
        </div>
      </div>
    </div>
  </div>
</section>