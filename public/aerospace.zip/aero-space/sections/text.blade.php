@php
  $c = $content ?? [];
  $heading = $c['heading'] ?? 'Missão Orbital, Impacto Terrestre';
  $body = $c['body'] ?? 'A AeroSpace nasceu em Luanda em 2019, quando um grupo de engenheiros aeronáuticos e especialistas in inteligência artificial uniram forças com uma missão clara: levar a tecnologia aeroespacial ao serviço do desenvolvimento de Angola e de África.';
  
  $secBg = $c['bg_color'] ?? $settings['bg_color'] ?? $c['custom_bg_color'] ?? null;
  $secText = $c['text_color'] ?? $settings['text_color'] ?? null;
@endphp
<section class="py-20 bg-[#070C18] relative" style="@if($secBg) background: {{ $secBg }} !important; @endif @if($secText) color: {{ $secText }} !important; @endif">
  <div class="max-w-4xl mx-auto px-6">
    <div class="border-l-2 border-[#06B6D4]/30 pl-8">
      <span class="inline-flex items-center gap-2 text-[11px] font-mono uppercase tracking-[0.25em] text-[#06B6D4] mb-6">
        <span class="w-2 h-2 rounded-full bg-[#06B6D4] animate-pulse"></span> A Nossa História
      </span>
      <h2 class="text-3xl font-bold text-white font-heading mb-6">{{ $heading }}</h2>
      <div class="text-slate-300 leading-relaxed space-y-5 text-[0.95rem]">
        @if(str_contains($body, "\n"))
          @foreach(explode("\n", $body) as $para)
            <p>{{ $para }}</p>
          @endforeach
        @else
          <p>{{ $body }}</p>
        @endif
      </div>
    </div>
  </div>
</section>