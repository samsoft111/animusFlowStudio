@php
  $c = $content ?? [];
  $heading = $c['heading'] ?? 'Iniciar a Sua Missão';
  $subtext = $c['subtext'] ?? 'A nossa equipa está disponível 24/7. Respondemos em menos de 2 horas em dias úteis.';
  $btnText = $c['button_text'] ?? 'SUBMETER PEDIDO DE MISSÃO';

  $cEmail = $theme->layout_config['contact_email'] ?? 'comercial@aerospace.ao';
  $cPhone = $theme->layout_config['contact_phone'] ?? '+244 923 456 780';
  $cHours = $theme->layout_config['contact_hours'] ?? 'Seg–Sex · 08h00–18h00 (WAT)';

  $domainParts = explode('@', $cEmail);
  $domain = isset($domainParts[1]) ? $domainParts[1] : 'aerospace.ao';
  $opsEmail = $theme->layout_config['contact_mailto'] ?? ('ops@' . $domain);
  $opsPhone = (strlen($cPhone) > 5) ? (substr($cPhone, 0, -1) . '9') : '+244 923 456 789';

  $formSuccess = $theme->layout_config['contact_form_success_message'] ?? '✅ Missão submetida com sucesso! A nossa equipa de operações entrará em contacto em breve.';

  // Serviços do dropdown (um por linha)
  $servicesList = $theme->layout_config['contact_services_list'] ?? "Transporte Autónomo de Carga\nCartografia & Fotogrametria\nVigilância & Patrulhamento\nInspecção Industrial\nLogística de Emergência\nAgricultura de Precisão";
  $servicesOptions = array_filter(array_map('trim', explode("\n", $servicesList)));

  $loc = $theme->layout_config['footer_location'] ?? 'Luanda';
  $hq1 = $theme->layout_config['contact_address_hq'] ?? 'Rua Rainha Ginga, Edifício AeroSpace Tower';
  $hq2 = $theme->layout_config['contact_address_sub'] ?? 'Miramar, Luanda, Angola';

  $hgr1 = $theme->layout_config['contact_address_hangar'] ?? 'Aeroporto Internacional 4 de Fevereiro';
  $hgr2 = $theme->layout_config['contact_address_hangar_sub'] ?? 'Zona Técnica Norte — Hangar AX, Luanda';
  
  $secBg = $c['bg_color'] ?? $settings['bg_color'] ?? $c['custom_bg_color'] ?? null;
  $secText = $c['text_color'] ?? $settings['text_color'] ?? null;
@endphp
<section class="py-24 bg-[#070C18] relative overflow-hidden" style="@if($secBg) background: {{ $secBg }} !important; @endif @if($secText) color: {{ $secText }} !important; @endif">
  <div class="absolute inset-0 opacity-[0.03]" style="background-image:radial-gradient(#06B6D4 1px,transparent 1px);background-size:28px 28px"></div>
  <div class="max-w-6xl mx-auto px-6 relative z-10">
    <div class="text-center mb-16">
      <span class="inline-flex items-center gap-2 text-[11px] font-mono uppercase tracking-[0.25em] text-[#06B6D4] mb-4">
        <span class="w-2 h-2 rounded-full bg-[#06B6D4] animate-pulse"></span> Centro de Controlo
      </span>
      <h2 class="text-4xl font-bold text-white font-heading">{{ $heading }}</h2>
      <p class="text-slate-400 mt-4 max-w-xl mx-auto text-sm">{{ $subtext }}</p>
    </div>
    <div class="grid lg:grid-cols-2 gap-16 items-start">

      <!-- Canais de Contacto -->
      <div class="space-y-6">
        <div class="bg-[#0A0F1E] border border-white/8 rounded-2xl p-6 flex items-start gap-4 hover:border-[#06B6D4]/25 transition-all duration-300">
          <div class="text-2xl flex-shrink-0 mt-1">📡</div>
          <div>
            <div class="text-white font-semibold font-heading mb-1">Canal Operacional</div>
            <div class="text-slate-400 text-sm">{{ $opsEmail }} · {{ $opsPhone }}</div>
            <div class="text-[#06B6D4] text-xs font-mono mt-1">Disponível 24/7 for emergencies</div>
          </div>
        </div>
        <div class="bg-[#0A0F1E] border border-white/8 rounded-2xl p-6 flex items-start gap-4 hover:border-[#06B6D4]/25 transition-all duration-300">
          <div class="text-2xl flex-shrink-0 mt-1">💼</div>
          <div>
            <div class="text-white font-semibold font-heading mb-1">Propostas Comerciais</div>
            <div class="text-slate-400 text-sm">{{ $cEmail }} · {{ $cPhone }}</div>
            <div class="text-[#06B6D4] text-xs font-mono mt-1">{{ $cHours }}</div>
          </div>
        </div>
        <div class="bg-[#0A0F1E] border border-white/8 rounded-2xl p-6 flex items-start gap-4 hover:border-[#06B6D4]/25 transition-all duration-300">
          <div class="text-2xl flex-shrink-0 mt-1">📍</div>
          <div>
            <div class="text-white font-semibold font-heading mb-1">Sede — {{ $loc }}</div>
            <div class="text-slate-400 text-sm">{{ $hq1 }}</div>
            <div class="text-slate-400 text-sm">{{ $hq2 }}</div>
          </div>
        </div>
        <div class="bg-[#0A0F1E] border border-white/8 rounded-2xl p-6 flex items-start gap-4 hover:border-[#06B6D4]/25 transition-all duration-300">
          <div class="text-2xl flex-shrink-0 mt-1">✈️</div>
          <div>
            <div class="text-white font-semibold font-heading mb-1">Hangar & Testes</div>
            <div class="text-slate-400 text-sm">{{ $hgr1 }}</div>
            <div class="text-slate-400 text-sm">{{ $hgr2 }}</div>
          </div>
        </div>
      </div>

      <!-- Formulário -->
      <div class="bg-[#0A0F1E] border border-white/8 rounded-2xl p-8">
        <h3 class="text-white font-bold font-heading text-xl mb-2">Enviar Mensagem</h3>
        <p class="text-slate-500 text-sm mb-6">Descreva a sua necessidade e um especialista entrará em contacto.</p>
        <form id="aerospace-contact-detail-form" class="space-y-4" novalidate
              onsubmit="handleAerospaceDetailFormSubmit(event)"
              data-mailto="{{ $opsEmail }}"
              data-success="{{ $formSuccess }}">
          @csrf
          <div>
            <label for="detail-name" class="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-1.5">Nome / Empresa</label>
            <input type="text" id="detail-name" name="nome" placeholder="{{ $theme->layout_config['contact_form_placeholder_name'] ?? 'Ex: Grupo Logística Angola' }}" required
                   class="w-full bg-[#070C18] border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-slate-600 focus:outline-none focus:border-[#06B6D4]/50 transition-colors">
          </div>
          <div>
            <label for="detail-email" class="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-1.5">E-mail</label>
            <input type="email" id="detail-email" name="email" placeholder="{{ $theme->layout_config['contact_form_placeholder_email'] ?? 'missao@empresa.ao' }}" required
                   class="w-full bg-[#070C18] border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-slate-600 focus:outline-none focus:border-[#06B6D4]/50 transition-colors">
          </div>
          <div>
            <label for="detail-service" class="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-1.5">Serviço de Interesse</label>
            <select id="detail-service" name="servico" class="w-full bg-[#070C18] border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#06B6D4]/50 transition-colors">
              @foreach($servicesOptions as $srv)
                <option>{{ $srv }}</option>
              @endforeach
            </select>
          </div>
          <div>
            <label for="detail-message" class="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-1.5">Descrição da Missão</label>
            <textarea id="detail-message" name="mensagem" rows="4" placeholder="{{ $theme->layout_config['contact_form_placeholder_message'] ?? 'Descreva a sua necessidade operacional...' }}" required
                      class="w-full bg-[#070C18] border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-slate-600 focus:outline-none focus:border-[#06B6D4]/50 transition-colors resize-none"></textarea>
          </div>
          <div id="detail-form-feedback" class="hidden text-xs py-2 rounded-lg px-3"></div>
          <button type="submit" id="detail-submit-btn"
                  class="w-full bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white font-bold py-3 rounded-xl hover:opacity-90 transition-opacity font-heading tracking-wider text-sm">
            {{ strtoupper($btnText) }} ➤
          </button>
        </form>
      </div>
    </div>
  </div>
</section>