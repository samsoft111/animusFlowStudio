@php
  $c = $content ?? [];
  $items = $c['items'] ?? [
    ['icon' => '🛸', 'value' => '1.240+', 'label' => 'Missoes Concluidas'],
    ['icon' => '📡', 'value' => '99.98%', 'label' => 'Disponibilidade'],
    ['icon' => '🚁', 'value' => '48', 'label' => 'Drones na Frota'],
    ['icon' => '🌍', 'value' => '24/7', 'label' => 'Monitorizacao Orbital']
  ];
  
  $secBg = $c['bg_color'] ?? $settings['bg_color'] ?? $c['custom_bg_color'] ?? null;
  $secText = $c['text_color'] ?? $settings['text_color'] ?? null;
@endphp
<section class="py-20 bg-gradient-to-b from-[#070C18] to-[#030712] border-y border-white/5 relative" style="@if($secBg) background: {{ $secBg }} !important; @endif @if($secText) color: {{ $secText }} !important; @endif">
  <div class="max-w-6xl mx-auto px-6">
    @if(!empty($c['heading']))
      <div class="text-center mb-10">
        <h2 class="text-2xl font-bold text-white font-heading">{{ $c['heading'] }}</h2>
      </div>
    @endif
    <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
      @foreach($items as $item)
        <div>
          <div class="text-4xl md:text-5xl font-bold font-heading text-white" data-counter="{{ preg_replace('/[^0-9]/', '', $item['value']) }}">{{ $item['value'] }}</div>
          <div class="mt-2 font-mono text-[11px] uppercase tracking-widest text-[#06B6D4] flex items-center justify-center gap-1">
            @if(!empty($item['icon']))
              <span>{{ $item['icon'] }}</span>
            @endif
            {{ $item['label'] }}
          </div>
        </div>
      @endforeach
    </div>
  </div>
</section>