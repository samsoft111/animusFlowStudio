@php
  $c = $content ?? [];
  $siteName = $site_name ?? 'AeroSpace';
  $heading = $c['heading'] ?? ('Sede — ' . ($theme->layout_config['footer_location'] ?? 'Luanda, Angola'));
  $embedUrl = $c['embed_url'] ?? $theme->layout_config['contact_map_iframe'] ?? 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15760.84157778939!2d13.23005872895697!3d-8.813958742512686!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1a51f3c83786adbf%3A0x6b772c676bb7db4b!2sLuanda!5e0!3m2!1spt-PT!2sao!4v1700000000000!5m2!1spt-PT!2sao';
  $address = $c['address'] ?? ($theme->layout_config['contact_address_hq'] ?? 'Miramar, Luanda, Angola');
  $lat = $theme->layout_config['footer_lat'] ?? '-8.8124';
  $lon = $theme->layout_config['footer_lon'] ?? '13.2306';
  
  $secBg = $c['bg_color'] ?? $settings['bg_color'] ?? $c['custom_bg_color'] ?? null;
  $secText = $c['text_color'] ?? $settings['text_color'] ?? null;
@endphp
<section class="py-16 bg-[#030712] relative" style="@if($secBg) background: {{ $secBg }} !important; @endif @if($secText) color: {{ $secText }} !important; @endif">
  <div class="max-w-5xl mx-auto px-6">
    <div class="text-center mb-10">
      <span class="inline-flex items-center gap-2 text-[11px] font-mono uppercase tracking-[0.25em] text-[#06B6D4] mb-3">
        <span class="w-2 h-2 rounded-full bg-[#06B6D4] animate-pulse"></span> Localização
      </span>
      <h2 class="text-2xl font-bold text-white font-heading">{{ $heading }}</h2>
    </div>
    <div class="rounded-2xl overflow-hidden border border-white/8 relative">
      <iframe
        src="{{ $embedUrl }}"
        width="100%" height="380"
        style="border:0; filter: invert(90%) hue-rotate(180deg) brightness(0.85) contrast(1.1); opacity:0.9;"
        allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
        title="Localização {{ $siteName }} — {{ $theme->layout_config['footer_location'] ?? 'Luanda, Angola' }}">
      </iframe>
      <div class="absolute bottom-4 left-4 bg-[#030712]/90 backdrop-blur border border-[#06B6D4]/20 rounded-xl px-4 py-3">
        <div class="text-white font-semibold text-sm font-heading">{{ $siteName }} HQ</div>
        <div class="text-slate-400 text-xs mt-0.5">{{ $address }}</div>
        <div class="text-[#06B6D4] text-[10px] font-mono mt-1">LAT {{ $lat }} · LON {{ $lon }}</div>
      </div>
    </div>
  </div>
</section>