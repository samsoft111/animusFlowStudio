# AeroSpace

Tema tecnológico de vanguarda para soluções aeroespaciais, apresentando preloader de consola de boot, grelha 3D interativa de perspetiva, menu orbital com sonar, widgets de cockpit arrastáveis e comandos por voz.

**Version:** 1.1.0
**Requires AnimusFlow:** 1.2.0+
**Author:** Test Author <https://example.com>

## Installation

Upload this ZIP via AnimusFlow Admin → Extensions → Themes → Upload ZIP.

## Capabilities

- **video_bg**: ✅
- **parallax**: ✅
- **animations**: ✅
- **lightbox**: ✅
- **mega_menu**: ❌
- **search**: ❌
- **cookie_banner**: ✅
- **preloader**: ✅
- **scroll_progress**: ✅
- **back_to_top**: ✅
