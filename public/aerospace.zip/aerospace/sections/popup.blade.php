@php
    $heading    = $content['heading']  ?? '';
    $text       = $content['text']     ?? '';
    $ctaText    = $content['cta_text'] ?? '';
    $ctaUrl     = $content['cta_url']  ?? '#';
    $image      = $content['image']    ?? '';
    $trigger    = $settings['trigger']       ?? 'time_delay';
    $triggerVal = $settings['trigger_value'] ?? 5;
    $showOnce   = $settings['show_once']     ?? true;
    $uid        = 'popup-' . $block->uuid;
@endphp
<div class="af-popup" id="{{ $uid }}" role="dialog" aria-modal="true" aria-hidden="true">
    <div class="af-popup__overlay" onclick="afClosePopup('{{ $uid }}')"></div>
    <div class="af-popup__box">
        <button class="af-popup__close" onclick="afClosePopup('{{ $uid }}')" aria-label="Close">✕</button>
        @if($image)<div class="af-popup__image"><img src="{{ $image }}" alt="{{ $heading }}"></div>@endif
        <div class="af-popup__body">
            @if($heading)<h3 class="af-popup__heading" data-af-field="heading">{{ $heading }}</h3>@endif
            @if($text)<p class="af-popup__text" data-af-field="text">{{ $text }}</p>@endif
            @if($ctaText)<a href="{{ $ctaUrl }}" class="af-btn af-popup__cta" data-af-field="cta_text">{{ $ctaText }}</a>@endif
        </div>
    </div>
</div>
@push('scripts')
<script>
(function(){
    var uid = '{{ $uid }}';
    var trigger = '{{ $trigger }}';
    var val = {{ (int)$triggerVal }};
    var showOnce = {{ $showOnce ? 'true' : 'false' }};
    var storageKey = 'af_popup_' + uid;

    if (showOnce && localStorage.getItem(storageKey)) return;

    function openPopup() {
        var el = document.getElementById(uid);
        if (!el) return;
        el.setAttribute('aria-hidden','false');
        el.classList.add('af-popup--open');
        if (showOnce) localStorage.setItem(storageKey, '1');
    }

    if (trigger === 'time_delay') {
        setTimeout(openPopup, val * 1000);
    } else if (trigger === 'scroll_percent') {
        window.addEventListener('scroll', function onScroll(){
            var pct = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
            if (pct >= val) { openPopup(); window.removeEventListener('scroll', onScroll); }
        });
    } else if (trigger === 'exit_intent') {
        document.addEventListener('mouseleave', function onLeave(e){
            if (e.clientY < 0) { openPopup(); document.removeEventListener('mouseleave', onLeave); }
        });
    }
})();

function afClosePopup(uid) {
    var el = document.getElementById(uid);
    if (el) { el.classList.remove('af-popup--open'); el.setAttribute('aria-hidden','true'); }
}
</script>
@endpush
