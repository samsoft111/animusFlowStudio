@php
    $heading        = $content['heading']        ?? 'Chat with our AI assistant';
    $subtext        = $content['subtext']        ?? '';
    $welcomeMsg     = $content['welcome_message'] ?? 'Hi! How can I help you today?';
    $placeholder    = $content['placeholder']    ?? 'Type your question...';
    $suggestions    = $content['suggestions']    ?? [];
    $height         = $settings['height']        ?? 400;
    $style          = $settings['style']         ?? 'card';
    $showBranding   = $settings['show_branding'] ?? true;
    $uid            = 'ai-chat-' . $block->uuid;
@endphp
<section class="af-ai-chatbox af-ai-chatbox--{{ $style }}">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
            @if($subtext)<p data-af-field="subtext">{{ $subtext }}</p>@endif
        </div>
        @endif

        <div class="af-ai-chatbox__widget" id="{{ $uid }}" style="height:{{ (int)$height }}px">
            <div class="af-ai-chatbox__messages" id="{{ $uid }}-msgs"></div>

            @if(count($suggestions))
            <div class="af-ai-chatbox__suggestions" id="{{ $uid }}-sugg">
                @foreach($suggestions as $sugg)
                <button class="af-ai-chatbox__suggestion" data-msg="{{ $sugg }}">{{ $sugg }}</button>
                @endforeach
            </div>
            @endif

            <div class="af-ai-chatbox__input-row">
                <input type="text" id="{{ $uid }}-input" class="af-ai-chatbox__input"
                       placeholder="{{ $placeholder }}" autocomplete="off" maxlength="1000">
                <button id="{{ $uid }}-send" class="af-ai-chatbox__send">Send</button>
            </div>

            @if($showBranding)
            <div class="af-ai-chatbox__branding">Powered by AnimusFlow AI</div>
            @endif
        </div>
    </div>
</section>
@push('scripts')
<script>
(function(){
    var uid = '{{ $uid }}';
    var msgs = document.getElementById(uid+'-msgs');
    var input = document.getElementById(uid+'-input');
    var send = document.getElementById(uid+'-send');
    var sugg = document.getElementById(uid+'-sugg');
    var history = [];
    var busy = false;

    function addMsg(role, text) {
        var el = document.createElement('div');
        el.className = 'af-ai-chatbox__msg af-ai-chatbox__msg--' + role;
        el.textContent = text;
        msgs.appendChild(el);
        msgs.scrollTop = msgs.scrollHeight;
        return el;
    }
    function getVid() {
        var m = document.cookie.match(/af_vid=([^;]+)/);
        return m ? m[1] : '';
    }
    // Welcome
    addMsg('assistant', '{{ addslashes($welcomeMsg) }}');

    if (sugg) {
        sugg.querySelectorAll('.af-ai-chatbox__suggestion').forEach(function(btn){
            btn.addEventListener('click', function(){ doSend(btn.getAttribute('data-msg')); });
        });
    }

    async function doSend(msg) {
        if (!msg || busy) return;
        if (sugg) sugg.style.display = 'none';
        busy = true;
        send.disabled = true;
        addMsg('user', msg);
        var loadEl = addMsg('assistant', '…');
        history.push({role:'user',content:msg});
        try {
            var res = await fetch('/api/v1/chat', {
                method:'POST',
                headers:{'Content-Type':'application/json','Accept':'application/json'},
                body: JSON.stringify({message:msg, history:history.slice(-8), visitor_id:getVid()})
            });
            var data = await res.json();
            var reply = data.reply || (data.error ? 'Sorry: '+data.error : 'Something went wrong.');
            loadEl.textContent = reply;
            history.push({role:'assistant',content:reply});
        } catch(e) { loadEl.textContent = 'Connection error. Please try again.'; }
        busy = false; send.disabled = false;
    }
    send.addEventListener('click', function(){ var v=input.value.trim(); input.value=''; doSend(v); });
    input.addEventListener('keydown', function(e){ if(e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); var v=input.value.trim(); input.value=''; doSend(v); } });
})();
</script>
@endpush
