@php
    $heading = $content['heading'] ?? '';
    $items   = $content['items']   ?? [];
    $style   = $settings['style']  ?? 'default';
    $showIcons = $settings['show_platform_icons'] ?? true;
    $linkProfiles = $settings['link_to_profile']  ?? true;

    $platformColors = [
        'instagram'=>'#E1306C','x'=>'#000','facebook'=>'#1877F2','linkedin'=>'#0A66C2',
        'youtube'=>'#FF0000','tiktok'=>'#010101','discord'=>'#5865F2','github'=>'#333',
        'spotify'=>'#1DB954','twitch'=>'#9146FF','threads'=>'#101010','pinterest'=>'#E60023',
    ];
    $platformIcons = [
        'instagram'=>'📸','x'=>'𝕏','facebook'=>'f','linkedin'=>'in','youtube'=>'▶',
        'tiktok'=>'♪','discord'=>'🎮','github'=>'⌥','spotify'=>'♫','twitch'=>'📺',
        'threads'=>'@','pinterest'=>'P',
    ];
@endphp
<section class="af-social-counters af-social-counters--{{ $style }}">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
        </div>
        @endif
        <div class="af-social-counters__grid">
            @foreach($items as $i => $item)
            @php
                $platform = $item['platform'] ?? 'instagram';
                $count    = $item['count']    ?? '0';
                $label    = $item['label']    ?? 'followers';
                $url      = $item['url']      ?? '';
                $color    = $platformColors[$platform] ?? '#6366f1';
                $icon     = $platformIcons[$platform]  ?? '🔗';
            @endphp
            <div class="af-social-counters__item" data-af-item="{{ $i }}" style="--sc-color:{{ $color }}">
                @if($linkProfiles && $url)
                <a href="{{ $url }}" target="_blank" rel="noopener" class="af-social-counters__link">
                @endif
                @if($showIcons)<div class="af-social-counters__icon">{{ $icon }}</div>@endif
                <div class="af-social-counters__count" data-af-field="count">{{ $count }}</div>
                <div class="af-social-counters__label" data-af-field="label">{{ $label }}</div>
                @if($linkProfiles && $url)</a>@endif
            </div>
            @endforeach
        </div>
    </div>
</section>
