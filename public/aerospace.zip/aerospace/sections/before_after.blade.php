{{-- Block: before_after — Drag slider comparing two images --}}
@php
    $title       = $content['title'] ?? '';
    $before_img  = $content['before_img'] ?? '';
    $after_img   = $content['after_img'] ?? '';
    $before_label = $content['before_label'] ?? 'Before';
    $after_label  = $content['after_label'] ?? 'After';
    $dark        = ($settings['section_dark'] ?? false);
    $blockId     = 'ba-' . substr(md5(serialize($content)), 0, 8);
@endphp

<section class="af-section af-before-after{{ $dark ? ' af-section--dark' : '' }}">
    <div class="af-container">
        @if($title)<h2 class="af-section__title" data-af-field="title">{{ $title }}</h2>@endif
        <div class="af-ba__slider" id="{{ $blockId }}">
            <div class="af-ba__after">
                @if($after_img)<img src="{{ $after_img }}" alt="{{ $after_label }}" data-af-field="after_img">@endif
                <span class="af-ba__label af-ba__label--after">{{ $after_label }}</span>
            </div>
            <div class="af-ba__before" id="{{ $blockId }}_before">
                @if($before_img)<img src="{{ $before_img }}" alt="{{ $before_label }}" data-af-field="before_img">@endif
                <span class="af-ba__label af-ba__label--before">{{ $before_label }}</span>
            </div>
            <div class="af-ba__handle" id="{{ $blockId }}_handle">
                <span class="af-ba__handle-icon">&#x21c6;</span>
            </div>
        </div>
    </div>
</section>

@push('scripts')
<script>
(function(){
    var slider  = document.getElementById('{{ $blockId }}');
    var before  = document.getElementById('{{ $blockId }}_before');
    var handle  = document.getElementById('{{ $blockId }}_handle');
    if(!slider || !before || !handle) return;
    var dragging = false;
    function setPos(x){
        var rect = slider.getBoundingClientRect();
        var pct  = Math.max(0, Math.min(100, (x - rect.left) / rect.width * 100));
        before.style.width = pct + '%';
        handle.style.left  = pct + '%';
    }
    setPos(slider.getBoundingClientRect().left + slider.offsetWidth / 2);
    handle.addEventListener('mousedown', function(e){ dragging=true; e.preventDefault(); });
    handle.addEventListener('touchstart', function(){ dragging=true; }, {passive:true});
    document.addEventListener('mousemove', function(e){ if(dragging) setPos(e.clientX); });
    document.addEventListener('touchmove', function(e){ if(dragging) setPos(e.touches[0].clientX); }, {passive:true});
    document.addEventListener('mouseup', function(){ dragging=false; });
    document.addEventListener('touchend', function(){ dragging=false; });
})();
</script>
@endpush
