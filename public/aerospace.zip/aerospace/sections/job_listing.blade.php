@php
    $heading = $content['heading'] ?? 'Open positions';
    $subtext = $content['subtext'] ?? '';
    $items   = $content['items']   ?? [];
    $style   = $settings['style']  ?? 'list';
    $showFilters = $settings['show_filters'] ?? false;
    $departments = collect($items)->pluck('department')->filter()->unique()->values()->toArray();
@endphp
<section class="af-job-listing af-job-listing--{{ $style }}">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
            @if($subtext)<p data-af-field="subtext">{{ $subtext }}</p>@endif
        </div>
        @endif

        @if($showFilters && count($departments) > 1)
        <div class="af-job-listing__filters">
            <button class="af-job-filter is-active" data-dept="">All</button>
            @foreach($departments as $dept)
            <button class="af-job-filter" data-dept="{{ $dept }}">{{ $dept }}</button>
            @endforeach
        </div>
        @endif

        <div class="af-job-listing__list">
            @foreach($items as $i => $job)
            @php
                $title  = $job['title']      ?? '';
                $dept   = $job['department'] ?? '';
                $loc    = $job['location']   ?? '';
                $type   = $job['type']       ?? 'full-time';
                $desc   = $job['description_short'] ?? '';
                $url    = $job['apply_url']  ?? '#';
                $posted = $job['posted_at']  ?? '';
            @endphp
            <div class="af-job-listing__item" data-af-item="{{ $i }}" data-dept="{{ $dept }}">
                <div class="af-job-listing__info">
                    @if($title)<h3 class="af-job-listing__title" data-af-field="title">{{ $title }}</h3>@endif
                    <div class="af-job-listing__meta">
                        @if($dept)<span class="af-job-listing__dept">{{ $dept }}</span>@endif
                        @if($loc)<span>📍 {{ $loc }}</span>@endif
                        @if($type)<span class="af-job-listing__type">{{ $type }}</span>@endif
                        @if($posted)<time>{{ $posted }}</time>@endif
                    </div>
                    @if($desc)<p class="af-job-listing__desc" data-af-field="description_short">{{ $desc }}</p>@endif
                </div>
                <a href="{{ $url }}" class="af-btn af-btn--outline" target="_blank" rel="noopener">Apply →</a>
            </div>
            @endforeach
        </div>
    </div>
</section>
@if($showFilters)
@push('scripts')
<script>
document.querySelectorAll('.af-job-filter').forEach(function(btn){
    btn.addEventListener('click', function(){
        document.querySelectorAll('.af-job-filter').forEach(function(b){ b.classList.remove('is-active'); });
        btn.classList.add('is-active');
        var dept = btn.getAttribute('data-dept');
        document.querySelectorAll('.af-job-listing__item').forEach(function(item){
            item.style.display = (!dept || item.getAttribute('data-dept')===dept) ? '' : 'none';
        });
    });
});
</script>
@endpush
@endif
