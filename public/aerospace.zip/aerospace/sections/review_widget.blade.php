@php
    $heading      = $content['heading']       ?? '';
    $platform     = $content['platform']      ?? 'google';
    $rating       = $content['overall_rating'] ?? '5.0';
    $reviewCount  = $content['total_reviews'] ?? '';
    $badgeText    = $content['badge_text']    ?? 'Excellent';
    $embedCode    = $content['embed_code']    ?? '';
    $profileUrl   = $content['profile_url']   ?? '';
    $style        = $settings['style']        ?? 'badge';
    $showStars    = $settings['show_stars']   ?? true;
    $showCount    = $settings['show_count']   ?? true;
    $ratingFloat  = (float) $rating;
    $fullStars    = min(5, (int) floor($ratingFloat));
    $platformLabel = ucfirst($platform);
@endphp
<section class="af-review-widget af-review-widget--{{ $style }}">
    <div class="af-container">
        @if($heading)<div class="af-section-header"><h2 data-af-field="heading">{{ $heading }}</h2></div>@endif

        @if($embedCode)
        <div class="af-review-widget__embed" data-af-field="embed_code">{!! $embedCode !!}</div>
        @else
        <div class="af-review-widget__badge">
            <div class="af-review-widget__platform">{{ $platformLabel }}</div>
            @if($showStars)
            <div class="af-review-widget__stars">
                @for($s=0;$s<5;$s++)<span class="{{ $s < $fullStars ? 'af-star--full' : 'af-star--empty' }}">★</span>@endfor
            </div>
            @endif
            <div class="af-review-widget__score" data-af-field="overall_rating">{{ $rating }}</div>
            @if($badgeText)<div class="af-review-widget__badge-text" data-af-field="badge_text">{{ $badgeText }}</div>@endif
            @if($showCount && $reviewCount)<div class="af-review-widget__count" data-af-field="total_reviews">{{ $reviewCount }}</div>@endif
            @if($profileUrl)
            <a href="{{ $profileUrl }}" class="af-review-widget__link" target="_blank" rel="noopener">
                View reviews on {{ $platformLabel }} →
            </a>
            @endif
        </div>
        @endif
    </div>
</section>
