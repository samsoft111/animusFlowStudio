{{-- Block: richtext — renders arbitrary HTML (e.g. from a WYSIWYG) --}}
@php
    $html      = $content['html']           ?? '';
    $maxWidth  = $settings['max_width']     ?? 'normal';
@endphp

<div class="af-richtext af-richtext--{{ $maxWidth }}">
    <div class="af-container">
        <div class="af-richtext__body prose" data-af-field="html">
            {!! $html !!}
        </div>
    </div>
</div>
