@php
    $heading    = $content['heading']    ?? '';
    $platform   = $content['platform']  ?? 'instagram';
    $embedCode  = $content['embed_code'] ?? '';
    $username   = $content['username']  ?? '';
    $posts      = $content['posts']     ?? [];
    $layout     = $settings['layout']   ?? 'grid';
    $cols       = $settings['columns']  ?? 3;
    $showFollow = $settings['show_follow_btn'] ?? true;
    $followUrl  = $settings['follow_url'] ?? '#';
@endphp
<section class="af-social-feed">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
            @if($username)<p class="af-social-feed__handle">@<span data-af-field="username">{{ $username }}</span></p>@endif
        </div>
        @endif

        @if($embedCode)
        <div class="af-social-feed__embed" data-af-field="embed_code">{!! $embedCode !!}</div>
        @elseif(count($posts))
        <div class="af-social-feed__grid af-social-feed__grid--{{ $cols }}">
            @foreach($posts as $i => $post)
            @php $image=$post['image']??''; $caption=$post['caption']??''; $url=$post['url']??'#'; $likes=$post['likes']??''; @endphp
            <a href="{{ $url }}" class="af-social-feed__post" target="_blank" rel="noopener" data-af-item="{{ $i }}">
                @if($image)<img src="{{ $image }}" alt="{{ $caption }}" loading="lazy" data-af-field="image">@endif
                <div class="af-social-feed__overlay">
                    @if($caption)<p data-af-field="caption">{{ $caption }}</p>@endif
                    @if($likes)<span class="af-social-feed__likes">♥ {{ $likes }}</span>@endif
                </div>
            </a>
            @endforeach
        </div>
        @else
        <div class="af-social-feed__placeholder">
            <span>📷 Add an embed code or posts to display your {{ ucfirst($platform) }} feed</span>
        </div>
        @endif

        @if($showFollow && $followUrl && $followUrl !== '#')
        <div class="af-social-feed__follow">
            <a href="{{ $followUrl }}" class="af-btn af-btn--outline" target="_blank" rel="noopener">Follow on {{ ucfirst($platform) }}</a>
        </div>
        @endif
    </div>
</section>
