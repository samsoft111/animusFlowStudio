{{-- Block: video --}}
@php
    $url     = $content['url']     ?? '';
    $heading = $content['heading'] ?? '';
    $caption = $content['caption'] ?? '';
    $aspect  = $settings['aspect'] ?? '16/9';

    // Detect YouTube / Vimeo and convert to embed URL
    $embedUrl = $url;
    if (preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]+)/', $url, $m)) {
        $embedUrl = 'https://www.youtube-nocookie.com/embed/' . $m[1] . '?rel=0';
    } elseif (preg_match('/vimeo\.com\/(\d+)/', $url, $m)) {
        $embedUrl = 'https://player.vimeo.com/video/' . $m[1];
    }

    $isEmbed = ($embedUrl !== $url || str_contains($embedUrl, 'youtube') || str_contains($embedUrl, 'vimeo'));
    $aspectClass = str_replace('/', '-', $aspect); // "16-9"
@endphp

<section class="af-video">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
        </div>
        @endif

        <div class="af-video__wrapper af-ratio af-ratio--{{ $aspectClass }}">
            @if($isEmbed && $embedUrl)
                <iframe src="{{ $embedUrl }}" frameborder="0" allowfullscreen
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        title="{{ $heading ?: 'Video' }}"></iframe>
            @elseif($url)
                <video controls preload="metadata">
                    <source src="{{ $url }}" data-af-field="url">
                    Your browser does not support the video tag.
                </video>
            @else
                <div class="af-video__placeholder">▶ Video</div>
            @endif
        </div>

        @if($caption)
        <p class="af-video__caption" data-af-field="caption">{{ $caption }}</p>
        @endif
    </div>
</section>
