@php
    $c       = $block->content ?? [];
    $heading = $c['heading']     ?? '';
    $sub     = $c['subtext']     ?? '';
    $ph      = $c['placeholder'] ?? 'Enter your email address';
    $btnText = $c['button_text'] ?? 'Subscribe';
    $note    = $c['note']        ?? 'No spam. Unsubscribe at any time.';
    $dark    = ($block->settings['style'] ?? 'dark') === 'dark';
@endphp

<section class="af-section {{ $dark ? 'af-section--dark' : 'af-section--muted' }}">
    <div class="af-container">
        <div class="af-newsletter">
            @if($heading)
                <h2 class="af-newsletter__heading" data-af-field="heading">{{ $heading }}</h2>
            @endif
            @if($sub)
                <p class="af-newsletter__sub" data-af-field="subtext">{{ $sub }}</p>
            @endif
            <form class="af-newsletter__form"
                  id="af-nl-form-{{ $block->uuid ?? '' }}"
                  novalidate
                  aria-label="Newsletter subscription">
                <input type="email"
                       class="af-newsletter__input"
                       placeholder="{{ $ph }}"
                       required
                       autocomplete="email"
                       aria-label="Email address">
                <button type="submit"
                        class="af-btn af-btn--primary"
                        data-af-field="button_text">{{ $btnText }}</button>
            </form>
            @if($note)
                <p class="af-newsletter__note" data-af-field="note">{{ $note }}</p>
            @endif
            <p class="af-newsletter__feedback"
               id="af-nl-msg-{{ $block->uuid ?? '' }}"
               aria-live="polite"></p>
        </div>
    </div>
</section>

@push('scripts')
<script>
(function () {
    var form = document.getElementById('af-nl-form-{{ $block->uuid ?? '' }}');
    var msg  = document.getElementById('af-nl-msg-{{ $block->uuid ?? '' }}');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        var input = form.querySelector('input[type="email"]');
        if (!input.value.trim() || !input.validity.valid) {
            msg.textContent = 'Please enter a valid email address.';
            msg.style.color = '#ef4444';
            return;
        }
        // Placeholder submit — integrate with your mailing service here
        msg.textContent = 'Thank you! You\'re subscribed.';
        msg.style.color = '#10b981';
        form.reset();
    });
})();
</script>
@endpush
