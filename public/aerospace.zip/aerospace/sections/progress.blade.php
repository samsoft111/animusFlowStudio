{{-- Block: progress bars --}}
@php
    $heading = $content['heading'] ?? '';
    $items   = $content['items']   ?? [];
    $style   = $settings['style']  ?? 'default';
@endphp

<section class="af-progress af-progress--{{ $style }}">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
        </div>
        @endif

        <div class="af-progress__list">
            @foreach($items as $i => $item)
            @php
                $label = $item['label'] ?? '';
                $value = min(100, max(0, (int) ($item['value'] ?? 0)));
            @endphp
            <div class="af-progress__item" data-af-item="{{ $i }}">
                <div class="af-progress__meta">
                    <span class="af-progress__label" data-af-field="label">{{ $label }}</span>
                    <span class="af-progress__pct">{{ $value }}%</span>
                </div>
                <div class="af-progress__track">
                    <div class="af-progress__bar" style="width:{{ $value }}%" data-af-field="value"></div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
