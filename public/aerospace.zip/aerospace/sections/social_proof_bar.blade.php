@php
    $items = $content['items'] ?? [];
    $style = $settings['style'] ?? 'bar';

    $platformIcons = [
        'google'=>'G','trustpilot'=>'★','instagram'=>'📸','appstore'=>'🍎',
        'capterra'=>'C','g2'=>'G2','facebook'=>'f','linkedin'=>'in','youtube'=>'▶',
    ];
@endphp
<div class="af-social-proof-bar af-social-proof-bar--{{ $style }}">
    <div class="af-container">
        <div class="af-social-proof-bar__items">
            @foreach($items as $i => $item)
            @php
                $type     = $item['type']     ?? 'stat';
                $platform = $item['platform'] ?? '';
                $value    = $item['value']    ?? '';
                $label    = $item['label']    ?? '';
                $url      = $item['url']      ?? '';
                $icon     = $platform ? ($platformIcons[$platform] ?? '⭐') : '⭐';
            @endphp
            <div class="af-social-proof-bar__item af-social-proof-bar__item--{{ $type }}" data-af-item="{{ $i }}">
                @if($i > 0)<span class="af-social-proof-bar__sep" aria-hidden="true">·</span>@endif
                @if($url)<a href="{{ $url }}" target="_blank" rel="noopener">@endif
                @if($type === 'rating')
                <span class="af-social-proof-bar__stars">★★★★★</span>
                @else
                <span class="af-social-proof-bar__icon">{{ $icon }}</span>
                @endif
                <strong class="af-social-proof-bar__value" data-af-field="value">{{ $value }}</strong>
                <span class="af-social-proof-bar__label" data-af-field="label">{{ $label }}</span>
                @if($url)</a>@endif
            </div>
            @endforeach
        </div>
    </div>
</div>
