@php
    $heading       = $content['heading']        ?? '';
    $items         = $content['items']          ?? [];
    $cols          = $settings['columns']       ?? 3;
    $style         = $settings['style']         ?? 'card';
    $showBadge     = $settings['show_badge']    ?? true;
@endphp
<section class="af-product-card af-product-card--{{ $style }}">
    <div class="af-container">
        @if($heading)<div class="af-section-header"><h2 data-af-field="heading">{{ $heading }}</h2></div>@endif
        <div class="af-product-card__grid af-product-card__grid--{{ $cols }}">
            @foreach($items as $i => $product)
            @php
                $image        = $product['image']          ?? '';
                $badge        = $product['badge']          ?? '';
                $name         = $product['name']           ?? '';
                $description  = $product['description']    ?? '';
                $price        = $product['price']          ?? '';
                $origPrice    = $product['original_price'] ?? '';
                $features     = $product['features']       ?? [];
                $ctaText      = $product['cta_text']       ?? 'Buy now';
                $ctaUrl       = $product['cta_url']        ?? '#';
            @endphp
            <div class="af-product-card__card" data-af-item="{{ $i }}">
                @if($image)
                <div class="af-product-card__image">
                    <img src="{{ $image }}" alt="{{ $name }}" loading="lazy" data-af-field="image">
                    @if($showBadge && $badge)<span class="af-product-card__badge" data-af-field="badge">{{ $badge }}</span>@endif
                </div>
                @endif
                <div class="af-product-card__body">
                    @if($name)<h3 class="af-product-card__name" data-af-field="name">{{ $name }}</h3>@endif
                    @if($description)<p class="af-product-card__desc" data-af-field="description">{{ $description }}</p>@endif
                    @if(count($features))
                    <ul class="af-product-card__features">
                        @foreach($features as $feat)<li>✓ {{ $feat }}</li>@endforeach
                    </ul>
                    @endif
                    <div class="af-product-card__pricing">
                        @if($origPrice)<del class="af-product-card__orig" data-af-field="original_price">{{ $origPrice }}</del>@endif
                        @if($price)<strong class="af-product-card__price" data-af-field="price">{{ $price }}</strong>@endif
                    </div>
                    <a href="{{ $ctaUrl }}" class="af-btn af-product-card__cta" data-af-field="cta_text">{{ $ctaText }}</a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
