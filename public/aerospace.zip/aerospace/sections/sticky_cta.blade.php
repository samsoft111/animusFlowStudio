@php
    $text       = $content['text']         ?? '';
    $ctaText    = $content['cta_text']     ?? '';
    $ctaUrl     = $content['cta_url']      ?? '#';
    $dismissText= $content['dismiss_text'] ?? '';
    $position   = $settings['position']     ?? 'bottom';
    $showAfter  = $settings['show_after_scroll'] ?? true;
    $scrollPct  = (int)($settings['scroll_percent'] ?? 30);
    $bg         = $settings['bg']           ?? 'primary';
    $uid        = 'stcta-' . $block->uuid;
@endphp
<div class="af-sticky-cta af-sticky-cta--{{ $position }} af-sticky-cta--{{ $bg }} {{ $showAfter ? 'af-sticky-cta--hidden' : '' }}"
     id="{{ $uid }}">
    <div class="af-container">
        <div class="af-sticky-cta__inner">
            @if($text)<span class="af-sticky-cta__text" data-af-field="text">{{ $text }}</span>@endif
            @if($ctaText)<a href="{{ $ctaUrl }}" class="af-sticky-cta__btn" data-af-field="cta_text">{{ $ctaText }}</a>@endif
            @if($dismissText)
            <button class="af-sticky-cta__dismiss" onclick="document.getElementById('{{ $uid }}').remove()">{{ $dismissText }}</button>
            @endif
        </div>
    </div>
</div>
@if($showAfter)
@push('scripts')
<script>
(function(){
    var el = document.getElementById('{{ $uid }}');
    if (!el) return;
    window.addEventListener('scroll', function(){
        var pct = (window.scrollY / Math.max(1, document.body.scrollHeight - window.innerHeight)) * 100;
        if (pct >= {{ $scrollPct }}) el.classList.remove('af-sticky-cta--hidden');
    }, { passive: true });
})();
</script>
@endpush
@endif
