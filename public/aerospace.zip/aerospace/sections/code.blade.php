{{-- Block: code --}}
@php
    $heading  = $content['heading']  ?? '';
    $code     = $content['code']     ?? '';
    $language = $content['language'] ?? 'plaintext';
    $filename = $content['filename'] ?? '';
    $uid      = 'code-' . $block->uuid;
@endphp

<section class="af-code">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
        </div>
        @endif

        <div class="af-code__block" id="{{ $uid }}">
            @if($filename)
            <div class="af-code__header">
                <span class="af-code__filename" data-af-field="filename">{{ $filename }}</span>
                <button class="af-code__copy" onclick="afCopyCode('{{ $uid }}')">Copy</button>
            </div>
            @else
            <button class="af-code__copy af-code__copy--bare" onclick="afCopyCode('{{ $uid }}')">Copy</button>
            @endif
            <pre class="af-code__pre"><code class="language-{{ $language }}" data-af-field="code">{{ $code }}</code></pre>
        </div>
    </div>
</section>

@push('scripts')
<script>
function afCopyCode(id) {
    var block = document.getElementById(id);
    if (!block) return;
    var code = block.querySelector('code');
    if (!code) return;
    navigator.clipboard.writeText(code.innerText).then(function () {
        var btn = block.querySelector('.af-code__copy');
        if (btn) { btn.textContent = 'Copied!'; setTimeout(function () { btn.textContent = 'Copy'; }, 2000); }
    });
}
</script>
@endpush
