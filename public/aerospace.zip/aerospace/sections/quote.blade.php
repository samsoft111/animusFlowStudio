{{-- Block: quote --}}
@php
    $quote  = $content['quote']  ?? '';
    $author = $content['author'] ?? '';
    $source = $content['source'] ?? '';
    $style  = $settings['style'] ?? 'large';
@endphp

<section class="af-quote af-quote--{{ $style }}">
    <div class="af-container">
        <figure class="af-quote__figure">
            <blockquote data-af-field="quote">&ldquo;{{ $quote }}&rdquo;</blockquote>
            @if($author || $source)
            <figcaption class="af-quote__caption">
                @if($author)<strong data-af-field="author">{{ $author }}</strong>@endif
                @if($source)<cite data-af-field="source">, {{ $source }}</cite>@endif
            </figcaption>
            @endif
        </figure>
    </div>
</section>
