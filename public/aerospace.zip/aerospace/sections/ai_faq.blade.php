@php
    $heading    = $content['heading']    ?? 'Frequently Asked Questions';
    $items      = $content['items']      ?? [];
    $style      = $settings['style']     ?? 'accordion';
    $uid        = 'aifaq-' . $block->uuid;
    $isPreview  = $preview ?? false;
@endphp
<section class="af-ai-faq af-ai-faq--{{ $style }}" id="{{ $uid }}">
    <div class="af-container">
        <div class="af-section-header">
            <span class="af-ai-badge">✨ AI FAQ</span>
            <h2 data-af-field="heading">{{ $heading }}</h2>
        </div>
        <div class="af-ai-faq__list">
            @foreach($items as $i => $item)
            @php
                $q    = $item['question']     ?? '';
                $a    = $item['answer']       ?? '';
                $conf = $item['confidence']   ?? 'high';
                $by   = $item['generated_by'] ?? 'ai';
            @endphp
            <div class="af-ai-faq__item {{ $i===0?'is-open':'' }}" data-af-item="{{ $i }}">
                <button class="af-ai-faq__q" aria-expanded="{{ $i===0?'true':'false' }}"
                        onclick="this.closest('.af-ai-faq__item').classList.toggle('is-open');
                                 this.setAttribute('aria-expanded', this.closest('.af-ai-faq__item').classList.contains('is-open'))">
                    <span data-af-field="question">{{ $q }}</span>
                    @if($isPreview && $by==='ai')
                    <span class="af-ai-faq__badge af-ai-faq__badge--{{ $conf }}" title="AI confidence: {{ $conf }}">🤖</span>
                    @endif
                    <span class="af-ai-faq__arrow">›</span>
                </button>
                <div class="af-ai-faq__a"><p data-af-field="answer">{{ $a }}</p></div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@push('scripts')
<script>
document.getElementById('{{ $uid }}')?.querySelectorAll('.af-ai-faq__q').forEach(function(btn){
    btn.addEventListener('click', function(){
        var item = btn.closest('.af-ai-faq__item');
        var open = item.classList.contains('is-open');
        document.getElementById('{{ $uid }}').querySelectorAll('.af-ai-faq__item').forEach(function(el){ el.classList.remove('is-open'); el.querySelector('.af-ai-faq__q').setAttribute('aria-expanded','false'); });
        if (!open) { item.classList.add('is-open'); btn.setAttribute('aria-expanded','true'); }
    });
});
</script>
@endpush
