<section class="af-section {{ ($settings['bg_mode'] ?? '') === 'dark' ? 'af-section--dark' : '' }} {{ ($settings['bg_mode'] ?? '') === 'muted' ? 'af-section--muted' : '' }}" id="{{ $settings['html_id'] ?? '' }}">
    <div class="af-container">
        <!-- Mount Point para a "Ilha" Vue -->
        <div data-vue-component="InteractiveCounter" data-props="{{ json_encode(['content' => $content, 'settings' => $settings]) }}"></div>
    </div>
</section>
