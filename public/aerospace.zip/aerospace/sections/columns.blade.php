{{-- Block: columns --}}
@php
    $items    = $content['items']    ?? [];
    $cols     = $settings['columns'] ?? 2;
    $valign   = $settings['valign']  ?? 'top';
    $gap      = $settings['gap']     ?? 'normal';
    $heading  = $content['heading']  ?? '';
    $subtext  = $content['subtext']  ?? '';
@endphp

<section class="af-columns af-columns--cols-{{ $cols }} af-columns--gap-{{ $gap }} af-columns--align-{{ $valign }}">
    <div class="af-container">
        @if($heading)
            <div class="af-section-header">
                <h2 data-af-field="heading">{{ $heading }}</h2>
                @if($subtext)<p data-af-field="subtext">{{ $subtext }}</p>@endif
            </div>
        @endif

        <div class="af-columns__grid">
            @foreach($items as $i => $item)
            @php
                $eyebrow  = $item['eyebrow']     ?? '';
                $itmHead  = $item['heading']      ?? '';
                $body     = $item['body']         ?? '';
                $image    = $item['image']        ?? '';
                $imageAlt = $item['image_alt']    ?? ($itmHead ?: 'image');
                $btnText  = $item['button_text']  ?? '';
                $btnUrl   = $item['button_url']   ?? '#';
            @endphp
            <div class="af-columns__item" data-af-item="{{ $i }}">
                @if($image)
                <div class="af-columns__image">
                    <img src="{{ $image }}" alt="{{ $imageAlt }}" data-af-field="image" loading="lazy">
                </div>
                @endif
                <div class="af-columns__body">
                    @if($eyebrow)<span class="af-eyebrow" data-af-field="eyebrow">{{ $eyebrow }}</span>@endif
                    @if($itmHead)<h3 data-af-field="heading">{{ $itmHead }}</h3>@endif
                    @if($body)<p data-af-field="body">{{ $body }}</p>@endif
                    @if($btnText)
                    <a href="{{ $btnUrl }}" class="af-btn af-btn--outline" data-af-field="button_text">{{ $btnText }}</a>
                    @endif
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
