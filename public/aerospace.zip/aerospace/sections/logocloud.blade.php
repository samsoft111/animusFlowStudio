{{-- Block: logocloud --}}
@php
    $heading   = $content['heading']    ?? '';
    $logos     = $content['logos']      ?? [];
    $grayscale = $settings['grayscale'] ?? true;
@endphp

<section class="af-logocloud">
    <div class="af-container">
        @if($heading)
        <p class="af-logocloud__heading" data-af-field="heading">{{ $heading }}</p>
        @endif
        <div class="af-logocloud__track {{ $grayscale ? 'af-logocloud--grayscale' : '' }}">
            @foreach($logos as $i => $logo)
            @php
                $src = $logo['src'] ?? '';
                $alt = $logo['alt'] ?? 'logo';
                $url = $logo['url'] ?? '';
            @endphp
            <div class="af-logocloud__item" data-af-item="{{ $i }}">
                @if($url)<a href="{{ $url }}" target="_blank" rel="noopener">@endif
                @if($src)
                    <img src="{{ $src }}" alt="{{ $alt }}" data-af-field="src" loading="lazy">
                @else
                    <span class="af-logocloud__placeholder">Logo</span>
                @endif
                @if($url)</a>@endif
            </div>
            @endforeach
        </div>
    </div>
</section>
