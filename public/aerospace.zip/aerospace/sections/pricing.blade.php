@php
    $c       = $block->content ?? [];
    $heading = $c['heading'] ?? '';
    $sub     = $c['subtext'] ?? '';
    $plans   = $c['plans']   ?? [];
    $muted   = ($block->settings['background'] ?? 'white') === 'muted';
@endphp

<section class="af-section {{ $muted ? 'af-section--muted' : '' }}">
    <div class="af-container">
        @if($heading)
            <h2 class="af-pricing__heading" data-af-field="heading">{{ $heading }}</h2>
        @endif
        @if($sub)
            <p class="af-pricing__sub" data-af-field="subtext">{{ $sub }}</p>
        @endif
        <div class="af-pricing__grid">
            @forelse($plans as $i => $plan)
                @php $featured = !empty($plan['highlighted']); @endphp
                <div class="af-pricing-card{{ $featured ? ' af-pricing-card--featured' : '' }}" data-af-item="{{ $i }}">
                    @if(!empty($plan['badge']))
                        <div class="af-pricing-card__badge" data-af-field="badge">{{ $plan['badge'] }}</div>
                    @endif
                    <div class="af-pricing-card__name" data-af-field="name">{{ $plan['name'] ?? '' }}</div>
                    <div class="af-pricing-card__price">
                        <span class="af-pricing-card__amount" data-af-field="price">{{ $plan['price'] ?? '' }}</span>
                        @if(!empty($plan['period']))
                            <span class="af-pricing-card__period" data-af-field="period">{{ $plan['period'] }}</span>
                        @endif
                    </div>
                    @if(!empty($plan['description']))
                        <p class="af-pricing-card__desc" data-af-field="description">{{ $plan['description'] }}</p>
                    @endif
                    @if(!empty($plan['features']))
                        <ul class="af-pricing-card__features">
                            @foreach((array) $plan['features'] as $feature)
                                <li>{{ $feature }}</li>
                            @endforeach
                        </ul>
                    @endif
                    @if(!empty($plan['cta_text']))
                        <a href="{{ $plan['cta_url'] ?? '#' }}"
                           class="af-btn {{ $featured ? 'af-btn--primary' : 'af-btn--outline' }}"
                           data-af-field="cta_text">{{ $plan['cta_text'] }}</a>
                    @endif
                </div>
            @empty
                <p style="color:var(--text-muted);text-align:center;grid-column:1/-1">No pricing plans added yet.</p>
            @endforelse
        </div>
    </div>
</section>
