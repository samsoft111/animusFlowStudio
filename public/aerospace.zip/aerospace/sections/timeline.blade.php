{{-- Block: timeline --}}
@php
    $heading = $content['heading'] ?? '';
    $items   = $content['items']   ?? [];
@endphp

<section class="af-timeline">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
        </div>
        @endif

        <div class="af-timeline__track">
            @foreach($items as $i => $item)
            @php
                $date  = $item['date']  ?? '';
                $title = $item['title'] ?? '';
                $text  = $item['text']  ?? '';
            @endphp
            <div class="af-timeline__item {{ $i % 2 === 0 ? 'af-timeline__item--left' : 'af-timeline__item--right' }}" data-af-item="{{ $i }}">
                <div class="af-timeline__dot"></div>
                <div class="af-timeline__card">
                    @if($date)<time class="af-timeline__date" data-af-field="date">{{ $date }}</time>@endif
                    @if($title)<h3 data-af-field="title">{{ $title }}</h3>@endif
                    @if($text)<p data-af-field="text">{{ $text }}</p>@endif
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
