{{-- Block: anchor_nav — Sticky in-page navigation with scrollspy --}}
@php
    $items  = $content['items'] ?? [];
    $sticky = ($content['sticky'] ?? true);
    $dark   = ($settings['section_dark'] ?? false);
    $blockId = 'an-' . substr(md5(serialize($content)), 0, 8);
@endphp

@if(count($items))
<nav class="af-anchor-nav{{ $sticky ? ' af-anchor-nav--sticky' : '' }}{{ $dark ? ' af-anchor-nav--dark' : '' }}"
     id="{{ $blockId }}" aria-label="Page sections">
    <div class="af-container">
        <ul class="af-anchor-nav__list">
            @foreach($items as $ii => $item)
            @php
                $label  = $item['label'] ?? '';
                $target = $item['target'] ?? '';
            @endphp
            <li class="af-anchor-nav__item" data-af-item="{{ $ii }}">
                <a href="#{{ $target }}" class="af-anchor-nav__link" data-target="{{ $target }}">{{ $label }}</a>
            </li>
            @endforeach
        </ul>
    </div>
</nav>

@push('scripts')
<script>
(function(){
    var nav   = document.getElementById('{{ $blockId }}');
    if(!nav) return;
    var links = Array.from(nav.querySelectorAll('.af-anchor-nav__link'));
    var targets = links.map(function(l){ return document.getElementById(l.dataset.target); });
    var obs = new IntersectionObserver(function(entries){
        entries.forEach(function(e){
            if(e.isIntersecting){
                var id = e.target.id;
                links.forEach(function(l){ l.classList.toggle('af-anchor-nav__link--active', l.dataset.target === id); });
            }
        });
    }, { rootMargin: '-30% 0px -60% 0px' });
    targets.forEach(function(t){ if(t) obs.observe(t); });
    links.forEach(function(l){
        l.addEventListener('click', function(e){
            e.preventDefault();
            var t = document.getElementById(l.dataset.target);
            if(t) t.scrollIntoView({ behavior:'smooth', block:'start' });
        });
    });
})();
</script>
@endpush
@endif
