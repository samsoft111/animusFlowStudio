{{-- Block: events_list — Upcoming events / calendar feed --}}
@php
    $title     = $content['title'] ?? '';
    $events    = $content['events'] ?? [];
    $show_past = ($content['show_past'] ?? false);
    $layout    = $content['layout'] ?? 'list'; // list | cards
    $dark      = ($settings['section_dark'] ?? false);
    $now       = now()->timestamp;
@endphp

@php
    if(!$show_past){
        $events = array_values(array_filter($events, function($ev) use($now){
            $ts = isset($ev['date']) ? strtotime($ev['date']) : 0;
            return $ts >= $now - 86400;
        }));
    }
@endphp

<section class="af-section af-events-list{{ $dark ? ' af-section--dark' : '' }}">
    <div class="af-container">
        @if($title)<h2 class="af-section__title" data-af-field="title">{{ $title }}</h2>@endif
        @if(count($events))
        <div class="af-events{{ $layout === 'cards' ? ' af-events--cards' : '' }}">
            @foreach($events as $ei => $ev)
            @php
                $evTitle   = $ev['title'] ?? '';
                $evDate    = $ev['date'] ?? '';
                $evTime    = $ev['time'] ?? '';
                $evLoc     = $ev['location'] ?? '';
                $evDesc    = $ev['description'] ?? '';
                $evUrl     = $ev['url'] ?? '';
                $evTag     = $ev['tag'] ?? '';
                $ts        = $evDate ? strtotime($evDate) : 0;
                $isPast    = $ts > 0 && $ts < $now - 86400;
            @endphp
            <div class="af-event{{ $isPast ? ' af-event--past' : '' }}" data-af-item="{{ $ei }}">
                @if($ts)
                <div class="af-event__date">
                    <span class="af-event__month">{{ strtoupper(date('M', $ts)) }}</span>
                    <span class="af-event__day">{{ date('d', $ts) }}</span>
                </div>
                @endif
                <div class="af-event__body">
                    @if($evTag)<span class="af-event__tag">{{ $evTag }}</span>@endif
                    <h3 class="af-event__title" data-af-field="title">{{ $evTitle }}</h3>
                    @if($evTime || $evLoc)
                    <p class="af-event__meta">
                        @if($evTime)<span>&#128336; {{ $evTime }}</span>@endif
                        @if($evLoc)<span>&#128205; {{ $evLoc }}</span>@endif
                    </p>
                    @endif
                    @if($evDesc)<p class="af-event__desc">{{ $evDesc }}</p>@endif
                    @if($evUrl)<a href="{{ $evUrl }}" class="af-btn af-btn--ghost af-btn--sm" target="_blank" rel="noopener">Register &rarr;</a>@endif
                </div>
            </div>
            @endforeach
        </div>
        @else
        <p class="af-events__empty">No upcoming events.</p>
        @endif
    </div>
</section>
