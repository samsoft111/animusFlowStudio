@php
    $heading       = $content['heading']       ?? 'In summary';
    $generatedText = $content['generated_text'] ?? '';
    $bullets       = $content['bullets']       ?? [];
    $generatedBy   = $content['generated_by']  ?? 'manual';
    $lastUpdated   = $content['last_updated_at'] ?? '';
    $style         = $settings['style']        ?? 'card';
    $showBullets   = $settings['show_bullets'] ?? true;
    $maxBullets    = (int)($settings['max_bullets'] ?? 5);
    $bullets       = array_slice($bullets, 0, $maxBullets);
@endphp
<section class="af-ai-summary af-ai-summary--{{ $style }}">
    <div class="af-container">
        <div class="af-ai-summary__inner">
            <div class="af-ai-summary__header">
                <span class="af-ai-badge">✨ AI Summary</span>
                <h2 data-af-field="heading">{{ $heading }}</h2>
            </div>
            @if($generatedText)
            <div class="af-ai-summary__text" data-af-field="generated_text">
                {!! nl2br(e($generatedText)) !!}
            </div>
            @endif
            @if($showBullets && count($bullets))
            <ul class="af-ai-summary__bullets">
                @foreach($bullets as $bullet)
                @php $icon = $bullet['icon'] ?? '✓'; $text = $bullet['text'] ?? ''; @endphp
                <li><span class="af-ai-summary__bullet-icon">{{ $icon }}</span> {{ $text }}</li>
                @endforeach
            </ul>
            @endif
            @if($lastUpdated)
            <div class="af-ai-summary__meta">
                <span class="af-ai-badge af-ai-badge--sm">{{ $generatedBy === 'ai' ? '🤖 AI generated' : '✏️ Manual' }}</span>
                <time>{{ $lastUpdated }}</time>
            </div>
            @endif
        </div>
    </div>
</section>
