@php
    $heading     = $content['heading']       ?? 'Contact us';
    $subtext     = $content['subtext']       ?? '';
    $fields      = $content['fields']        ?? [];
    $submitText  = $content['submit_text']   ?? 'Send';
    $successMsg  = $content['success_message'] ?? 'Thank you! Your message has been received.';
    $layout      = $settings['layout']       ?? '1col';
    $style       = $settings['style']        ?? 'card';
    $uid         = 'form-' . $block->uuid;
@endphp
<section class="af-form-builder af-form-builder--{{ $style }}">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
            @if($subtext)<p data-af-field="subtext">{{ $subtext }}</p>@endif
        </div>
        @endif

        <div class="af-form-builder__wrap">
            <form class="af-form-builder__form af-form-builder__form--{{ $layout }}"
                  id="{{ $uid }}" data-success="{{ $successMsg }}" novalidate>
                @csrf
                <input type="hidden" name="block_uuid" value="{{ $block->uuid }}">

                @foreach($fields as $f)
                @php
                    $type    = $f['type']        ?? 'text';
                    $label   = $f['label']       ?? '';
                    $key     = Str::slug($label ?: 'field', '_');
                    $ph      = $f['placeholder'] ?? '';
                    $req     = !empty($f['required']);
                    $opts    = $f['options']     ?? [];
                @endphp
                <div class="af-form-builder__field {{ $layout==='2col' ? 'af-form-builder__field--half' : '' }}">
                    @if($label)<label class="af-form-builder__label">{{ $label }}@if($req)<span>*</span>@endif</label>@endif

                    @if($type === 'textarea')
                    <textarea name="{{ $key }}" class="af-form-builder__input" placeholder="{{ $ph }}"
                              rows="4" {{ $req?'required':'' }}></textarea>

                    @elseif($type === 'select')
                    <select name="{{ $key }}" class="af-form-builder__input" {{ $req?'required':'' }}>
                        <option value="">{{ $ph ?: 'Select...' }}</option>
                        @foreach($opts as $opt)
                        <option value="{{ $opt }}">{{ $opt }}</option>
                        @endforeach
                    </select>

                    @elseif($type === 'checkbox')
                    <label class="af-form-builder__checkbox">
                        <input type="checkbox" name="{{ $key }}" value="1" {{ $req?'required':'' }}>
                        <span>{{ $ph }}</span>
                    </label>

                    @elseif($type === 'radio')
                    <div class="af-form-builder__radios">
                        @foreach($opts as $opt)
                        <label class="af-form-builder__radio">
                            <input type="radio" name="{{ $key }}" value="{{ $opt }}" {{ $req?'required':'' }}>
                            <span>{{ $opt }}</span>
                        </label>
                        @endforeach
                    </div>

                    @else
                    <input type="{{ $type }}" name="{{ $key }}" class="af-form-builder__input"
                           placeholder="{{ $ph }}" {{ $req?'required':'' }}>
                    @endif
                </div>
                @endforeach

                <div class="af-form-builder__submit">
                    <button type="submit" class="af-btn">{{ $submitText }}</button>
                    <span class="af-form-builder__status" id="{{ $uid }}-status"></span>
                </div>
            </form>
        </div>
    </div>
</section>
@push('scripts')
<script>
(function(){
    var form = document.getElementById('{{ $uid }}');
    if (!form) return;
    form.addEventListener('submit', async function(e){
        e.preventDefault();
        var btn = form.querySelector('[type=submit]');
        var status = document.getElementById('{{ $uid }}-status');
        btn.disabled = true; btn.textContent = 'Sending…';
        try {
            var data = new FormData(form);
            var res = await fetch('/submit-form', { method:'POST', body: data,
                headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'} });
            var json = await res.json();
            if (json.success) {
                form.innerHTML = '<p class="af-form-builder__success">' + (form.getAttribute('data-success') || 'Thank you!') + '</p>';
            } else {
                status.textContent = json.message || 'An error occurred.';
                btn.disabled=false; btn.textContent='{{ $submitText }}';
            }
        } catch(e) { status.textContent='Connection error.'; btn.disabled=false; btn.textContent='{{ addslashes($submitText) }}'; }
    });
})();
</script>
@endpush
