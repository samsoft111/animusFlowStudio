{{-- Block: cards --}}
@php
    $heading = $content['heading'] ?? '';
    $items   = $content['items']   ?? [];
    $cols    = $settings['columns'] ?? 3;
@endphp

<section class="af-cards af-cards--cols-{{ $cols }}">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
        </div>
        @endif

        <div class="af-cards__grid">
            @foreach($items as $i => $card)
            @php
                $image    = $card['image']     ?? '';
                $tag      = $card['tag']       ?? '';
                $title    = $card['title']     ?? '';
                $text     = $card['text']      ?? '';
                $link     = $card['link']      ?? '#';
                $linkText = $card['link_text'] ?? 'Read more';
            @endphp
            <article class="af-cards__card" data-af-item="{{ $i }}">
                @if($image)
                <div class="af-cards__image">
                    <img src="{{ $image }}" alt="{{ $title }}" data-af-field="image" loading="lazy">
                </div>
                @endif
                <div class="af-cards__body">
                    @if($tag)<span class="af-cards__tag" data-af-field="tag">{{ $tag }}</span>@endif
                    @if($title)<h3 class="af-cards__title" data-af-field="title">{{ $title }}</h3>@endif
                    @if($text)<p class="af-cards__text" data-af-field="text">{{ $text }}</p>@endif
                    @if($linkText)
                    <a href="{{ $link }}" class="af-cards__link" data-af-field="link_text">{{ $linkText }} →</a>
                    @endif
                </div>
            </article>
            @endforeach
        </div>
    </div>
</section>
