@php
    $heading         = $content['heading']          ?? '';
    $connectionUuid  = $content['connection_uuid']  ?? '';
    $toolName        = $content['tool_name']         ?? '';
    $inputParams     = $content['input_params']      ?? '{}';
    $outputLayout    = $content['output_layout']     ?? 'text';
    $loadingText     = $content['loading_text']      ?? 'Loading…';
    $errorText       = $content['error_text']        ?? 'Could not load content.';
    $blockId         = 'mcp-' . ($block->uuid ?? uniqid());

    // Validate JSON params — fall back to empty object if invalid
    $parsedParams = [];
    if ($inputParams) {
        $decoded = json_decode($inputParams, true);
        if (is_array($decoded)) {
            $parsedParams = $decoded;
        }
    }

    $hasConfig = $connectionUuid && $toolName;
@endphp

<section class="af-mcp-block" id="{{ $blockId }}" data-block-type="mcp_block">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 class="af-mcp-block__heading">{{ $heading }}</h2>
        </div>
        @endif

        <div class="af-mcp-block__body"
             data-mcp-connection="{{ $connectionUuid }}"
             data-mcp-tool="{{ $toolName }}"
             data-mcp-params="{{ e(json_encode($parsedParams)) }}"
             data-mcp-layout="{{ $outputLayout }}"
             data-mcp-loading="{{ e($loadingText) }}"
             data-mcp-error="{{ e($errorText) }}">

            @if($hasConfig)
            {{-- Loading state — replaced by JS once content loads --}}
            <div class="af-mcp-block__loading">
                <div class="af-mcp-spinner"></div>
                <span>{{ $loadingText }}</span>
            </div>
            @else
            {{-- No configuration yet --}}
            <div class="af-mcp-block__empty">
                <span>🔌</span>
                <p>MCP block not configured. Open the editor to connect a service.</p>
            </div>
            @endif
        </div>
    </div>
</section>

@once
<script>
(function () {
    'use strict';

    // ── Renderer per output layout ────────────────────────────────────────────

    function renderText(result) {
        const text = typeof result === 'string' ? result : JSON.stringify(result, null, 2);
        // Basic markdown-to-HTML: bold, italic, code, newlines
        return '<div class="af-mcp-text">' + escapeHtml(text)
            .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.+?)\*/g,     '<em>$1</em>')
            .replace(/`(.+?)`/g,       '<code>$1</code>')
            .replace(/\n/g,            '<br>')
            + '</div>';
    }

    function renderList(result) {
        const items = Array.isArray(result) ? result : [result];
        return '<ul class="af-mcp-list">' + items.map(i =>
            '<li>' + escapeHtml(typeof i === 'object' ? JSON.stringify(i) : String(i)) + '</li>'
        ).join('') + '</ul>';
    }

    function renderCards(result) {
        const items = Array.isArray(result) ? result : [result];
        const cards = items.map(item => {
            if (typeof item === 'object' && item !== null) {
                const title = item.title || item.name || item.heading || '';
                const text  = item.text  || item.description || item.content || item.body || '';
                const link  = item.url   || item.link || item.href || '';
                return `<div class="af-mcp-card">
                    ${title ? `<div class="af-mcp-card__title">${escapeHtml(String(title))}</div>` : ''}
                    ${text  ? `<div class="af-mcp-card__text">${escapeHtml(String(text))}</div>`   : ''}
                    ${link  ? `<a class="af-mcp-card__link" href="${escapeHtml(String(link))}" target="_blank">View →</a>` : ''}
                </div>`;
            }
            return `<div class="af-mcp-card">${escapeHtml(String(item))}</div>`;
        });
        return '<div class="af-mcp-cards">' + cards.join('') + '</div>';
    }

    function renderTable(result) {
        const rows = Array.isArray(result) ? result : [result];
        if (!rows.length) return '<p>No data.</p>';

        const keys = typeof rows[0] === 'object' && rows[0] !== null
            ? Object.keys(rows[0])
            : ['value'];

        const header = '<tr>' + keys.map(k => `<th>${escapeHtml(k)}</th>`).join('') + '</tr>';
        const body   = rows.map(row => {
            const cells = keys.map(k => {
                const val = typeof row === 'object' ? (row[k] ?? '') : row;
                return `<td>${escapeHtml(String(val))}</td>`;
            }).join('');
            return '<tr>' + cells + '</tr>';
        }).join('');

        return `<div class="af-mcp-table-wrap"><table class="af-mcp-table"><thead>${header}</thead><tbody>${body}</tbody></table></div>`;
    }

    function renderRaw(result) {
        const json = typeof result === 'string' ? result : JSON.stringify(result, null, 2);
        return '<pre class="af-mcp-raw"><code>' + escapeHtml(json) + '</code></pre>';
    }

    function escapeHtml(str) {
        return String(str)
            .replace(/&/g,  '&amp;')
            .replace(/</g,  '&lt;')
            .replace(/>/g,  '&gt;')
            .replace(/"/g,  '&quot;');
    }

    const RENDERERS = { text: renderText, list: renderList, cards: renderCards, table: renderTable, raw: renderRaw };

    // ── Block loader ──────────────────────────────────────────────────────────

    async function loadBlock(el) {
        const connUuid = el.dataset.mcpConnection;
        const toolName = el.dataset.mcpTool;
        const layout   = el.dataset.mcpLayout   || 'text';
        const errText  = el.dataset.mcpError    || 'Could not load content.';

        if (!connUuid || !toolName) return;

        let args = {};
        try { args = JSON.parse(el.dataset.mcpParams || '{}'); } catch {}

        try {
            const res  = await fetch('/api/v1/mcp/invoke', {
                method:  'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                body:    JSON.stringify({ connection_uuid: connUuid, tool_name: toolName, arguments: args }),
            });
            const data = await res.json();

            if (data.ok) {
                const render = RENDERERS[layout] || renderText;
                el.innerHTML = render(data.result);
                el.classList.add('af-mcp-block__body--loaded');
            } else {
                el.innerHTML = `<div class="af-mcp-block__error">${escapeHtml(data.error || errText)}</div>`;
            }
        } catch (e) {
            el.innerHTML = `<div class="af-mcp-block__error">${escapeHtml(errText)}</div>`;
        }
    }

    // Initialise all MCP blocks on the page
    function init() {
        document.querySelectorAll('[data-mcp-connection]').forEach(el => {
            if (el.dataset.mcpConnection && el.dataset.mcpTool) {
                loadBlock(el);
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
</script>
@endonce
