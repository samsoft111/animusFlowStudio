@php
    $c       = $block->content ?? [];
    $heading = $c['heading'] ?? '';
    $items   = $c['items']   ?? [];
    $muted   = ($block->settings['background'] ?? 'white') === 'muted';
@endphp

<section class="af-section {{ $muted ? 'af-section--muted' : '' }}">
    <div class="af-container">
        @if($heading)
            <h2 class="af-faq__heading" data-af-field="heading">{{ $heading }}</h2>
        @endif
        <div class="af-faq__list">
            @forelse($items as $i => $item)
                <div class="af-faq-item" data-af-item="{{ $i }}">
                    <button class="af-faq-item__question" aria-expanded="false">
                        <span data-af-field="question">{{ $item['question'] ?? '' }}</span>
                        <span class="af-faq-item__icon" aria-hidden="true">+</span>
                    </button>
                    <div class="af-faq-item__answer" role="region">
                        <p data-af-field="answer">{{ $item['answer'] ?? '' }}</p>
                    </div>
                </div>
            @empty
                <p style="color:var(--text-muted);text-align:center">No FAQ items added yet.</p>
            @endforelse
        </div>
    </div>
</section>

@push('scripts')
<script>
(function () {
    document.querySelectorAll('.af-faq-item__question').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var item   = btn.closest('.af-faq-item');
            var isOpen = btn.getAttribute('aria-expanded') === 'true';

            // Close all open items
            document.querySelectorAll('.af-faq-item--open').forEach(function (el) {
                el.classList.remove('af-faq-item--open');
                el.querySelector('.af-faq-item__question').setAttribute('aria-expanded', 'false');
            });

            if (!isOpen) {
                item.classList.add('af-faq-item--open');
                btn.setAttribute('aria-expanded', 'true');
            }
        });
    });
})();
</script>
@endpush
