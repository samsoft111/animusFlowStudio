@php
    $heading   = $content['heading'] ?? '';
    $text      = $content['text']    ?? '';
    $shareUrl  = $content['url']     ?? '';
    $platforms = $settings['platforms'] ?? ['x','facebook','linkedin','whatsapp','email','copy_link'];
    $style     = $settings['style']  ?? 'buttons';
    $size      = $settings['size']   ?? 'md';
    $uid       = 'share-' . $block->uuid;

    $platformDef = [
        'facebook'   => ['label'=>'Facebook',  'icon'=>'f',   'color'=>'#1877F2',
                         'url'=>'https://www.facebook.com/sharer/sharer.php?u={url}'],
        'x'          => ['label'=>'X',         'icon'=>'𝕏',   'color'=>'#000000',
                         'url'=>'https://x.com/intent/tweet?url={url}&text={text}'],
        'linkedin'   => ['label'=>'LinkedIn',  'icon'=>'in',  'color'=>'#0A66C2',
                         'url'=>'https://www.linkedin.com/sharing/share-offsite/?url={url}'],
        'whatsapp'   => ['label'=>'WhatsApp',  'icon'=>'💬',  'color'=>'#25D366',
                         'url'=>'https://wa.me/?text={text}+{url}'],
        'telegram'   => ['label'=>'Telegram',  'icon'=>'✈',   'color'=>'#2CA5E0',
                         'url'=>'https://t.me/share/url?url={url}&text={text}'],
        'email'      => ['label'=>'Email',     'icon'=>'✉',   'color'=>'#6366f1',
                         'url'=>'mailto:?subject={text}&body={url}'],
        'pinterest'  => ['label'=>'Pinterest', 'icon'=>'P',   'color'=>'#E60023',
                         'url'=>'https://pinterest.com/pin/create/button/?url={url}&description={text}'],
        'reddit'     => ['label'=>'Reddit',    'icon'=>'r',   'color'=>'#FF4500',
                         'url'=>'https://www.reddit.com/submit?url={url}&title={text}'],
        'copy_link'  => ['label'=>'Copy link', 'icon'=>'🔗',  'color'=>'#64748b', 'url'=>''],
    ];
@endphp
<section class="af-social-share af-social-share--{{ $style }} af-social-share--{{ $size }}" id="{{ $uid }}">
    <div class="af-container">
        @if($heading)
        <p class="af-social-share__heading" data-af-field="heading">{{ $heading }}</p>
        @endif
        <div class="af-social-share__btns">
            @foreach($platforms as $p)
            @if(isset($platformDef[$p]))
            @php $def=$platformDef[$p]; @endphp
            @if($p === 'copy_link')
            <button class="af-share-btn" style="--share-color:{{ $def['color'] }}"
                    onclick="afShareCopy('{{ $uid }}', '{{ addslashes($shareUrl) }}')"
                    data-label="{{ $def['label'] }}">
                <span>{{ $def['icon'] }}</span>
                @if($style !== 'icons')<span>{{ $def['label'] }}</span>@endif
            </button>
            @else
            @php
                $finalUrl = str_replace(['{url}','{text}'], [urlencode($shareUrl ?: ''), urlencode($text)], $def['url']);
            @endphp
            <a href="{{ $finalUrl }}" class="af-share-btn" target="_blank" rel="noopener"
               style="--share-color:{{ $def['color'] }}" data-label="{{ $def['label'] }}">
                <span>{{ $def['icon'] }}</span>
                @if($style !== 'icons')<span>{{ $def['label'] }}</span>@endif
            </a>
            @endif
            @endif
            @endforeach
        </div>
        <div class="af-social-share__feedback" id="{{ $uid }}-feedback"></div>
    </div>
</section>
@push('scripts')
<script>
function afShareCopy(uid, url) {
    var finalUrl = url || window.location.href;
    navigator.clipboard.writeText(finalUrl).then(function() {
        var fb = document.getElementById(uid + '-feedback');
        if (fb) { fb.textContent = '✓ Link copied!'; setTimeout(function(){ fb.textContent=''; }, 2500); }
    });
}
</script>
@endpush
