@php
    $text        = $content['text']         ?? 'We use cookies to improve your experience. By continuing, you agree to our cookie policy.';
    $acceptText  = $content['accept_text']  ?? 'Accept all';
    $declineText = $content['decline_text'] ?? 'Decline';
    $privacyUrl  = $content['privacy_url']  ?? '';
    $position    = $settings['position']    ?? 'bottom';
    $style       = $settings['style']       ?? 'banner';
    $persistDismiss = $settings['persist_dismiss'] ?? true;
    $uid         = 'cookie-' . $block->uuid;
@endphp
<div class="af-cookie-banner af-cookie-banner--{{ $position }} af-cookie-banner--{{ $style }}"
     id="{{ $uid }}" role="dialog" aria-label="Cookie consent" aria-hidden="true">
    <div class="af-container">
        <div class="af-cookie-banner__inner">
            <p class="af-cookie-banner__text" data-af-field="text">
                {!! $text !!}
                @if($privacyUrl)
                <a href="{{ $privacyUrl }}" target="_blank" rel="noopener">Privacy policy</a>.
                @endif
            </p>
            <div class="af-cookie-banner__actions">
                <button class="af-btn af-cookie-banner__accept" onclick="afCookieConsent('{{ $uid }}', true, {{ $persistDismiss?'true':'false' }})">
                    {{ $acceptText }}
                </button>
                <button class="af-btn af-btn--ghost af-cookie-banner__decline" onclick="afCookieConsent('{{ $uid }}', false, {{ $persistDismiss?'true':'false' }})">
                    {{ $declineText }}
                </button>
            </div>
        </div>
    </div>
</div>
@push('scripts')
<script>
(function(){
    var uid = '{{ $uid }}';
    var key = 'af_cookie_consent_' + uid;
    var persist = {{ $persistDismiss ? 'true' : 'false' }};
    if (persist && localStorage.getItem(key)) return;
    var el = document.getElementById(uid);
    if (el) { el.setAttribute('aria-hidden','false'); el.classList.add('af-cookie-banner--visible'); }
})();
function afCookieConsent(uid, accepted, persist) {
    var el = document.getElementById(uid);
    if (el) { el.classList.remove('af-cookie-banner--visible'); el.setAttribute('aria-hidden','true'); }
    if (persist) localStorage.setItem('af_cookie_consent_' + uid, accepted ? '1' : '0');
    document.dispatchEvent(new CustomEvent('af:cookieConsent', { detail: { accepted: accepted } }));
}
</script>
@endpush
