{{-- Block: icongrid --}}
@php
    $heading = $content['heading'] ?? '';
    $items   = $content['items']   ?? [];
    $cols    = $settings['columns'] ?? 4;
    $style   = $settings['style']   ?? 'minimal';
@endphp

<section class="af-icongrid af-icongrid--{{ $style }} af-icongrid--cols-{{ $cols }}">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
        </div>
        @endif

        <div class="af-icongrid__grid">
            @foreach($items as $i => $item)
            @php
                $icon  = $item['icon']  ?? '✦';
                $label = $item['label'] ?? '';
                $text  = $item['text']  ?? '';
            @endphp
            <div class="af-icongrid__item" data-af-item="{{ $i }}">
                <div class="af-icongrid__icon" data-af-field="icon">{{ $icon }}</div>
                @if($label)<h4 class="af-icongrid__label" data-af-field="label">{{ $label }}</h4>@endif
                @if($text)<p class="af-icongrid__text" data-af-field="text">{{ $text }}</p>@endif
            </div>
            @endforeach
        </div>
    </div>
</section>
