{{-- Block: data_table — Responsive sortable table --}}
@php
    $title   = $content['title'] ?? '';
    $headers = $content['headers'] ?? [];
    $rows    = $content['rows'] ?? [];
    $sortable = ($content['sortable'] ?? false);
    $striped  = ($content['striped'] ?? true);
    $dark    = ($settings['section_dark'] ?? false);
    $blockId = 'dt-' . substr(md5(serialize($content)), 0, 8);
@endphp

@if(count($headers) || count($rows))
<section class="af-section af-data-table{{ $dark ? ' af-section--dark' : '' }}">
    <div class="af-container">
        @if($title)<h2 class="af-section__title" data-af-field="title">{{ $title }}</h2>@endif
        <div class="af-dt__wrap">
            <table class="af-dt__table{{ $striped ? ' af-dt__table--striped' : '' }}" id="{{ $blockId }}">
                @if(count($headers))
                <thead>
                    <tr>
                        @foreach($headers as $hi => $h)
                        <th data-col="{{ $hi }}" class="{{ $sortable ? 'af-dt__sortable' : '' }}">{{ $h }}@if($sortable)<span class="af-dt__sort-icon">&#x2195;</span>@endif</th>
                        @endforeach
                    </tr>
                </thead>
                @endif
                <tbody>
                    @foreach($rows as $ri => $row)
                    <tr data-af-item="{{ $ri }}">
                        @foreach((array)$row as $cell)
                        <td>{{ $cell }}</td>
                        @endforeach
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</section>
@endif

@if($sortable)
@push('scripts')
<script>
(function(){
    var tbl = document.getElementById('{{ $blockId }}');
    if(!tbl) return;
    tbl.querySelectorAll('th.af-dt__sortable').forEach(function(th){
        th.style.cursor='pointer';
        th.addEventListener('click', function(){
            var col = parseInt(th.dataset.col);
            var tbody = tbl.querySelector('tbody');
            var rows = Array.from(tbody.querySelectorAll('tr'));
            var asc = th.dataset.dir !== 'asc';
            th.dataset.dir = asc ? 'asc' : 'desc';
            rows.sort(function(a,b){
                var av = (a.cells[col]||{}).textContent||'';
                var bv = (b.cells[col]||{}).textContent||'';
                var n = parseFloat(av) - parseFloat(bv);
                return asc ? (isNaN(n) ? av.localeCompare(bv) : n) : (isNaN(n) ? bv.localeCompare(av) : -n);
            });
            rows.forEach(function(r){ tbody.appendChild(r); });
        });
    });
})();
</script>
@endpush
@endif
