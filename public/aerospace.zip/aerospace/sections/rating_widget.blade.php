@php
    $heading    = $content['heading']       ?? 'Was this page helpful?';
    $thankYou   = $content['thank_you_message'] ?? 'Thank you for your feedback!';
    $labels     = $content['labels']        ?? ['Poor','Fair','Good','Very good','Excellent'];
    $style      = $settings['style']        ?? 'stars';
    $showCount  = $settings['show_count']   ?? true;
    $uid        = 'rating-' . $block->uuid;
@endphp
<section class="af-rating-widget af-rating-widget--{{ $style }}">
    <div class="af-container">
        <div class="af-rating-widget__inner" id="{{ $uid }}">
            <h3 class="af-rating-widget__heading" data-af-field="heading">{{ $heading }}</h3>
            <div class="af-rating-widget__stars">
                @for($s=1;$s<=5;$s++)
                <button class="af-rating-widget__star" data-score="{{ $s }}"
                        title="{{ $labels[$s-1] ?? $s }}" aria-label="{{ $labels[$s-1] ?? $s }} stars">
                    @if($style === 'emoji')
                    {{ ['😞','😐','🙂','😊','🤩'][$s-1] }}
                    @elseif($style === 'thumbs')
                    {{ $s >= 4 ? '👍' : '👎' }}
                    @else ★
                    @endif
                </button>
                @endfor
            </div>
            <div class="af-rating-widget__aggregate" id="{{ $uid }}-agg" style="display:none"></div>
        </div>
    </div>
</section>
@push('scripts')
<script>
(function(){
    var uid = '{{ $uid }}';
    var container = document.getElementById(uid);
    var agg = document.getElementById(uid+'-agg');
    var storageKey = 'af_rating_' + uid;

    if (localStorage.getItem(storageKey)) {
        container.querySelector('.af-rating-widget__stars').style.display='none';
        agg.style.display='block';
        agg.textContent = 'You already rated this. Thank you!';
        return;
    }

    container.querySelectorAll('.af-rating-widget__star').forEach(function(btn){
        btn.addEventListener('mouseover', function(){
            var score = parseInt(btn.getAttribute('data-score'));
            container.querySelectorAll('.af-rating-widget__star').forEach(function(b,i){ b.classList.toggle('is-hover', i < score); });
        });
        btn.addEventListener('mouseleave', function(){
            container.querySelectorAll('.af-rating-widget__star').forEach(function(b){ b.classList.remove('is-hover'); });
        });
        btn.addEventListener('click', async function(){
            var score = parseInt(btn.getAttribute('data-score'));
            container.querySelector('.af-rating-widget__stars').style.opacity='.5';
            try {
                var vid = (document.cookie.match(/af_vid=([^;]+)/)||[])[1]||'';
                var res = await fetch('/api/v1/ratings', {
                    method:'POST',
                    headers:{'Content-Type':'application/json','Accept':'application/json'},
                    body: JSON.stringify({block_uuid: uid.replace('rating-',''), score: score, visitor_id: vid})
                });
                var data = await res.json();
                localStorage.setItem(storageKey, score);
                container.querySelector('.af-rating-widget__stars').style.display='none';
                agg.style.display='block';
                agg.innerHTML = '{{ addslashes($thankYou) }}'
                    + (data.average ? ' <strong>Average: '+parseFloat(data.average).toFixed(1)+'/5</strong> ('+data.count+' ratings)' : '');
            } catch(e) { container.querySelector('.af-rating-widget__stars').style.opacity='1'; }
        });
    });
})();
</script>
@endpush
