@php
    $heading = $content['heading'] ?? '';
    $subtext = $content['subtext'] ?? '';
    $links   = $content['links']   ?? [];
    $style   = $settings['style']  ?? 'cards';
    $showFollowers = $settings['show_followers'] ?? false;
    $size    = $settings['size']   ?? 'md';

    $platformData = [
        'instagram' => ['name'=>'Instagram','color'=>'#E1306C'],
        'x'         => ['name'=>'X (Twitter)','color'=>'#000000'],
        'facebook'  => ['name'=>'Facebook','color'=>'#1877F2'],
        'linkedin'  => ['name'=>'LinkedIn','color'=>'#0A66C2'],
        'youtube'   => ['name'=>'YouTube','color'=>'#FF0000'],
        'tiktok'    => ['name'=>'TikTok','color'=>'#010101'],
        'pinterest' => ['name'=>'Pinterest','color'=>'#E60023'],
        'whatsapp'  => ['name'=>'WhatsApp','color'=>'#25D366'],
        'telegram'  => ['name'=>'Telegram','color'=>'#2CA5E0'],
        'github'    => ['name'=>'GitHub','color'=>'#333333'],
        'discord'   => ['name'=>'Discord','color'=>'#5865F2'],
        'spotify'   => ['name'=>'Spotify','color'=>'#1DB954'],
        'twitch'    => ['name'=>'Twitch','color'=>'#9146FF'],
        'threads'   => ['name'=>'Threads','color'=>'#101010'],
    ];
    $platformIcons = [
        'instagram'=>'📸','x'=>'𝕏','facebook'=>'f','linkedin'=>'in',
        'youtube'=>'▶','tiktok'=>'♪','pinterest'=>'P','whatsapp'=>'💬',
        'telegram'=>'✈','github'=>'⌥','discord'=>'🎮','spotify'=>'♫',
        'twitch'=>'📺','threads'=>'@',
    ];
@endphp
<section class="af-social-links af-social-links--{{ $style }} af-social-links--{{ $size }}">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
            @if($subtext)<p data-af-field="subtext">{{ $subtext }}</p>@endif
        </div>
        @endif
        <div class="af-social-links__grid">
            @foreach($links as $i => $link)
            @php
                $platform  = $link['platform']  ?? 'instagram';
                $url       = $link['url']        ?? '#';
                $followers = $link['followers']  ?? '';
                $label     = $link['label']      ?? ($platformData[$platform]['name'] ?? $platform);
                $color     = $platformData[$platform]['color'] ?? '#6366f1';
                $icon      = $platformIcons[$platform] ?? '🔗';
            @endphp
            <a href="{{ $url }}" class="af-social-links__item" target="_blank" rel="noopener"
               data-af-item="{{ $i }}" style="--sl-color:{{ $color }}">
                <span class="af-social-links__icon">{{ $icon }}</span>
                <span class="af-social-links__name" data-af-field="label">{{ $label }}</span>
                @if($showFollowers && $followers)
                <span class="af-social-links__followers" data-af-field="followers">{{ $followers }}</span>
                @endif
            </a>
            @endforeach
        </div>
    </div>
</section>
