@php
    $heading = $content['heading'] ?? 'Recommended for you';
    $segments = $content['segments'] ?? [];
    $style   = $settings['style']  ?? 'cards';
    $maxItems= (int)($settings['max_items'] ?? 3);

    // $segment is passed from PageRenderController; default first_visit
    $seg = $segment ?? 'first_visit';
    $segData = $segments[$seg] ?? $segments['default'] ?? $segments['first_visit'] ?? null;
    $segHeading = $segData['heading'] ?? $heading;
    $items = array_slice($segData['items'] ?? [], 0, $maxItems);
@endphp
@if(count($items))
<section class="af-ai-reco af-ai-reco--{{ $style }}">
    <div class="af-container">
        <div class="af-section-header">
            <span class="af-ai-badge">✨ AI</span>
            <h2>{{ $segHeading }}</h2>
        </div>
        <div class="af-ai-reco__grid">
            @foreach($items as $i => $item)
            @php
                $title   = $item['title']    ?? '';
                $text    = $item['text']     ?? '';
                $image   = $item['image']    ?? '';
                $link    = $item['link']     ?? '#';
                $ctaText = $item['cta_text'] ?? 'Learn more';
            @endphp
            <div class="af-ai-reco__item" data-af-item="{{ $i }}">
                @if($image)<div class="af-ai-reco__img"><img src="{{ $image }}" alt="{{ $title }}" loading="lazy"></div>@endif
                <div class="af-ai-reco__body">
                    @if($title)<h3 data-af-field="title">{{ $title }}</h3>@endif
                    @if($text)<p data-af-field="text">{{ $text }}</p>@endif
                    <a href="{{ $link }}" class="af-btn af-btn--sm af-btn--outline">{{ $ctaText }}</a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif
