{{-- Block: image --}}
@php
    $src       = $content['src']     ?? '';
    $alt       = $content['alt']     ?? '';
    $caption   = $content['caption'] ?? '';
    $link      = $content['link']    ?? '';
    $size      = $settings['size']      ?? 'large';
    $alignment = $settings['alignment'] ?? 'center';
    $rounded   = $settings['rounded']   ?? false;
    $shadow    = $settings['shadow']    ?? false;

    $classes = 'af-image-block af-image-block--' . $size . ' af-image-block--' . $alignment;
    if ($rounded) $classes .= ' af-image-block--rounded';
    if ($shadow)  $classes .= ' af-image-block--shadow';
@endphp

<div class="{{ $classes }}">
    <div class="af-container">
        <figure class="af-image-block__figure">
            @if($link)<a href="{{ $link }}">@endif
            @if($src)
                <img src="{{ $src }}" alt="{{ $alt }}" data-af-field="src" loading="lazy">
            @else
                <div class="af-image-block__placeholder">🖼️ Image</div>
            @endif
            @if($link)</a>@endif
            @if($caption)
                <figcaption data-af-field="caption">{{ $caption }}</figcaption>
            @endif
        </figure>
    </div>
</div>
