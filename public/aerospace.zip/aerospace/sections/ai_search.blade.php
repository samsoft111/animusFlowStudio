@php
    $heading     = $content['heading']     ?? '';
    $placeholder = $content['placeholder'] ?? 'Search...';
    $noResults   = $content['no_results_text'] ?? 'No results found. Try a different search.';
    $suggestions = $content['suggestions'] ?? [];
    $style       = $settings['style']      ?? 'bar';
    $uid         = 'aisrch-' . $block->uuid;
@endphp
<section class="af-ai-search af-ai-search--{{ $style }}">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
        </div>
        @endif

        <div class="af-ai-search__box" id="{{ $uid }}">
            <div class="af-ai-search__input-row">
                <span class="af-ai-search__icon">🔍</span>
                <input type="search" class="af-ai-search__input" id="{{ $uid }}-input"
                       placeholder="{{ $placeholder }}" autocomplete="off" autocorrect="off">
                <button class="af-ai-search__btn" id="{{ $uid }}-btn">Search</button>
            </div>
            @if(count($suggestions))
            <div class="af-ai-search__suggestions">
                @foreach($suggestions as $s)
                <button class="af-ai-search__sugg" data-q="{{ $s }}">{{ $s }}</button>
                @endforeach
            </div>
            @endif
            <div class="af-ai-search__results" id="{{ $uid }}-results" style="display:none"></div>
        </div>
    </div>
</section>
@push('scripts')
<script>
(function(){
    var uid = '{{ $uid }}';
    var input = document.getElementById(uid+'-input');
    var btn   = document.getElementById(uid+'-btn');
    var results = document.getElementById(uid+'-results');
    var noResults = {{ json_encode($noResults) }};
    var timer;

    function doSearch(q) {
        q = (q||'').trim();
        if (!q) { results.style.display='none'; return; }
        results.style.display='block';
        results.innerHTML = '<div class="af-ai-search__loading">Searching…</div>';
        fetch('/api/v1/search?q=' + encodeURIComponent(q))
            .then(function(r){ return r.json(); })
            .then(function(data){
                var items = data.results || [];
                if (!items.length) { results.innerHTML='<p class="af-ai-search__no-results">'+noResults+'</p>'; return; }
                results.innerHTML = items.map(function(item){
                    return '<a href="'+item.url+'" class="af-ai-search__result"><strong>'+item.title+'</strong><span>'+item.excerpt+'</span></a>';
                }).join('');
            })
            .catch(function(){ results.innerHTML='<p class="af-ai-search__no-results">Search unavailable.</p>'; });
    }

    input.addEventListener('input', function(){ clearTimeout(timer); timer=setTimeout(function(){ doSearch(input.value); }, 350); });
    btn.addEventListener('click', function(){ doSearch(input.value); });
    input.addEventListener('keydown', function(e){ if(e.key==='Enter'){ e.preventDefault(); doSearch(input.value); } });
    document.querySelectorAll('#'+uid+' .af-ai-search__sugg').forEach(function(b){
        b.addEventListener('click', function(){ input.value=b.getAttribute('data-q'); doSearch(input.value); });
    });
})();
</script>
@endpush
