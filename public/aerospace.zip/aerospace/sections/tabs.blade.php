{{-- Block: tabs --}}
@php
    $items = $content['items'] ?? [];
    $uid   = 'tabs-' . $block->uuid;
@endphp

<section class="af-tabs" id="{{ $uid }}">
    <div class="af-container">
        <div class="af-tabs__nav" role="tablist">
            @foreach($items as $i => $tab)
            <button class="af-tabs__tab {{ $i === 0 ? 'is-active' : '' }}"
                    role="tab"
                    data-tab="{{ $uid }}-{{ $i }}"
                    aria-selected="{{ $i === 0 ? 'true' : 'false' }}"
                    data-af-item="{{ $i }}"
                    data-af-field="label">
                {{ $tab['label'] ?? 'Tab ' . ($i + 1) }}
            </button>
            @endforeach
        </div>

        <div class="af-tabs__panels">
            @foreach($items as $i => $tab)
            <div class="af-tabs__panel {{ $i === 0 ? 'is-active' : '' }}"
                 id="{{ $uid }}-{{ $i }}"
                 role="tabpanel">
                <div data-af-field="content">{!! $tab['content'] ?? '' !!}</div>
            </div>
            @endforeach
        </div>
    </div>
</section>

@push('scripts')
<script>
(function () {
    var container = document.getElementById('{{ $uid }}');
    if (!container) return;
    container.querySelectorAll('.af-tabs__tab').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var panelId = btn.getAttribute('data-tab');
            container.querySelectorAll('.af-tabs__tab').forEach(function (t) {
                t.classList.remove('is-active');
                t.setAttribute('aria-selected', 'false');
            });
            container.querySelectorAll('.af-tabs__panel').forEach(function (p) { p.classList.remove('is-active'); });
            btn.classList.add('is-active');
            btn.setAttribute('aria-selected', 'true');
            var panel = container.querySelector('#' + panelId);
            if (panel) panel.classList.add('is-active');
        });
    });
})();
</script>
@endpush
