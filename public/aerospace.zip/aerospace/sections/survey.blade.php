@php
    $question   = $content['question']    ?? 'What do you think?';
    $options    = $content['options']     ?? [];
    $showResults= $content['show_results'] ?? true;
    $style      = $settings['style']      ?? 'buttons';
    $allowMulti = $settings['allow_multiple'] ?? false;
    $uid        = 'survey-' . $block->uuid;
    $blockUuid  = $block->uuid;
@endphp
<section class="af-survey af-survey--{{ $style }}">
    <div class="af-container">
        <div class="af-survey__inner" id="{{ $uid }}">
            <h3 class="af-survey__question" data-af-field="question">{{ $question }}</h3>
            <div class="af-survey__options">
                @foreach($options as $i => $opt)
                @php $text = $opt['text'] ?? $opt; $votes = $opt['votes'] ?? 0; @endphp
                <button class="af-survey__option" data-index="{{ $i }}" data-af-item="{{ $i }}">
                    <span class="af-survey__option-text" data-af-field="text">{{ $text }}</span>
                </button>
                @endforeach
            </div>
            <div class="af-survey__results" id="{{ $uid }}-results" style="display:none"></div>
        </div>
    </div>
</section>
@push('scripts')
<script>
(function(){
    var uid = '{{ $uid }}';
    var blockUuid = '{{ $blockUuid }}';
    var showResults = {{ $showResults ? 'true' : 'false' }};
    var storageKey = 'af_survey_' + uid;
    var container = document.getElementById(uid);
    var resultsEl = document.getElementById(uid + '-results');

    function showResultsUI(totals) {
        if (!showResults || !resultsEl) return;
        var total = totals.reduce(function(a,b){ return a+b; }, 0);
        container.querySelector('.af-survey__options').style.display='none';
        resultsEl.style.display='block';
        resultsEl.innerHTML = totals.map(function(count, i){
            var opts = container.querySelectorAll('.af-survey__option');
            var label = opts[i] ? opts[i].querySelector('.af-survey__option-text').textContent : ('Option '+(i+1));
            var pct = total > 0 ? Math.round((count/total)*100) : 0;
            return '<div class="af-survey__result-item"><span>'+label+'</span>'
                 + '<div class="af-survey__result-bar"><div style="width:'+pct+'%"></div></div>'
                 + '<span>'+pct+'%</span></div>';
        }).join('');
    }

    if (localStorage.getItem(storageKey)) {
        try { showResultsUI(JSON.parse(localStorage.getItem(storageKey + '_totals') || '[]')); } catch(e){}
        return;
    }

    container.querySelectorAll('.af-survey__option').forEach(function(btn){
        btn.addEventListener('click', async function(){
            var idx = parseInt(btn.getAttribute('data-index'));
            container.querySelectorAll('.af-survey__option').forEach(function(b){ b.disabled=true; });
            try {
                var res = await fetch('/api/v1/surveys/'+blockUuid+'/vote', {
                    method:'POST',
                    headers:{'Content-Type':'application/json','Accept':'application/json'},
                    body: JSON.stringify({option_index: idx})
                });
                var data = await res.json();
                localStorage.setItem(storageKey, '1');
                if (data.totals) { localStorage.setItem(storageKey+'_totals', JSON.stringify(data.totals)); showResultsUI(data.totals); }
            } catch(e) { container.querySelectorAll('.af-survey__option').forEach(function(b){ b.disabled=false; }); }
        });
    });
})();
</script>
@endpush
