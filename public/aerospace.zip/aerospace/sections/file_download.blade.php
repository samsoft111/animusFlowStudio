@php
    $heading    = $content['heading']     ?? '';
    $description= $content['description'] ?? '';
    $fileUrl    = $content['file_url']    ?? '';
    $fileName   = $content['file_name']   ?? 'Download';
    $fileSize   = $content['file_size']   ?? '';
    $fileType   = $content['file_type']   ?? 'pdf';
    $btnText    = $content['button_text'] ?? 'Download';
    $style      = $settings['style']      ?? 'card';
    $track      = $settings['track_downloads'] ?? true;

    $typeIcons  = ['pdf'=>'📄','zip'=>'🗜','docx'=>'📝','xlsx'=>'📊','csv'=>'📋','mp4'=>'🎬'];
    $icon       = $typeIcons[$fileType] ?? '📁';
    $uid        = 'fdl-' . $block->uuid;
@endphp
<div class="af-file-download af-file-download--{{ $style }}" id="{{ $uid }}">
    <div class="af-container">
        <div class="af-file-download__card">
            <div class="af-file-download__icon">{{ $icon }}</div>
            <div class="af-file-download__info">
                @if($heading)<h3 class="af-file-download__name" data-af-field="heading">{{ $heading ?: $fileName }}</h3>@endif
                @if($description)<p class="af-file-download__desc" data-af-field="description">{{ $description }}</p>@endif
                @if($fileSize)<span class="af-file-download__size">{{ $fileSize }}</span>@endif
            </div>
            @if($fileUrl)
            <a href="{{ $fileUrl }}" class="af-btn af-file-download__btn"
               download="{{ $fileName }}"
               onclick="{{ $track ? 'afTrackDownload(\''.addslashes($fileName).'\',\''.addslashes($fileUrl).'\')' : '' }}">
                ↓ {{ $btnText }}
            </a>
            @else
            <button class="af-btn af-file-download__btn" disabled>↓ {{ $btnText }}</button>
            @endif
        </div>
    </div>
</div>
@if($track)
@push('scripts')
<script>
function afTrackDownload(name, url) {
    var vid = (document.cookie.match(/af_vid=([^;]+)/) || [])[1] || '';
    fetch('/api/v1/events', {
        method:'POST',
        headers:{'Content-Type':'application/json','Accept':'application/json'},
        body: JSON.stringify({event_type:'download', page_url: window.location.pathname,
            visitor_id: vid, metadata: {file_name: name, file_url: url}})
    }).catch(function(){});
}
</script>
@endpush
@endif
