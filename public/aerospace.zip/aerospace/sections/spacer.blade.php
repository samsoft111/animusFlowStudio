{{-- Block: spacer --}}
@php
    $size    = $settings['size']    ?? 'md';
    $divider = $settings['divider'] ?? false;
    $label   = $content['label']    ?? '';
@endphp

<div class="af-spacer af-spacer--{{ $size }} {{ $divider ? 'af-spacer--divider' : '' }}" aria-hidden="true">
    @if($label)
        <span class="af-spacer__label">{{ $label }}</span>
    @endif
</div>
