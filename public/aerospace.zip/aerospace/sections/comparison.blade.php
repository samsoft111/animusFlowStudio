{{-- Block: comparison table --}}
@php
    $heading  = $content['heading']  ?? '';
    $subtext  = $content['subtext']  ?? '';
    $features = $content['features'] ?? [];
    $columns  = $content['columns']  ?? [];
@endphp

<section class="af-comparison">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
            @if($subtext)<p data-af-field="subtext">{{ $subtext }}</p>@endif
        </div>
        @endif

        <div class="af-comparison__scroll">
            <table class="af-comparison__table">
                <thead>
                    <tr>
                        <th class="af-comparison__feature-col">Feature</th>
                        @foreach($columns as $col)
                        <th class="{{ ($col['highlighted'] ?? false) ? 'af-comparison__col--highlight' : '' }}">
                            {{ $col['name'] ?? '' }}
                        </th>
                        @endforeach
                    </tr>
                </thead>
                <tbody>
                    @foreach($features as $fi => $feature)
                    <tr>
                        <td class="af-comparison__feature-name">{{ $feature }}</td>
                        @foreach($columns as $ci => $col)
                        @php $val = $col['values'][$fi] ?? ''; @endphp
                        <td class="{{ ($col['highlighted'] ?? false) ? 'af-comparison__col--highlight' : '' }}">
                            @if($val === true || $val === '1' || strtolower((string)$val) === 'yes' || $val === '✓')
                                <span class="af-comparison__yes">✓</span>
                            @elseif($val === false || $val === '0' || strtolower((string)$val) === 'no' || $val === '✗')
                                <span class="af-comparison__no">✗</span>
                            @else
                                {{ $val }}
                            @endif
                        </td>
                        @endforeach
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</section>
