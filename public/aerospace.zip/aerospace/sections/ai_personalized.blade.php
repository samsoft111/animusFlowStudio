@php
    $segments  = $content['segments'] ?? [];
    $style     = $settings['style']   ?? 'card';
    $activeSegs = $settings['active_segments'] ?? ['first_visit','returning','high_intent','mobile'];

    // Pick the right segment variant; fallback to 'default'
    $seg    = $segment ?? 'first_visit';
    $data   = in_array($seg, $activeSegs) ? ($segments[$seg] ?? $segments['default'] ?? [])
                                          : ($segments['default'] ?? []);
    $heading = $data['heading'] ?? ($content['heading'] ?? '');
    $text    = $data['text']    ?? ($content['text']    ?? '');
    $ctaText = $data['cta_text'] ?? ($content['cta_text'] ?? '');
    $ctaUrl  = $data['cta_url']  ?? ($content['cta_url']  ?? '#');
    $image   = $data['image']   ?? ($content['image']   ?? '');
@endphp
@if($heading || $text || $ctaText)
<section class="af-ai-personalized af-ai-personalized--{{ $style }}">
    <div class="af-container">
        <span class="af-ai-badge">✨ Personalised</span>
        <div class="af-ai-personalized__inner {{ $image ? 'af-ai-personalized__inner--media' : '' }}">
            @if($image)
            <div class="af-ai-personalized__media">
                <img src="{{ $image }}" alt="{{ $heading }}" loading="lazy">
            </div>
            @endif
            <div class="af-ai-personalized__content">
                @if($heading)<h2>{{ $heading }}</h2>@endif
                @if($text)<p>{{ $text }}</p>@endif
                @if($ctaText)<a href="{{ $ctaUrl }}" class="af-btn">{{ $ctaText }}</a>@endif
            </div>
        </div>
    </div>
</section>
@endif
