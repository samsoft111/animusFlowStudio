{{-- Block: breadcrumb — Schema.org BreadcrumbList markup, NOT inside <section> --}}
@php
    $items = $content['items'] ?? [];
@endphp

@if(count($items))
<nav class="af-breadcrumb" aria-label="Breadcrumb">
    <div class="af-container">
        <ol class="af-breadcrumb__list" itemscope itemtype="https://schema.org/BreadcrumbList">
            @foreach($items as $i => $crumb)
            @php
                $label = $crumb['label'] ?? '';
                $url   = $crumb['url']   ?? '';
                $pos   = $i + 1;
                $isLast = $i === count($items) - 1;
            @endphp
            <li class="af-breadcrumb__item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"
                data-af-item="{{ $i }}">
                @if($url && !$isLast)
                    <a href="{{ $url }}" itemprop="item" data-af-field="label">
                        <span itemprop="name">{{ $label }}</span>
                    </a>
                @else
                    <span itemprop="name" data-af-field="label">{{ $label }}</span>
                @endif
                <meta itemprop="position" content="{{ $pos }}">
                @if(!$isLast)<span class="af-breadcrumb__sep" aria-hidden="true">›</span>@endif
            </li>
            @endforeach
        </ol>
    </div>
</nav>
@endif
