{{-- Block: banner — announcement band, NOT inside <section> --}}
@php
    $text     = $content['text']      ?? '';
    $linkText = $content['link_text'] ?? '';
    $linkUrl  = $content['link_url']  ?? '#';
    $type     = $settings['type']     ?? 'info';
@endphp

<div class="af-banner af-banner--{{ $type }}" role="alert">
    <div class="af-container af-banner__inner">
        <span data-af-field="text">{!! $text !!}</span>
        @if($linkText)
        <a href="{{ $linkUrl }}" class="af-banner__link" data-af-field="link_text">{{ $linkText }} →</a>
        @endif
    </div>
</div>
