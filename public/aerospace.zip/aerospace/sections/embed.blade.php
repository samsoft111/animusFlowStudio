{{-- Block: embed — arbitrary HTML / iframe embed (e.g. Typeform, Airtable, Calendly) --}}
@php
    $heading = $content['heading'] ?? '';
    $html    = $content['html']    ?? '';
    $caption = $content['caption'] ?? '';
    $height  = $settings['height'] ?? 400;
@endphp

<section class="af-embed">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
        </div>
        @endif

        <div class="af-embed__frame" style="min-height:{{ (int) $height }}px" data-af-field="html">
            @if($html)
                {!! $html !!}
            @else
                <div class="af-embed__placeholder">Paste embed code here</div>
            @endif
        </div>

        @if($caption)
        <p class="af-embed__caption" data-af-field="caption">{{ $caption }}</p>
        @endif
    </div>
</section>
