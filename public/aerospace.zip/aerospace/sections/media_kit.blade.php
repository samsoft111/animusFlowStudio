@php
    $heading     = $content['heading']    ?? 'Media Kit';
    $subtext     = $content['subtext']    ?? '';
    $files       = $content['files']      ?? [];
    $brandColors = $content['brand_colors'] ?? [];
    $logos       = $content['logos']      ?? [];
    $style       = $settings['style']     ?? 'grid';
    $typeIcons   = ['pdf'=>'📄','zip'=>'🗜','png'=>'🖼','svg'=>'🔷','ai'=>'🎨','eps'=>'✏️'];
@endphp
<section class="af-media-kit af-media-kit--{{ $style }}">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
            @if($subtext)<p data-af-field="subtext">{{ $subtext }}</p>@endif
        </div>
        @endif

        @if(count($logos))
        <div class="af-media-kit__section">
            <h3 class="af-media-kit__sub-heading">Logos</h3>
            <div class="af-media-kit__logos">
                @foreach($logos as $i => $logo)
                @php $name=$logo['name']??''; $url=$logo['url']??''; $bg=$logo['background']??'light'; @endphp
                <div class="af-media-kit__logo-item af-media-kit__logo--{{ $bg }}" data-af-item="{{ $i }}">
                    @if($url)<img src="{{ $url }}" alt="{{ $name }}" loading="lazy">@endif
                    @if($name)<span>{{ $name }}</span>@endif
                    @if($url)<a href="{{ $url }}" download class="af-media-kit__dl">↓</a>@endif
                </div>
                @endforeach
            </div>
        </div>
        @endif

        @if(count($brandColors))
        <div class="af-media-kit__section">
            <h3 class="af-media-kit__sub-heading">Brand Colors</h3>
            <div class="af-media-kit__colors">
                @foreach($brandColors as $color)
                @php $name=$color['name']??''; $hex=$color['hex']??'#000'; @endphp
                <div class="af-media-kit__color-swatch">
                    <div class="af-media-kit__color-preview" style="background:{{ $hex }}" title="{{ $hex }}"></div>
                    <div class="af-media-kit__color-info">
                        <strong>{{ $name }}</strong>
                        <code>{{ $hex }}</code>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
        @endif

        @if(count($files))
        <div class="af-media-kit__section">
            <h3 class="af-media-kit__sub-heading">Downloads</h3>
            <div class="af-media-kit__files">
                @foreach($files as $i => $file)
                @php
                    $fname = $file['name']??''; $fdesc=$file['description']??''; $furl=$file['url']??'';
                    $ftype = strtolower($file['type']??''); $fsize=$file['size']??'';
                    $ficon = $typeIcons[$ftype] ?? '📁';
                    $fpreview=$file['preview_image']??'';
                @endphp
                <div class="af-media-kit__file" data-af-item="{{ $i }}">
                    @if($fpreview)<img src="{{ $fpreview }}" alt="{{ $fname }}" class="af-media-kit__file-preview" loading="lazy">@endif
                    <div class="af-media-kit__file-info">
                        <span class="af-media-kit__file-icon">{{ $ficon }}</span>
                        <div>
                            @if($fname)<strong>{{ $fname }}</strong>@endif
                            @if($fdesc)<p>{{ $fdesc }}</p>@endif
                            @if($fsize)<small>{{ $fsize }}</small>@endif
                        </div>
                    </div>
                    @if($furl)<a href="{{ $furl }}" download class="af-btn af-btn--outline af-btn--sm">↓ Download</a>@endif
                </div>
                @endforeach
            </div>
        </div>
        @endif
    </div>
</section>
