{{-- Block: countdown --}}
@php
    $heading     = $content['heading']      ?? '';
    $targetDate  = $content['target_date']  ?? '';
    $expiredText = $content['expired_text'] ?? 'Event has started!';
    $style       = $settings['style']       ?? 'default';
    $uid         = 'cd-' . $block->uuid;
@endphp

<section class="af-countdown af-countdown--{{ $style }}">
    <div class="af-container">
        @if($heading)
        <div class="af-section-header">
            <h2 data-af-field="heading">{{ $heading }}</h2>
        </div>
        @endif

        <div class="af-countdown__display" id="{{ $uid }}" data-target="{{ $targetDate }}" data-expired="{{ $expiredText }}">
            <div class="af-countdown__unit"><span class="af-countdown__value" data-cd-days>00</span><span class="af-countdown__label">Days</span></div>
            <div class="af-countdown__sep">:</div>
            <div class="af-countdown__unit"><span class="af-countdown__value" data-cd-hours>00</span><span class="af-countdown__label">Hours</span></div>
            <div class="af-countdown__sep">:</div>
            <div class="af-countdown__unit"><span class="af-countdown__value" data-cd-mins>00</span><span class="af-countdown__label">Minutes</span></div>
            <div class="af-countdown__sep">:</div>
            <div class="af-countdown__unit"><span class="af-countdown__value" data-cd-secs>00</span><span class="af-countdown__label">Seconds</span></div>
        </div>
    </div>
</section>

@push('scripts')
<script>
(function () {
    var el = document.getElementById('{{ $uid }}');
    if (!el) return;
    var target = new Date(el.getAttribute('data-target')).getTime();
    var expired = el.getAttribute('data-expired');

    function pad(n) { return String(n).padStart(2, '0'); }
    function tick() {
        var diff = target - Date.now();
        if (diff <= 0) {
            el.innerHTML = '<p class="af-countdown__expired">' + expired + '</p>';
            return;
        }
        var d = Math.floor(diff / 86400000);
        var h = Math.floor((diff % 86400000) / 3600000);
        var m = Math.floor((diff % 3600000) / 60000);
        var s = Math.floor((diff % 60000) / 1000);
        el.querySelector('[data-cd-days]').textContent  = pad(d);
        el.querySelector('[data-cd-hours]').textContent = pad(h);
        el.querySelector('[data-cd-mins]').textContent  = pad(m);
        el.querySelector('[data-cd-secs]').textContent  = pad(s);
    }
    tick();
    setInterval(tick, 1000);
})();
</script>
@endpush
