@extends('theme.aerospace.layout')

@section('title', $page->title . ' — ' . ($site_name ?? 'AnimusFlow'))

@section('content')

    @forelse($blocks as $block)
        <div class="af-block-wrapper"
             data-block-id="{{ $block->uuid }}"
             data-block-type="{{ $block->type }}">
            @includeIf('theme.aerospace.sections.' . $block->type, [
                'block'    => $block,
                'content'  => $block->content  ?? [],
                'settings' => $block->settings ?? [],
            ])
        </div>
    @empty
        <section class="af-section">
            <div class="af-container af-text" style="text-align:center;padding:4rem 0">
                <p style="color:#94a3b8;font-size:1.1rem">This page has no content blocks yet.</p>
            </div>
        </section>
    @endforelse

@endsection
