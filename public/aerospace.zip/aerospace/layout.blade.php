@php
    $contentSpacing   = $layout['content_spacing']    ?? 'normal';
    $contentBg        = $layout['content_bg']         ?? 'white';
    $contentFontSize  = $layout['content_font_size']  ?? 'md';
    $contentAnims     = $layout['content_animations'] ?? true;
    $forceDark        = $contentBg === 'dark';

    // Media background
    $bgMedia      = $layout['content_bg_media']   ?? '';
    $bgOverlay    = $layout['content_bg_overlay']  ?? 'dark';
    $bgOpacity    = max(0, min(90, (int) ($layout['content_bg_opacity'] ?? 50)));
    $hasMediaBg   = in_array($contentBg, ['image', 'video'], true) && $bgMedia !== '';
    $overlayAlpha = number_format($bgOpacity / 100, 2);
    $overlayColor = ($bgOverlay === 'light')
        ? "rgba(255,255,255,{$overlayAlpha})"
        : "rgba(0,0,0,{$overlayAlpha})";

    // Brand colors
    $brandPrimary = preg_match('/^#[0-9a-fA-F]{6}$/', $layout['brand_primary'] ?? '') ? $layout['brand_primary'] : '#6366f1';
    $brandAccent  = preg_match('/^#[0-9a-fA-F]{6}$/', $layout['brand_accent']  ?? '') ? $layout['brand_accent']  : '#8b5cf6';
    $pr = hexdec(substr(ltrim($brandPrimary,'#'),0,2));
    $pg = hexdec(substr(ltrim($brandPrimary,'#'),2,2));
    $pb = hexdec(substr(ltrim($brandPrimary,'#'),4,2));
    $primaryH    = sprintf('#%02x%02x%02x', max(0,(int)($pr*.83)), max(0,(int)($pg*.83)), max(0,(int)($pb*.83)));
    $primarySoft = "rgba({$pr},{$pg},{$pb},0.10)";

    // Font family
    $fontKey = $layout['font_family'] ?? 'inter';
    $fontMap = [
        'inter'        => ["'Inter', -apple-system, BlinkMacSystemFont, sans-serif", 'Inter:wght@400;500;600;700;800;900'],
        'poppins'      => ["'Poppins', sans-serif",                                  'Poppins:wght@400;500;600;700;800;900'],
        'dm-sans'      => ["'DM Sans', sans-serif",                                  'DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700;9..40,800'],
        'outfit'       => ["'Outfit', sans-serif",                                   'Outfit:wght@400;500;600;700;800;900'],
        'plus-jakarta' => ["'Plus Jakarta Sans', sans-serif",                        'Plus+Jakarta+Sans:wght@400;500;600;700;800'],
        'playfair'     => ["'Playfair Display', Georgia, serif",                     'Playfair+Display:wght@400;500;600;700;800'],
        'fraunces'     => ["'Fraunces', Georgia, serif",                             'Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700;9..144,800'],
        'sora'         => ["'Sora', sans-serif",                                     'Sora:wght@400;500;600;700;800'],
    ];
    $fontCss    = $fontMap[$fontKey][0] ?? $fontMap['inter'][0];
    $fontGoogle = $fontMap[$fontKey][1] ?? $fontMap['inter'][1];

    // Shape / border radius
    $shapeKey = $layout['shape'] ?? 'normal';
    $radiiMap = [
        'sharp'   => ['sm'=>'0',       'md'=>'0',       'lg'=>'0',       'xl'=>'0',       '2xl'=>'0'],
        'normal'  => ['sm'=>'.375rem', 'md'=>'.625rem', 'lg'=>'1rem',    'xl'=>'1.5rem',  '2xl'=>'2rem'],
        'rounded' => ['sm'=>'.5rem',   'md'=>'1rem',    'lg'=>'1.5rem',  'xl'=>'2.25rem', '2xl'=>'3rem'],
    ];
    $radii = $radiiMap[$shapeKey] ?? $radiiMap['normal'];

    $sectionPyMap = ['compact' => '3.5rem', 'normal' => '5.5rem', 'spacious' => '8rem'];
    $heroPyMap    = ['compact' => '4.5rem 0 4rem', 'normal' => '7rem 0 6.5rem', 'spacious' => '9.5rem 0 9rem'];
    $fontSizeMap  = ['sm' => '14px', 'md' => '16px', 'lg' => '17.5px'];

    $sectionPy  = $sectionPyMap[$contentSpacing] ?? '5.5rem';
    $heroPy     = $heroPyMap[$contentSpacing]    ?? '7rem 0 6.5rem';
    $baseFontSz = $fontSizeMap[$contentFontSize] ?? '16px';
@endphp
<!DOCTYPE html>
<html lang="{{ $site_language ?? 'en' }}" data-theme="{{ $forceDark ? 'dark' : 'light' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    {{-- Prevent FOUC: apply saved theme before first paint --}}
    <script>
    (function(){
        try {
            var def = '{{ $forceDark ? 'dark' : 'light' }}';
            var s = localStorage.getItem('af_scheme') ||
                (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : def);
            document.documentElement.setAttribute('data-theme', s);
        } catch(e){}
    })();
    </script>

    {{-- SEO --}}
    <title>{{ $seo?->meta_title ?? $page?->title ?? $site_name ?? 'AnimusFlow' }}
        @if(($seo?->meta_title ?? $page?->title ?? '') !== ($site_name ?? ''))
            — {{ $site_name ?? 'AnimusFlow' }}
        @endif
    </title>
    @if(!empty($seo?->meta_description))
    <meta name="description" content="{{ $seo->meta_description }}">
    @endif
    @if(!empty($seo?->keywords))
    <meta name="keywords" content="{{ implode(', ', (array) $seo->keywords) }}">
    @endif
    <meta property="og:type"        content="website">
    <meta property="og:title"       content="{{ $seo?->og_title ?? $page?->title ?? $site_name ?? 'AnimusFlow' }}">
    <meta property="og:description" content="{{ $seo?->og_description ?? $seo?->meta_description ?? '' }}">
    @if(!empty($seo?->og_image))
    <meta property="og:image"       content="{{ $seo->og_image }}">
    @endif

    {{-- Editor metadata --}}
    <meta name="af-page-id"   content="{{ $page->uuid ?? '' }}">
    <meta name="af-page-slug" content="{{ $page->slug ?? '' }}">
    <meta name="af-api-base"  content="{{ url('/api/v1') }}">
    <meta name="csrf-token"   content="{{ csrf_token() }}">

    {{-- Favicon (item 2) --}}
    @php
        $favicon = $layout['favicon_image'] ?? $site_favicon ?? '';
    @endphp
    @if(!empty($favicon))
    <link rel="icon" href="{{ $favicon }}">
    @endif

    {{-- Fonts --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family={{ $fontGoogle }}&display=swap" rel="stylesheet">

    @vite('resources/js/app.js')

    <style>
    /* ═══════════════════════════════════════════════════════════
       DESIGN TOKENS
    ═══════════════════════════════════════════════════════════ */
    :root {
        --font:       {{ $fontCss }};
        --max-w:      {{ ($layout['content_max_width'] ?? '1120') === 'full' ? '100%' : (($layout['content_max_width'] ?? '1120') . 'px') }};
        --section-py: {{ $sectionPy }};

        /* Light mode (default) */
        --bg:            #070C18;
        --bg-subtle:     rgba(10, 15, 30, 0.75);
        --bg-muted:      #1E293B;
        --bg-invert:     #0a0f1e;
        --border:        rgba(255, 255, 255, 0.08);
        --border-strong: #cbd5e1;
        --text:          #F3F4F6;
        --text-2:        #334155;
        --text-muted:    #64748b;
        --text-invert:   #f8fafc;
        --primary:       #2563EB;
        --primary-h:     #0F172A;
        --primary-soft:  {{ $primarySoft }};
        --accent:        #06B6D4;
        --success:       #10B981;
        --danger:        #EF4444;

        --radius-sm:  {{ $radii['sm'] }};
        --radius:     {{ $radii['md'] }};
        --radius-lg:  {{ $radii['lg'] }};
        --radius-xl:  {{ $radii['xl'] }};
        --radius-2xl: {{ $radii['2xl'] }};

        --shadow-xs:  0 1px 2px rgba(0,0,0,.05);
        --shadow-sm:  0 1px 3px rgba(0,0,0,.08), 0 1px 2px rgba(0,0,0,.04);
        --shadow:     0 4px 6px -1px rgba(0,0,0,.07), 0 2px 4px -2px rgba(0,0,0,.05);
        --shadow-md:  0 8px 20px -4px rgba(0,0,0,.08), 0 4px 8px -4px rgba(0,0,0,.05);
        --shadow-lg:  0 16px 40px -8px rgba(0,0,0,.1),  0 8px 16px -8px rgba(0,0,0,.06);
        --shadow-xl:  0 24px 60px -12px rgba(0,0,0,.14);
        --shadow-glow: 0 0 40px rgba(99,102,241,.25);

        --transition: .2s ease;
        --transition-fast: .12s ease;
        --transition-bounce: .3s cubic-bezier(.34,1.56,.64,1);
        --nav-h: 68px;

        /* ── Aliases for legacy block CSS ── */
        --bg-alt:    var(--bg-muted);
        --section-y: var(--section-py);
    }

    [data-theme="dark"] {
        --bg:            #070C18;
        --bg-subtle:     rgba(3, 7, 18, 0.85);
        --bg-muted:      #0F172A;
        --bg-invert:     #f8fafc;
        --border:        rgba(255, 255, 255, 0.05);
        --border-strong: #2d4059;
        --text:          #F9FAFB;
        --text-2:        #c8d3e8;
        --text-muted:    #6b7f9e;
        --text-invert:   #0f172a;
        --primary:       #2563EB;
        --primary-h:     #030712;
        --primary-soft:  rgba(129,140,248,.12);
        --accent:        #06B6D4;

        --shadow-xs:  0 1px 2px rgba(0,0,0,.3);
        --shadow-sm:  0 1px 3px rgba(0,0,0,.4), 0 1px 2px rgba(0,0,0,.3);
        --shadow:     0 4px 6px -1px rgba(0,0,0,.4), 0 2px 4px -2px rgba(0,0,0,.3);
        --shadow-md:  0 8px 20px -4px rgba(0,0,0,.5), 0 4px 8px -4px rgba(0,0,0,.3);
        --shadow-lg:  0 16px 40px -8px rgba(0,0,0,.6),  0 8px 16px -8px rgba(0,0,0,.4);
        --shadow-xl:  0 24px 60px -12px rgba(0,0,0,.7);
        --shadow-glow: 0 0 60px rgba(129,140,248,.2);

        /* ── Dark mode aliases ── */
        --bg-alt: var(--bg-muted);
    }

    /* ═══════════════════════════════════════════════════════════
       RESET + BASE
    ═══════════════════════════════════════════════════════════ */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html   { scroll-behavior: smooth; font-size: {{ $baseFontSz }}; }
    body   { font-family: var(--font); background: var(--bg); color: var(--text);
             line-height: 1.65; -webkit-font-smoothing: antialiased; transition: background var(--transition), color var(--transition); }
    @if($contentBg === 'neutral' && !$hasMediaBg)
    body { background: #f8fafc; }
    [data-theme="dark"] body { background: var(--bg); }
    @elseif($hasMediaBg)
    body { background: transparent !important; }
    @endif
    img    { max-width: 100%; display: block; }
    a      { color: var(--primary); text-decoration: none; transition: color var(--transition); }
    a:hover { text-decoration: underline; }
    ::selection { background: var(--primary-soft); color: var(--text); }

    /* ═══════════════════════════════════════════════════════════
       LAYOUT
    ═══════════════════════════════════════════════════════════ */
    .af-container { max-width: var(--max-w); margin: 0 auto; padding: 0 1.75rem; }
    .af-section   { padding: var(--section-py) 0; }

    .af-section--dark {
        background: linear-gradient(160deg, #0a0f1e 0%, #110a2e 60%, #0f1629 100%);
        color: var(--text-invert);
        position: relative;
        overflow: hidden;
    }
    .af-section--dark::before {
        content: '';
        position: absolute;
        inset: 0;
        background:
            radial-gradient(ellipse 70% 60% at 50% 120%, rgba(99,102,241,.18), transparent),
            radial-gradient(ellipse 50% 40% at 80% 0%, rgba(139,92,246,.12), transparent);
        pointer-events: none;
    }
    .af-section--dark .af-container { position: relative; z-index: 1; }
    .af-section--muted { background: var(--bg-subtle); }

    /* ═══════════════════════════════════════════════════════════
       NAVIGATION
    ═══════════════════════════════════════════════════════════ */

    /* Item 9 — entrance animation */
    @keyframes af-nav-in {
        from { opacity: 0; transform: translateY(-4px); }
        to   { opacity: 1; transform: translateY(0); }
    }

    .af-nav {
        position: sticky;
        top: 0;
        z-index: 1000;
        height: var(--nav-h);
        display: flex;
        align-items: center;
        background: rgba(255,255,255,.82);
        backdrop-filter: blur(20px) saturate(180%);
        -webkit-backdrop-filter: blur(20px) saturate(180%);
        border-bottom: 1px solid rgba(226,232,240,.6);
        /* Item 1 — smooth height transition */
        transition: height .3s ease, background var(--transition), border-color var(--transition);
        animation: af-nav-in .35s ease both;
    }
    [data-theme="dark"] .af-nav {
        background: rgba(8,13,26,.85);
        border-bottom-color: rgba(30,45,64,.6);
    }

    /* Item 1 — compact nav on scroll */
    .af-nav--compact { height: 52px; }
    .af-nav--compact .af-nav__logo { max-height: 32px; }

    /* Background variants */
    .af-nav--solid {
        background: var(--bg) !important;
        backdrop-filter: none;
        border-bottom: 1px solid var(--border) !important;
    }
    .af-nav--transparent {
        background: transparent !important;
        backdrop-filter: none;
        border-bottom-color: transparent !important;
    }

    /* Non-sticky */
    .af-nav--relative { position: relative !important; top: auto !important; }

    .af-nav__inner {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 2rem;
    }

    /* Menu position variants */
    .af-nav--menu-left .af-nav__inner  { justify-content: flex-start; }
    .af-nav--menu-left .af-nav__links  { margin-right: auto; }
    .af-nav--menu-center .af-nav__inner { position: relative; justify-content: space-between; }
    .af-nav--menu-center .af-nav__links { position: absolute; left: 50%; transform: translateX(-50%); }
    .af-nav--menu-right .af-nav__links  { margin-left: auto; }

    .af-nav__brand {
        font-size: 1.2rem;
        font-weight: 800;
        letter-spacing: -.02em;
        background: linear-gradient(135deg, var(--primary), var(--accent));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        text-decoration: none;
        flex-shrink: 0;
    }

    /* Item 3 — logo with smooth height transition */
    .af-nav__logo {
        width: auto;
        object-fit: contain;
        display: block;
        transition: height .3s ease, max-height .3s ease;
    }

    .af-nav__links {
        display: flex;
        align-items: center;
        gap: .25rem;
    }
    .af-nav__link {
        padding: .4rem .75rem;
        border-radius: var(--radius);
        font-size: .875rem;
        font-weight: 500;
        color: var(--text-muted);
        text-decoration: none;
        transition: color var(--transition), background var(--transition);
        white-space: nowrap;
    }
    .af-nav__link:hover { color: var(--text); background: var(--bg-muted); text-decoration: none; }
    .af-nav__link--active { color: var(--primary) !important; background: var(--primary-soft); }

    .af-nav__right { display: flex; align-items: center; gap: .5rem; }

    .af-theme-toggle {
        width: 38px; height: 38px;
        border-radius: var(--radius);
        border: 1px solid var(--border);
        background: var(--bg-muted);
        color: var(--text-muted);
        cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        font-size: 1rem;
        transition: background var(--transition), color var(--transition), border-color var(--transition);
        flex-shrink: 0;
    }
    .af-theme-toggle:hover { background: var(--border); color: var(--text); }

    /* Hamburger — hidden on desktop */
    .af-nav__hamburger {
        display: none;
        flex-direction: column;
        justify-content: center;
        gap: 5px;
        background: none;
        border: 1px solid var(--border);
        border-radius: var(--radius);
        cursor: pointer;
        padding: .45rem .55rem;
        width: 38px; height: 38px;
        flex-shrink: 0;
    }
    .af-nav__hamburger span {
        display: block;
        width: 18px; height: 2px;
        background: var(--text-muted);
        border-radius: 2px;
        transition: transform .25s ease, opacity .2s ease;
        pointer-events: none;
    }
    .af-nav__hamburger.is-open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
    .af-nav__hamburger.is-open span:nth-child(2) { opacity: 0; transform: scaleX(0); }
    .af-nav__hamburger.is-open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

    /* Item 4 — mobile backdrop */
    .af-nav__backdrop {
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,.45);
        backdrop-filter: blur(2px);
        -webkit-backdrop-filter: blur(2px);
        z-index: 997;
        opacity: 0;
        visibility: hidden;
        pointer-events: none;
        transition: opacity .25s ease, visibility 0s ease .25s;
    }
    .af-nav__backdrop.is-open {
        opacity: 1;
        visibility: visible;
        pointer-events: auto;
        transition: opacity .25s ease;
    }

    /* Item 7 — dropdown menus */
    .af-nav__item { position: relative; }
    .af-nav__item--trigger {
        display: inline-flex;
        align-items: center;
        gap: .3rem;
        padding: .4rem .75rem;
        border-radius: var(--radius);
        font-size: .875rem;
        font-weight: 500;
        color: var(--text-muted);
        background: none;
        border: none;
        font-family: var(--font);
        cursor: pointer;
        white-space: nowrap;
        transition: color var(--transition), background var(--transition);
    }
    .af-nav__item:hover .af-nav__item--trigger,
    .af-nav__item:focus-within .af-nav__item--trigger {
        color: var(--text); background: var(--bg-muted);
    }
    .af-nav__caret {
        width: 8px; height: 8px;
        border-right: 1.5px solid currentColor;
        border-bottom: 1.5px solid currentColor;
        transform: rotate(45deg) translateY(-2px);
        transition: transform .2s ease;
        flex-shrink: 0;
        margin-top: 1px;
    }
    .af-nav__item:hover .af-nav__caret,
    .af-nav__item:focus-within .af-nav__caret { transform: rotate(-135deg) translateY(2px); }

    .af-nav__dropdown {
        position: absolute;
        top: calc(100% + .5rem);
        left: 50%;
        transform: translateX(-50%) translateY(-4px);
        min-width: 180px;
        background: var(--bg);
        border: 1px solid var(--border);
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-lg);
        padding: .4rem;
        opacity: 0;
        visibility: hidden;
        pointer-events: none;
        transition: opacity .2s ease, transform .2s ease, visibility 0s ease .2s;
        z-index: 1010;
    }
    .af-nav__dropdown::before {
        content: '';
        position: absolute;
        top: -5px; left: 50%;
        transform: translateX(-50%) rotate(45deg);
        width: 8px; height: 8px;
        background: var(--bg);
        border-top: 1px solid var(--border);
        border-left: 1px solid var(--border);
    }
    .af-nav__item:hover .af-nav__dropdown,
    .af-nav__item:focus-within .af-nav__dropdown {
        opacity: 1; visibility: visible; pointer-events: auto;
        transform: translateX(-50%) translateY(0);
        transition: opacity .2s ease, transform .2s ease;
    }
    .af-nav__dropdown-link {
        display: block;
        padding: .45rem .75rem;
        border-radius: var(--radius-sm);
        font-size: .84rem;
        font-weight: 500;
        color: var(--text-2);
        text-decoration: none;
        white-space: nowrap;
        transition: background var(--transition), color var(--transition);
    }
    .af-nav__dropdown-link:hover { background: var(--bg-muted); color: var(--text); text-decoration: none; }

    /* Transparent nav → glass when scrolled */
    .af-nav--transparent.af-nav--scrolled {
        background: rgba(255,255,255,.92) !important;
        backdrop-filter: blur(20px) saturate(180%);
        -webkit-backdrop-filter: blur(20px) saturate(180%);
        border-bottom-color: rgba(226,232,240,.6) !important;
    }
    [data-theme="dark"] .af-nav--transparent.af-nav--scrolled {
        background: rgba(8,13,26,.9) !important;
        border-bottom-color: rgba(30,45,64,.6) !important;
    }

    /* ═══════════════════════════════════════════════════════════
       BUTTONS
    ═══════════════════════════════════════════════════════════ */
    .af-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: .45rem;
        padding: .7rem 1.5rem;
        border-radius: var(--radius-lg);
        font-family: var(--font);
        font-size: .9375rem;
        font-weight: 600;
        line-height: 1;
        cursor: pointer;
        border: none;
        text-decoration: none;
        transition: all var(--transition);
        white-space: nowrap;
        letter-spacing: -.01em;
    }
    .af-btn:hover { text-decoration: none; transform: translateY(-1px); }
    .af-btn:active { transform: translateY(0); }

    .af-btn--primary {
        background: linear-gradient(135deg, var(--primary), var(--accent));
        color: #fff;
        box-shadow: 0 4px 14px rgba(99,102,241,.35);
    }
    .af-btn--primary:hover { box-shadow: 0 6px 20px rgba(99,102,241,.45); }

    .af-btn--outline {
        background: transparent;
        border: 1.5px solid var(--border-strong);
        color: var(--text-2);
    }
    .af-btn--outline:hover { border-color: var(--primary); color: var(--primary); background: var(--primary-soft); }

    .af-btn--white {
        background: #fff;
        color: var(--text-invert);
        box-shadow: var(--shadow-md);
    }
    [data-theme="dark"] .af-btn--white { color: #0f172a; }
    .af-btn--white:hover { box-shadow: var(--shadow-lg); }

    .af-btn--ghost {
        background: rgba(255,255,255,.1);
        border: 1.5px solid rgba(255,255,255,.2);
        color: #fff;
        backdrop-filter: blur(8px);
    }
    .af-btn--ghost:hover { background: rgba(255,255,255,.18); }

    /* ═══════════════════════════════════════════════════════════
       HERO SECTION
    ═══════════════════════════════════════════════════════════ */
    .af-hero { padding: {{ $heroPy }}; text-align: center; }
    .af-hero--dark {
        background: linear-gradient(160deg, #060b18 0%, #0e0826 55%, #09111f 100%);
        color: #f0f4ff;
        position: relative;
        overflow: hidden;
    }
    .af-hero--dark::before {
        content: '';
        position: absolute;
        inset: 0;
        background:
            radial-gradient(ellipse 80% 55% at 50% -10%, rgba(99,102,241,.3), transparent),
            radial-gradient(ellipse 40% 30% at 80% 80%, rgba(139,92,246,.15), transparent),
            radial-gradient(ellipse 30% 25% at 10% 50%, rgba(59,130,246,.1), transparent);
        pointer-events: none;
    }
    .af-hero--dark::after {
        content: '';
        position: absolute;
        inset: 0;
        background-image:
            linear-gradient(rgba(99,102,241,.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(99,102,241,.04) 1px, transparent 1px);
        background-size: 60px 60px;
        mask-image: radial-gradient(ellipse 70% 60% at 50% 50%, black, transparent);
        pointer-events: none;
    }
    .af-hero--dark .af-container { position: relative; z-index: 1; }

    .af-hero__eyebrow {
        display: inline-flex; align-items: center; gap: .5rem;
        padding: .35rem .9rem; border-radius: 99px;
        font-size: .75rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase;
        background: var(--primary-soft); color: var(--primary); border: 1px solid rgba(99,102,241,.2);
        margin-bottom: 1.5rem;
    }
    .af-hero--dark .af-hero__eyebrow { background: rgba(129,140,248,.1); color: #a5b4fc; border-color: rgba(129,140,248,.2); }

    .af-hero__heading {
        font-size: clamp(2.5rem, 6vw, 4.25rem);
        font-weight: 900; line-height: 1.05; letter-spacing: -.04em;
        margin-bottom: 1.5rem; color: inherit;
    }
    .af-hero__heading span {
        background: linear-gradient(135deg, var(--primary), var(--accent));
        -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
    }
    .af-hero--dark .af-hero__heading span {
        background: linear-gradient(135deg, #a5b4fc, #c4b5fd);
        -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
    }

    .af-hero__sub {
        font-size: 1.175rem; color: var(--text-muted);
        max-width: 580px; margin: 0 auto 2.75rem; line-height: 1.7; font-weight: 400;
    }
    .af-hero--dark .af-hero__sub { color: #8fa3c4; }
    .af-hero__actions { display: flex; gap: .875rem; justify-content: center; flex-wrap: wrap; }

    /* ═══════════════════════════════════════════════════════════
       FEATURES
    ═══════════════════════════════════════════════════════════ */
    .af-features__heading {
        text-align: center; font-size: clamp(1.75rem, 3.5vw, 2.5rem);
        font-weight: 800; letter-spacing: -.03em; margin-bottom: 3.5rem; color: var(--text);
    }
    .af-features__grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.25rem; }
    .af-feature-card {
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 2rem 1.75rem;
        transition: box-shadow var(--transition), transform var(--transition), border-color var(--transition);
        position: relative; overflow: hidden;
    }
    .af-feature-card::before {
        content: ''; position: absolute; inset: 0;
        background: linear-gradient(135deg, var(--primary-soft), transparent 60%);
        opacity: 0; transition: opacity var(--transition);
    }
    .af-feature-card:hover { box-shadow: var(--shadow-lg); transform: translateY(-3px); border-color: rgba(99,102,241,.3); }
    .af-feature-card:hover::before { opacity: 1; }
    [data-theme="dark"] .af-feature-card { background: var(--bg-subtle); border-color: var(--border); }
    [data-theme="dark"] .af-feature-card:hover { border-color: rgba(129,140,248,.35); }

    .af-feature-card__icon {
        width: 52px; height: 52px; border-radius: var(--radius-lg);
        background: linear-gradient(135deg, rgba(99,102,241,.15), rgba(139,92,246,.08));
        border: 1px solid rgba(99,102,241,.15);
        display: flex; align-items: center; justify-content: center; font-size: 1.5rem;
        margin-bottom: 1.25rem; position: relative; transition: box-shadow var(--transition);
    }
    .af-feature-card:hover .af-feature-card__icon { box-shadow: 0 0 20px rgba(99,102,241,.25); }
    [data-theme="dark"] .af-feature-card__icon {
        background: linear-gradient(135deg, rgba(129,140,248,.12), rgba(167,139,250,.06));
        border-color: rgba(129,140,248,.15);
    }
    .af-feature-card__title { font-size: 1.0625rem; font-weight: 700; letter-spacing: -.02em; margin-bottom: .5rem; color: var(--text); position: relative; }
    .af-feature-card__text  { font-size: .9rem; color: var(--text-muted); line-height: 1.7; position: relative; }

    /* ═══════════════════════════════════════════════════════════
       TEXT / RICH TEXT
    ═══════════════════════════════════════════════════════════ */
    .af-text { max-width: 740px; margin: 0 auto; }
    .af-text__heading { font-size: clamp(1.6rem, 3vw, 2.25rem); font-weight: 800; letter-spacing: -.03em; margin-bottom: 1.5rem; color: var(--text); }
    .af-text__body    { font-size: 1.05rem; color: var(--text-muted); line-height: 1.85; white-space: pre-wrap; }

    /* ═══════════════════════════════════════════════════════════
       CTA SECTION
    ═══════════════════════════════════════════════════════════ */
    .af-cta { text-align: center; }
    .af-cta__heading { font-size: clamp(1.75rem, 4vw, 3rem); font-weight: 900; letter-spacing: -.04em; margin-bottom: 1.1rem; line-height: 1.1; }
    .af-cta__text {
        font-size: 1.075rem; color: var(--text-muted); margin-bottom: 2.5rem;
        max-width: 500px; margin-left: auto; margin-right: auto; line-height: 1.7;
    }
    .af-section--dark .af-cta__text { color: #8fa3c4; }

    /* ═══════════════════════════════════════════════════════════
       FOOTER
    ═══════════════════════════════════════════════════════════ */
    .af-footer {
        border-top: 1px solid var(--border); padding: 2.25rem 0; background: var(--bg-subtle);
        transition: background var(--transition), border-color var(--transition);
    }
    .af-footer--dark  { background: #0c1120; border-color: rgba(255,255,255,.08); }
    .af-footer--dark  .af-footer__copy  { color: #8fa3c4; }
    .af-footer--dark  .af-footer__links a { color: #8fa3c4; }
    .af-footer--dark  .af-footer__social a { border-color: rgba(255,255,255,.12); color: #8fa3c4; }
    .af-footer--brand { background: linear-gradient(135deg, var(--primary), var(--accent)); border-color: transparent; }
    .af-footer--brand .af-footer__brand { background: none; -webkit-text-fill-color: #fff; color: #fff; }
    .af-footer--brand .af-footer__copy  { color: rgba(255,255,255,.8); }
    .af-footer--brand .af-footer__links a { color: rgba(255,255,255,.8); }
    .af-footer--brand .af-footer__links a:hover { color: #fff; }
    .af-footer--brand .af-footer__social a { border-color: rgba(255,255,255,.3); color: #fff; }
    .af-footer--brand .af-footer__social a:hover { background: rgba(255,255,255,.15); border-color: rgba(255,255,255,.6); }
    .af-footer__inner { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem; }
    .af-footer__brand { font-weight: 800; font-size: .9rem; background: linear-gradient(135deg, var(--primary), var(--accent)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
    .af-footer__logo  { height: 28px; object-fit: contain; display: block; }
    .af-footer__links { display: flex; align-items: center; flex-wrap: wrap; gap: .2rem 1.1rem; }
    .af-footer__links a { font-size: .82rem; color: var(--text-muted); text-decoration: none; transition: color .15s; }
    .af-footer__links a:hover { color: var(--primary); }
    .af-footer__right { display: flex; flex-direction: column; align-items: flex-end; gap: .45rem; }
    .af-footer__social { display: flex; align-items: center; gap: .45rem; }
    .af-footer__social a {
        display: flex; align-items: center; justify-content: center;
        width: 30px; height: 30px; border-radius: 50%;
        border: 1.5px solid var(--border); color: var(--text-muted);
        text-decoration: none; transition: border-color .15s, color .15s, background .15s;
    }
    .af-footer__social a:hover { border-color: var(--primary); color: var(--primary); background: var(--primary-s); }
    .af-footer__copy  { font-size: .82rem; color: var(--text-muted); }

    /* ── Footer column grid ──────────────────────────────────── */
    .af-footer-grid { display: grid; gap: 2.5rem; padding-bottom: 2rem; }
    .af-footer-grid--1 { grid-template-columns: 1fr; }
    .af-footer-grid--2 { grid-template-columns: repeat(2, 1fr); }
    .af-footer-grid--3 { grid-template-columns: repeat(3, 1fr); }
    .af-footer-grid--4 { grid-template-columns: repeat(4, 1fr); }
    @media (max-width: 768px) {
        .af-footer-grid--3, .af-footer-grid--4 { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 520px) {
        .af-footer-grid--2, .af-footer-grid--3, .af-footer-grid--4 { grid-template-columns: 1fr; }
    }
    .af-footer-col__label {
        font-size: .7rem; font-weight: 800; letter-spacing: .08em;
        text-transform: uppercase; color: var(--text-muted); margin-bottom: .8rem;
    }
    .af-footer--dark  .af-footer-col__label { color: #60789c; }
    .af-footer--brand .af-footer-col__label { color: rgba(255,255,255,.55); }
    .af-footer-col__links { display: flex; flex-direction: column; gap: .5rem; }
    .af-footer-col__links a { font-size: .87rem; color: var(--text-muted); text-decoration: none; transition: color .15s; }
    .af-footer-col__links a:hover { color: var(--primary); }
    .af-footer--brand .af-footer-col__links a { color: rgba(255,255,255,.75); }
    .af-footer--brand .af-footer-col__links a:hover { color: #fff; }
    .af-footer-contact { font-size: .87rem; color: var(--text-muted); line-height: 1.65; display: flex; flex-direction: column; gap: .35rem; }
    .af-footer-contact a { color: inherit; text-decoration: none; transition: color .15s; }
    .af-footer-contact a:hover { color: var(--primary); }
    .af-footer-map { border-radius: var(--radius-lg); overflow: hidden; }
    .af-footer-map iframe { width: 100%; height: 190px; border: none; display: block; }
    .af-footer-text { font-size: .87rem; color: var(--text-muted); line-height: 1.65; }
    .af-footer-text a { color: var(--primary); }
    .af-footer__social-icon {
        display: inline-flex; align-items: center; justify-content: center;
        width: 34px; height: 34px; border-radius: 50%;
        border: 1.5px solid var(--border); color: var(--text-muted);
        text-decoration: none; transition: border-color .15s, color .15s, background .15s;
    }
    .af-footer__social-icon:hover { border-color: var(--primary); color: var(--primary); background: var(--primary-s); }
    .af-footer--dark  .af-footer__social-icon { border-color: rgba(255,255,255,.12); color: #8fa3c4; }
    .af-footer--brand .af-footer__social-icon { border-color: rgba(255,255,255,.3); color: #fff; }
    .af-footer--brand .af-footer__social-icon:hover { background: rgba(255,255,255,.15); border-color: rgba(255,255,255,.6); }
    .af-footer-social-col { display: flex; flex-wrap: wrap; gap: .45rem; }
    .af-footer-bottom {
        display: flex; align-items: center; justify-content: space-between;
        flex-wrap: wrap; gap: .75rem;
        padding-top: 1.25rem; border-top: 1px solid var(--border);
    }
    .af-footer--dark  .af-footer-bottom { border-color: rgba(255,255,255,.08); }
    .af-footer--brand .af-footer-bottom { border-color: rgba(255,255,255,.15); }

    /* ═══════════════════════════════════════════════════════════
       PREVIEW BANNER
    ═══════════════════════════════════════════════════════════ */
    .af-preview-bar {
        position: fixed; bottom: 1.25rem; left: 50%; transform: translateX(-50%);
        background: linear-gradient(135deg, #0f172a, #1e1b4b); color: #f0f4ff;
        padding: .55rem 1.35rem; border-radius: 99px; font-size: .78rem; font-weight: 600;
        z-index: 9998; pointer-events: none;
        box-shadow: 0 4px 24px rgba(0,0,0,.4), 0 0 0 1px rgba(99,102,241,.3); letter-spacing: .01em;
    }

    /* ═══════════════════════════════════════════════════════════
       RESPONSIVE
    ═══════════════════════════════════════════════════════════ */
    @media (max-width: 640px) {
        :root { --section-py: {{ $contentSpacing === 'spacious' ? '5.5rem' : ($contentSpacing === 'compact' ? '2.5rem' : '4rem') }}; }
        .af-hero    { padding: {{ $contentSpacing === 'spacious' ? '6rem 0 5.5rem' : ($contentSpacing === 'compact' ? '3rem 0 2.5rem' : '5rem 0 4.5rem') }}; }
        .af-section { padding: var(--section-py) 0; }
        .af-nav__hamburger { display: flex; }

        /* Item 4 — mobile menu: slide-in animation via visibility+opacity (no display:none flash) */
        .af-nav__links {
            flex-direction: column;
            align-items: stretch;
            position: fixed;
            top: var(--nav-h);
            left: 0; right: 0;
            background: var(--bg);
            border-bottom: 1px solid var(--border);
            padding: .75rem 1.25rem 1.5rem;
            gap: .25rem;
            z-index: 999;
            box-shadow: var(--shadow-md);
            /* Hidden state */
            visibility: hidden;
            opacity: 0;
            transform: translateY(-8px);
            pointer-events: none;
            transition: transform .25s ease, opacity .2s ease, visibility 0s ease .25s;
        }
        .af-nav__links.is-open {
            visibility: visible;
            opacity: 1;
            transform: translateY(0);
            pointer-events: auto;
            transition: transform .25s ease, opacity .2s ease;
        }
        .af-nav__links .af-nav__link { padding: .65rem .875rem; border-radius: var(--radius); }

        /* Item 7 — mobile dropdowns (static, accordion-style) */
        .af-nav__dropdown {
            position: static !important;
            transform: none !important;
            min-width: auto;
            box-shadow: none;
            border: none;
            background: var(--bg-muted);
            border-radius: var(--radius);
            padding: .25rem .25rem .25rem .5rem;
            margin: .1rem 0 .25rem;
            opacity: 0;
            visibility: hidden;
            max-height: 0;
            overflow: hidden;
            transition: opacity .2s ease, max-height .25s ease, visibility 0s ease .25s;
        }
        .af-nav__dropdown::before { display: none; }
        .af-nav__item.is-open .af-nav__dropdown {
            opacity: 1; visibility: visible; max-height: 400px;
            transition: opacity .2s ease, max-height .25s ease;
        }
        .af-nav__item--trigger {
            width: 100%; justify-content: space-between; padding: .65rem .875rem;
        }
        .af-nav__item:hover .af-nav__dropdown,
        .af-nav__item:focus-within .af-nav__dropdown {
            opacity: 0; visibility: hidden; max-height: 0;
            transform: none;
        }
        .af-nav__item.is-open .af-nav__dropdown {
            opacity: 1; visibility: visible; max-height: 400px;
        }
    }

    /* ═══════════════════════════════════════════════════════════
       PAGE BACKGROUND MEDIA
    ═══════════════════════════════════════════════════════════ */
    .af-page-bg {
        position: fixed;
        inset: 0;
        z-index: -1;
        overflow: hidden;
        pointer-events: none;
    }
    .af-page-bg__img {
        position: absolute;
        inset: 0;
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
    }
    .af-page-bg__vid {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .af-page-bg__overlay {
        position: absolute;
        inset: 0;
    }

    /* ═══════════════════════════════════════════════════════════
       SCROLL ANIMATIONS
    ═══════════════════════════════════════════════════════════ */
    @if($contentAnims)
    .af-block-wrapper {
        opacity: 0;
        transform: translateY(22px);
        transition: opacity .65s ease, transform .65s ease;
        will-change: opacity, transform;
    }
    .af-block-wrapper.af-in {
        opacity: 1;
        transform: translateY(0);
    }
    @media (prefers-reduced-motion: reduce) {
        .af-block-wrapper { opacity: 1 !important; transform: none !important; transition: none !important; }
    }
    @endif

    /* ═══════════════════════════════════════════════════════════
       TOOLTIPS — aparece abaixo dos itens do header
    ═══════════════════════════════════════════════════════════ */
    [data-tooltip] { position: relative; }
    [data-tooltip]::after {
        content: attr(data-tooltip);
        position: absolute;
        top: calc(100% + 9px);
        left: 50%;
        transform: translateX(-50%) translateY(-4px);
        background: var(--bg-invert);
        color: var(--text-invert);
        font-family: var(--font);
        font-size: .68rem;
        font-weight: 600;
        white-space: nowrap;
        padding: .27rem .62rem;
        border-radius: var(--radius-sm);
        pointer-events: none;
        opacity: 0;
        transition: opacity .18s ease, transform .18s ease;
        z-index: 9999;
        letter-spacing: .025em;
        box-shadow: var(--shadow-sm);
    }
    [data-tooltip]::before {
        content: '';
        position: absolute;
        top: calc(100% + 5px);
        left: 50%;
        transform: translateX(-50%);
        border: 4px solid transparent;
        border-bottom-color: var(--bg-invert);
        pointer-events: none;
        opacity: 0;
        transition: opacity .18s ease;
        z-index: 9999;
    }
    [data-tooltip]:hover::after,
    [data-tooltip]:focus-visible::after  { opacity: 1; transform: translateX(-50%) translateY(0); }
    [data-tooltip]:hover::before,
    [data-tooltip]:focus-visible::before { opacity: 1; }
    /* Esconder tooltips em mobile (menus já mostram label) */
    @media (max-width: 640px) {
        [data-tooltip]::after,
        [data-tooltip]::before { display: none; }
    }

    /* ═══════════════════════════════════════════════════════════
       TESTIMONIALS
    ═══════════════════════════════════════════════════════════ */
    .af-testimonials__heading {
        text-align: center; font-size: clamp(1.75rem, 3.5vw, 2.5rem);
        font-weight: 800; letter-spacing: -.03em; margin-bottom: 3rem; color: var(--text);
    }
    .af-testimonials__grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.25rem; }
    .af-testimonial-card {
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 1.75rem; display: flex; flex-direction: column; gap: .875rem;
        transition: box-shadow var(--transition), transform var(--transition), border-color var(--transition);
    }
    .af-testimonial-card:hover { box-shadow: var(--shadow-lg); transform: translateY(-3px); border-color: rgba(99,102,241,.25); }
    [data-theme="dark"] .af-testimonial-card { background: var(--bg-subtle); }
    .af-testimonial-card__stars { display: flex; gap: .15rem; }
    .af-star--filled { color: #f59e0b; font-size: .95rem; }
    .af-star--empty  { color: var(--border-strong); font-size: .95rem; }
    .af-testimonial-card__quote {
        font-size: .96rem; color: var(--text-2); line-height: 1.78;
        font-style: italic; flex: 1; margin: 0;
        position: relative; padding-left: 1.1rem;
    }
    .af-testimonial-card__quote::before {
        content: '"'; position: absolute; left: 0; top: -.15rem;
        font-size: 1.8rem; color: var(--primary); line-height: 1; font-style: normal; font-weight: 900;
    }
    .af-testimonial-card__footer { display: flex; align-items: center; gap: .875rem; margin-top: auto; }
    .af-testimonial-card__avatar {
        width: 44px; height: 44px; border-radius: 50%; object-fit: cover; flex-shrink: 0;
        border: 2px solid var(--border);
    }
    .af-testimonial-card__avatar--initials {
        background: linear-gradient(135deg, var(--primary), var(--accent));
        color: #fff; font-size: 1.05rem; font-weight: 800;
        display: flex; align-items: center; justify-content: center;
    }
    .af-testimonial-card__name { font-size: .9rem; font-weight: 700; color: var(--text); }
    .af-testimonial-card__role { font-size: .8rem; color: var(--text-muted); margin-top: .1rem; }

    /* ═══════════════════════════════════════════════════════════
       PRICING
    ═══════════════════════════════════════════════════════════ */
    .af-pricing__heading {
        text-align: center; font-size: clamp(1.75rem, 3.5vw, 2.5rem);
        font-weight: 800; letter-spacing: -.03em; margin-bottom: .875rem; color: var(--text);
    }
    .af-pricing__sub { text-align: center; font-size: 1.05rem; color: var(--text-muted); margin-bottom: 3rem; }
    .af-pricing__grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1.25rem; align-items: start; }
    .af-pricing-card {
        background: var(--bg); border: 1.5px solid var(--border); border-radius: var(--radius-xl);
        padding: 2.25rem 2rem; position: relative; display: flex; flex-direction: column; gap: 1.25rem;
        transition: box-shadow var(--transition), transform var(--transition);
    }
    .af-pricing-card:hover { box-shadow: var(--shadow-lg); transform: translateY(-2px); }
    .af-pricing-card--featured {
        border-color: var(--primary);
        box-shadow: 0 0 0 2px var(--primary-soft), var(--shadow-xl);
    }
    .af-pricing-card--featured:hover { box-shadow: 0 0 0 2px var(--primary), var(--shadow-xl); }
    [data-theme="dark"] .af-pricing-card { background: var(--bg-subtle); }
    .af-pricing-card__badge {
        position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
        background: linear-gradient(135deg, var(--primary), var(--accent));
        color: #fff; font-size: .7rem; font-weight: 700; letter-spacing: .08em;
        text-transform: uppercase; padding: .28rem .9rem; border-radius: 99px; white-space: nowrap;
    }
    .af-pricing-card__name {
        font-size: .85rem; font-weight: 700; color: var(--text-muted);
        text-transform: uppercase; letter-spacing: .08em;
    }
    .af-pricing-card__price { display: flex; align-items: baseline; gap: .3rem; }
    .af-pricing-card__amount { font-size: 3rem; font-weight: 900; letter-spacing: -.04em; color: var(--text); line-height: 1; }
    .af-pricing-card__period { font-size: .9rem; color: var(--text-muted); }
    .af-pricing-card__desc { font-size: .9rem; color: var(--text-muted); line-height: 1.6; margin: 0; }
    .af-pricing-card__features { list-style: none; display: flex; flex-direction: column; gap: .6rem; flex: 1; }
    .af-pricing-card__features li {
        font-size: .9rem; color: var(--text-2); display: flex; align-items: flex-start; gap: .6rem;
    }
    .af-pricing-card__features li::before {
        content: '✓'; color: var(--primary); font-weight: 800;
        flex-shrink: 0; margin-top: 1px;
    }
    .af-pricing-card .af-btn { width: 100%; justify-content: center; margin-top: auto; }

    /* ═══════════════════════════════════════════════════════════
       GALLERY
    ═══════════════════════════════════════════════════════════ */
    .af-gallery__heading {
        text-align: center; font-size: clamp(1.75rem, 3.5vw, 2.5rem);
        font-weight: 800; letter-spacing: -.03em; margin-bottom: 3rem; color: var(--text);
    }
    .af-gallery__grid { display: grid; gap: .875rem; }
    .af-gallery__grid--2 { grid-template-columns: repeat(2, 1fr); }
    .af-gallery__grid--3 { grid-template-columns: repeat(3, 1fr); }
    .af-gallery__grid--4 { grid-template-columns: repeat(4, 1fr); }
    @media (max-width: 768px) {
        .af-gallery__grid--3, .af-gallery__grid--4 { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 480px) {
        .af-gallery__grid--2, .af-gallery__grid--3, .af-gallery__grid--4 { grid-template-columns: 1fr; }
    }
    .af-gallery-item { margin: 0; overflow: hidden; border-radius: var(--radius-lg); }
    .af-gallery-item__link {
        display: block; position: relative; overflow: hidden; border-radius: var(--radius-lg);
        background: var(--bg-muted);
    }
    .af-gallery-item__img { width: 100%; height: 220px; object-fit: cover; display: block; transition: transform .4s ease; }
    .af-gallery-item__link:hover .af-gallery-item__img { transform: scale(1.06); }
    .af-gallery-item__overlay {
        position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
        background: rgba(0,0,0,.38); color: #fff; opacity: 0; transition: opacity .3s ease;
    }
    .af-gallery-item__link:hover .af-gallery-item__overlay { opacity: 1; }
    .af-gallery-item__caption { font-size: .8rem; color: var(--text-muted); margin-top: .45rem; text-align: center; padding: 0 .25rem; }
    /* Lightbox */
    .af-lightbox {
        display: none; position: fixed; inset: 0; z-index: 10000;
        background: rgba(0,0,0,.92); align-items: center; justify-content: center;
        padding: 2rem;
    }
    .af-lightbox.active { display: flex; flex-direction: column; gap: 1rem; }
    .af-lightbox__img { max-width: 92vw; max-height: 80vh; object-fit: contain; border-radius: var(--radius-lg); }
    .af-lightbox__close {
        position: fixed; top: 1.25rem; right: 1.5rem;
        background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.2);
        color: #fff; font-size: 1.5rem; cursor: pointer; width: 44px; height: 44px;
        border-radius: 50%; display: flex; align-items: center; justify-content: center;
        transition: background .2s;
    }
    .af-lightbox__close:hover { background: rgba(255,255,255,.25); }
    .af-lightbox__caption { color: rgba(255,255,255,.75); font-size: .88rem; text-align: center; max-width: 600px; }

    /* ═══════════════════════════════════════════════════════════
       FAQ
    ═══════════════════════════════════════════════════════════ */
    .af-faq__heading {
        text-align: center; font-size: clamp(1.75rem, 3.5vw, 2.5rem);
        font-weight: 800; letter-spacing: -.03em; margin-bottom: 3rem; color: var(--text);
    }
    .af-faq__list { max-width: 740px; margin: 0 auto; display: flex; flex-direction: column; gap: .625rem; }
    .af-faq-item {
        border: 1.5px solid var(--border); border-radius: var(--radius-lg); overflow: hidden;
        transition: border-color var(--transition), box-shadow var(--transition);
    }
    .af-faq-item--open { border-color: var(--primary); box-shadow: 0 0 0 3px var(--primary-soft); }
    [data-theme="dark"] .af-faq-item { background: var(--bg-subtle); }
    .af-faq-item__question {
        width: 100%; display: flex; align-items: center; justify-content: space-between; gap: 1rem;
        background: none; border: none; text-align: left;
        font-family: var(--font); font-size: 1rem; font-weight: 600; color: var(--text);
        padding: 1.15rem 1.4rem; cursor: pointer; transition: color var(--transition);
    }
    .af-faq-item__question:hover { color: var(--primary); }
    .af-faq-item--open .af-faq-item__question { color: var(--primary); }
    .af-faq-item__icon {
        font-size: 1.25rem; font-weight: 300; color: var(--text-muted);
        flex-shrink: 0; transition: transform .22s ease;
        width: 24px; height: 24px; display: flex; align-items: center; justify-content: center;
    }
    .af-faq-item--open .af-faq-item__icon { transform: rotate(45deg); color: var(--primary); }
    .af-faq-item__answer { display: none; padding: 0 1.4rem 1.25rem; }
    .af-faq-item--open .af-faq-item__answer { display: block; }
    .af-faq-item__answer p { font-size: .95rem; color: var(--text-muted); line-height: 1.78; margin: 0; }

    /* ═══════════════════════════════════════════════════════════
       CONTACT
    ═══════════════════════════════════════════════════════════ */
    .af-contact { max-width: 680px; margin: 0 auto; }
    .af-contact__heading {
        font-size: clamp(1.75rem, 3.5vw, 2.5rem); font-weight: 800; letter-spacing: -.03em;
        margin-bottom: .875rem; color: var(--text); text-align: center;
    }
    .af-contact__sub { font-size: 1.05rem; color: var(--text-muted); text-align: center; margin-bottom: 2.75rem; }
    .af-contact__form { display: flex; flex-direction: column; gap: 1.25rem; }
    .af-contact__row { display: grid; grid-template-columns: 1fr 1fr; gap: 1.25rem; }
    @media (max-width: 520px) { .af-contact__row { grid-template-columns: 1fr; } }
    .af-contact__field { display: flex; flex-direction: column; gap: .4rem; }
    .af-contact__field label { font-size: .84rem; font-weight: 600; color: var(--text-2); }
    .af-contact__field label span { color: var(--danger); }
    .af-contact__field input,
    .af-contact__field textarea {
        background: var(--bg); border: 1.5px solid var(--border); border-radius: var(--radius);
        padding: .7rem 1rem; font-family: var(--font); font-size: .95rem; color: var(--text);
        transition: border-color var(--transition), box-shadow var(--transition);
        outline: none; resize: vertical; width: 100%;
    }
    .af-contact__field input:focus,
    .af-contact__field textarea:focus {
        border-color: var(--primary); box-shadow: 0 0 0 3px var(--primary-soft);
    }
    [data-theme="dark"] .af-contact__field input,
    [data-theme="dark"] .af-contact__field textarea { background: var(--bg-subtle); border-color: var(--border); }
    .af-contact__status { font-size: .85rem; min-height: 1.2rem; }
    .af-contact__form .af-btn { align-self: flex-start; }

    /* ═══════════════════════════════════════════════════════════
       NEWSLETTER
    ═══════════════════════════════════════════════════════════ */
    .af-newsletter { text-align: center; max-width: 560px; margin: 0 auto; }
    .af-newsletter__heading {
        font-size: clamp(1.75rem, 3.5vw, 2.5rem); font-weight: 800; letter-spacing: -.03em;
        margin-bottom: .875rem; color: inherit;
    }
    .af-newsletter__sub { font-size: 1.05rem; color: var(--text-muted); margin-bottom: 2rem; line-height: 1.65; }
    .af-section--dark .af-newsletter__sub { color: #8fa3c4; }
    .af-newsletter__form {
        display: flex; gap: .75rem; max-width: 460px; margin: 0 auto; flex-wrap: wrap; justify-content: center;
    }
    .af-newsletter__input {
        flex: 1; min-width: 200px;
        background: var(--bg); border: 1.5px solid var(--border); border-radius: var(--radius-lg);
        padding: .7rem 1.2rem; font-family: var(--font); font-size: .95rem; color: var(--text);
        outline: none; transition: border-color var(--transition), box-shadow var(--transition);
    }
    .af-newsletter__input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px var(--primary-soft); }
    .af-newsletter__input::placeholder { color: var(--text-muted); }
    .af-section--dark .af-newsletter__input {
        background: rgba(255,255,255,.08); border-color: rgba(255,255,255,.15); color: #f0f4ff;
    }
    .af-section--dark .af-newsletter__input::placeholder { color: rgba(255,255,255,.4); }
    .af-newsletter__note { font-size: .78rem; color: var(--text-muted); margin-top: .875rem; opacity: .75; }
    .af-section--dark .af-newsletter__note { color: #8fa3c4; }
    .af-newsletter__feedback { font-size: .85rem; margin-top: .75rem; min-height: 1.2rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       SHARED BLOCK HEADING — used by many section blocks
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-section-header { text-align: center; margin-bottom: 3rem; }
    .af-section-header h2 {
        font-size: clamp(1.75rem, 3.5vw, 2.5rem); font-weight: 800;
        letter-spacing: -.035em; color: var(--text); line-height: 1.12;
        margin-bottom: .75rem;
    }
    .af-section-header p {
        font-size: 1.05rem; color: var(--text-muted);
        max-width: 600px; margin: 0 auto; line-height: 1.7;
    }
    .af-section-eyebrow {
        display: inline-flex; align-items: center; gap: .4rem; margin-bottom: 1rem;
        font-size: .72rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase;
        color: var(--primary); background: var(--primary-soft); padding: .28rem .8rem;
        border-radius: 99px; border: 1px solid rgba(99,102,241,.15);
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: columns
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-columns { padding: var(--section-y) 0; }
    .af-columns__grid { display: grid; gap: 2rem; }
    .af-columns--cols-2 .af-columns__grid { grid-template-columns: repeat(2,1fr); }
    .af-columns--cols-3 .af-columns__grid { grid-template-columns: repeat(3,1fr); }
    .af-columns--cols-4 .af-columns__grid { grid-template-columns: repeat(4,1fr); }
    .af-columns--gap-tight .af-columns__grid { gap: 1rem; }
    .af-columns--gap-wide  .af-columns__grid { gap: 3.5rem; }
    .af-columns--align-center .af-columns__item { text-align: center; }
    .af-columns--align-bottom .af-columns__item { display: flex; flex-direction: column; justify-content: flex-end; }
    .af-columns__image img { width: 100%; border-radius: var(--radius-lg); margin-bottom: 1rem; }
    .af-columns__body h3 { font-size: 1.25rem; font-weight: 700; margin-bottom: .5rem; color: var(--text); }
    .af-columns__body p  { color: var(--text-muted); line-height: 1.7; margin-bottom: 1rem; }
    .af-eyebrow { font-size: .72rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; color: var(--primary); display: block; margin-bottom: .5rem; }
    @media(max-width:768px){
        .af-columns--cols-2 .af-columns__grid,
        .af-columns--cols-3 .af-columns__grid,
        .af-columns--cols-4 .af-columns__grid { grid-template-columns: 1fr; }
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: image
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-image-block { padding: var(--section-y) 0; }
    .af-image-block--full  .af-image-block__figure { max-width: 100%; }
    .af-image-block--large .af-image-block__figure { max-width: 960px; }
    .af-image-block--medium .af-image-block__figure { max-width: 640px; }
    .af-image-block--center .af-image-block__figure { margin: 0 auto; }
    .af-image-block--left   .af-image-block__figure { margin-right: auto; }
    .af-image-block--right  .af-image-block__figure { margin-left: auto; }
    .af-image-block__figure img { width: 100%; display: block; }
    .af-image-block--rounded .af-image-block__figure img { border-radius: var(--radius-xl); }
    .af-image-block--shadow  .af-image-block__figure img { box-shadow: var(--shadow-xl); }
    .af-image-block__figure figcaption { text-align: center; font-size: .82rem; color: var(--text-muted); margin-top: .625rem; }
    .af-image-block__placeholder { background: var(--bg-alt); border: 2px dashed var(--border); border-radius: var(--radius-lg); height: 300px; display: flex; align-items: center; justify-content: center; font-size: 2rem; color: var(--text-muted); }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: stats
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-stats { padding: var(--section-py) 0; }
    .af-stats__heading {
        text-align: center; font-size: clamp(1.75rem, 3.5vw, 2.5rem);
        font-weight: 800; letter-spacing: -.03em; margin-bottom: 3rem; color: var(--text);
    }
    .af-stats__grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px,1fr)); gap: 1.25rem; }
    .af-stats__item {
        position: relative; text-align: center;
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 2rem 1.5rem 1.75rem;
        box-shadow: var(--shadow-sm);
        transition: box-shadow var(--transition), transform var(--transition), border-color var(--transition);
        overflow: hidden;
    }
    .af-stats__item::before {
        content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px;
        background: linear-gradient(90deg, var(--primary), var(--accent));
    }
    .af-stats__item:hover { box-shadow: var(--shadow-lg); transform: translateY(-3px); border-color: rgba(99,102,241,.25); }
    [data-theme="dark"] .af-stats__item { background: var(--bg-subtle); }
    [data-theme="dark"] .af-stats__item:hover { border-color: rgba(129,140,248,.3); }
    .af-stats__icon { font-size: 1.75rem; margin-bottom: .75rem; display: block; }
    .af-stats__value {
        font-size: clamp(2.25rem, 5vw, 3.25rem); font-weight: 900; line-height: 1;
        margin-bottom: .5rem; letter-spacing: -.04em;
        background: linear-gradient(135deg, var(--primary), var(--accent));
        -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
    }
    .af-stats__label { font-size: .82rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase; letter-spacing: .07em; }
    .af-stats__sublabel { font-size: .78rem; color: var(--text-muted); margin-top: .25rem; opacity: .7; }
    /* Dark band variant */
    .af-stats--dark { background: linear-gradient(135deg, #080d1a, #110a2e); border-radius: var(--radius-xl); }
    .af-stats--dark .af-stats__item { background: rgba(255,255,255,.04); border-color: rgba(255,255,255,.08); }
    .af-stats--dark .af-stats__item:hover { background: rgba(255,255,255,.07); border-color: rgba(129,140,248,.25); }
    .af-stats--dark .af-stats__label { color: rgba(255,255,255,.5); }
    /* Minimal variant */
    .af-stats--minimal .af-stats__item { border: none; box-shadow: none; background: transparent; padding: 1rem; }
    .af-stats--minimal .af-stats__item::before { display: none; }
    .af-stats--minimal .af-stats__item:hover { transform: none; box-shadow: none; }
    .af-stats--minimal .af-stats__value { font-size: 2.25rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: logocloud
    ═══════════════════════════════════════════════════════════════════════════ */
    @keyframes af-marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
    .af-logocloud {
        padding: 3.5rem 0;
        border-top: 1px solid var(--border); border-bottom: 1px solid var(--border);
        background: var(--bg-subtle);
    }
    [data-theme="dark"] .af-logocloud { background: var(--bg-subtle); }
    .af-logocloud__heading {
        text-align: center; font-size: .72rem; font-weight: 700; letter-spacing: .1em;
        text-transform: uppercase; color: var(--text-muted); margin-bottom: 2rem;
    }
    /* Static layout */
    .af-logocloud__track {
        display: flex; flex-wrap: wrap; align-items: center; justify-content: center; gap: 2rem 3.5rem;
    }
    .af-logocloud__item img { height: 28px; object-fit: contain; max-width: 130px; }
    /* Scrolling marquee variant */
    .af-logocloud--scroll { overflow: hidden; position: relative; }
    .af-logocloud--scroll::before,
    .af-logocloud--scroll::after {
        content: ''; position: absolute; top: 0; bottom: 0; width: 100px; z-index: 2; pointer-events: none;
    }
    .af-logocloud--scroll::before { left: 0; background: linear-gradient(to right, var(--bg-subtle), transparent); }
    .af-logocloud--scroll::after  { right: 0; background: linear-gradient(to left, var(--bg-subtle), transparent); }
    .af-logocloud--scroll .af-logocloud__track {
        flex-wrap: nowrap; width: max-content; animation: af-marquee 28s linear infinite;
        gap: 0 4rem;
    }
    .af-logocloud--scroll:hover .af-logocloud__track { animation-play-state: paused; }
    .af-logocloud--scroll .af-logocloud__item { flex-shrink: 0; padding: 0 .5rem; }
    /* Grayscale hover */
    .af-logocloud--grayscale .af-logocloud__item img {
        filter: grayscale(1) opacity(.5); transition: filter .25s ease;
    }
    .af-logocloud--grayscale .af-logocloud__item:hover img { filter: grayscale(0) opacity(1); }
    .af-logocloud__placeholder { font-size: .85rem; font-weight: 600; color: var(--text-muted); padding: .5rem 1rem; border: 1px dashed var(--border); border-radius: var(--radius-sm); }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: spacer
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-spacer { position: relative; display: flex; align-items: center; justify-content: center; }
    .af-spacer--xs  { height: 1rem; }
    .af-spacer--sm  { height: 2rem; }
    .af-spacer--md  { height: 4rem; }
    .af-spacer--lg  { height: 6rem; }
    .af-spacer--xl  { height: 9rem; }
    .af-spacer--divider::before { content: ''; position: absolute; inset-inline: 0; top: 50%; height: 1px; background: var(--border); }
    .af-spacer__label { position: relative; background: var(--bg); padding: 0 1rem; font-size: .78rem; color: var(--text-muted); }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: video
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-video { padding: var(--section-y) 0; }
    .af-ratio { position: relative; width: 100%; overflow: hidden; border-radius: var(--radius-xl); background: #000; }
    .af-ratio--16-9 { padding-top: 56.25%; }
    .af-ratio--4-3  { padding-top: 75%; }
    .af-ratio--1-1  { padding-top: 100%; }
    .af-ratio iframe, .af-ratio video { position: absolute; inset: 0; width: 100%; height: 100%; }
    .af-video__placeholder { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; font-size: 3rem; background: var(--bg-alt); color: var(--text-muted); }
    .af-video__caption { text-align: center; font-size: .82rem; color: var(--text-muted); margin-top: .75rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: richtext
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-richtext { padding: var(--section-y) 0; }
    .af-richtext--narrow  .af-richtext__body { max-width: 640px; margin: 0 auto; }
    .af-richtext--normal  .af-richtext__body { max-width: 800px; margin: 0 auto; }
    .af-richtext--wide    .af-richtext__body { max-width: 1080px; margin: 0 auto; }
    .af-richtext__body { line-height: 1.8; color: var(--text); }
    .af-richtext__body h1, .af-richtext__body h2, .af-richtext__body h3,
    .af-richtext__body h4, .af-richtext__body h5, .af-richtext__body h6 { margin-top: 1.5em; margin-bottom: .5em; font-weight: 700; color: var(--text); }
    .af-richtext__body p   { margin-bottom: 1em; }
    .af-richtext__body a   { color: var(--primary); text-decoration: underline; }
    .af-richtext__body ul, .af-richtext__body ol { padding-left: 1.5rem; margin-bottom: 1em; }
    .af-richtext__body li  { margin-bottom: .25em; }
    .af-richtext__body blockquote { border-left: 4px solid var(--primary); padding: .75rem 1.25rem; margin: 1.5rem 0; background: var(--bg-alt); border-radius: 0 var(--radius-sm) var(--radius-sm) 0; color: var(--text-muted); font-style: italic; }
    .af-richtext__body pre  { background: #0f1117; color: #e8edf5; border-radius: var(--radius-md); padding: 1.25rem; overflow-x: auto; font-size: .85rem; margin-bottom: 1em; }
    .af-richtext__body code { font-family: 'JetBrains Mono', 'Fira Code', monospace; }
    .af-richtext__body img  { max-width: 100%; border-radius: var(--radius-md); }
    .af-richtext__body hr   { border: none; border-top: 1px solid var(--border); margin: 2rem 0; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: team
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-team { padding: var(--section-py) 0; }
    .af-team__heading {
        text-align: center; font-size: clamp(1.75rem, 3.5vw, 2.5rem);
        font-weight: 800; letter-spacing: -.03em; margin-bottom: .75rem; color: var(--text);
    }
    .af-team__sub { text-align: center; font-size: 1.05rem; color: var(--text-muted); margin-bottom: 3rem; }
    .af-team__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px,1fr)); gap: 1.5rem; }
    .af-team__photo {
        width: 88px; height: 88px; border-radius: 50%; overflow: hidden; margin-bottom: 1.125rem;
        background: linear-gradient(135deg, var(--primary-soft), rgba(139,92,246,.08));
        border: 3px solid var(--border);
        transition: border-color var(--transition), box-shadow var(--transition);
    }
    .af-team__member:hover .af-team__photo { border-color: var(--primary); box-shadow: 0 0 0 4px var(--primary-soft); }
    .af-team__photo img { width: 100%; height: 100%; object-fit: cover; }
    .af-team__photo-placeholder { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 1.5rem; color: var(--primary); background: linear-gradient(135deg, var(--primary-soft), rgba(139,92,246,.12)); }
    .af-team__name { font-size: 1.125rem; font-weight: 700; margin-bottom: .25rem; color: var(--text); letter-spacing: -.02em; }
    .af-team__role { font-size: .82rem; color: var(--primary); font-weight: 700; margin-bottom: .625rem; text-transform: uppercase; letter-spacing: .04em; }
    .af-team__bio  { font-size: .875rem; color: var(--text-muted); line-height: 1.7; margin-bottom: .875rem; }
    .af-team__social { display: flex; gap: .5rem; }
    .af-team__social-link {
        display: inline-flex; align-items: center; justify-content: center;
        width: 32px; height: 32px; border-radius: 50%;
        background: var(--bg-muted); border: 1.5px solid var(--border);
        font-size: .85rem; font-weight: 700; color: var(--text-muted); text-decoration: none;
        transition: all .18s ease;
    }
    .af-team__social-link:hover { background: var(--primary); color: #fff; border-color: var(--primary); transform: translateY(-2px); }
    /* Cards variant */
    .af-team--cards .af-team__member {
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 2rem 1.75rem; box-shadow: var(--shadow-sm);
        transition: transform var(--transition), box-shadow var(--transition), border-color var(--transition);
    }
    .af-team--cards .af-team__member:hover { transform: translateY(-4px); box-shadow: var(--shadow-xl); border-color: rgba(99,102,241,.2); }
    [data-theme="dark"] .af-team--cards .af-team__member { background: var(--bg-subtle); }
    .af-team--minimal .af-team__member { border-bottom: 1px solid var(--border); padding-bottom: 1.5rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: steps
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-steps { padding: var(--section-py) 0; }
    .af-steps__heading {
        text-align: center; font-size: clamp(1.75rem, 3.5vw, 2.5rem);
        font-weight: 800; letter-spacing: -.03em; margin-bottom: .75rem; color: var(--text);
    }
    .af-steps__sub { text-align: center; font-size: 1.05rem; color: var(--text-muted); margin-bottom: 3rem; }
    .af-steps__list { list-style: none; padding: 0; margin: 0; }
    .af-steps--vertical .af-steps__list { display: flex; flex-direction: column; gap: 0; }
    .af-steps--horizontal .af-steps__list { display: flex; flex-direction: row; gap: 1.5rem; }
    .af-steps--cards .af-steps__list { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px,1fr)); gap: 1.5rem; }
    .af-steps__item { display: flex; gap: 1.25rem; position: relative; padding-bottom: 2.25rem; }
    .af-steps--vertical .af-steps__item:not(:last-child)::before {
        content: ''; position: absolute; left: 1.3125rem; top: 2.625rem; bottom: .5rem; width: 2px;
        background: linear-gradient(to bottom, var(--primary), var(--border));
    }
    .af-steps__number {
        flex-shrink: 0; width: 2.625rem; height: 2.625rem; border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), var(--accent));
        color: #fff; display: flex; align-items: center; justify-content: center;
        font-weight: 800; font-size: .875rem; z-index: 1;
        box-shadow: 0 4px 14px rgba(99,102,241,.35);
        transition: box-shadow var(--transition), transform var(--transition);
    }
    .af-steps__item:hover .af-steps__number { box-shadow: 0 6px 20px rgba(99,102,241,.5); transform: scale(1.08); }
    .af-steps__content h3 { font-size: 1.0625rem; font-weight: 700; color: var(--text); margin-bottom: .4rem; }
    .af-steps__content p  { font-size: .9rem; color: var(--text-muted); line-height: 1.7; }
    /* Cards variant */
    .af-steps--cards .af-steps__item {
        flex-direction: column; align-items: flex-start;
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 1.75rem; gap: 1rem;
        box-shadow: var(--shadow-sm);
        transition: box-shadow var(--transition), transform var(--transition), border-color var(--transition);
    }
    .af-steps--cards .af-steps__item::before { display: none; }
    .af-steps--cards .af-steps__item:hover { box-shadow: var(--shadow-lg); transform: translateY(-3px); border-color: rgba(99,102,241,.25); }
    [data-theme="dark"] .af-steps--cards .af-steps__item { background: var(--bg-subtle); }
    @media(max-width:640px){ .af-steps--horizontal .af-steps__list { flex-direction: column; } }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: icongrid
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-icongrid { padding: var(--section-py) 0; }
    .af-icongrid__heading {
        text-align: center; font-size: clamp(1.75rem, 3.5vw, 2.5rem);
        font-weight: 800; letter-spacing: -.03em; margin-bottom: .75rem; color: var(--text);
    }
    .af-icongrid__sub { text-align: center; font-size: 1.05rem; color: var(--text-muted); margin-bottom: 3rem; }
    .af-icongrid__grid { display: grid; gap: 1.25rem; grid-template-columns: repeat(4,1fr); }
    .af-icongrid--cols-2 .af-icongrid__grid { grid-template-columns: repeat(2,1fr); }
    .af-icongrid--cols-3 .af-icongrid__grid { grid-template-columns: repeat(3,1fr); }
    .af-icongrid--cols-6 .af-icongrid__grid { grid-template-columns: repeat(6,1fr); }
    .af-icongrid__icon {
        font-size: 2rem; margin-bottom: .75rem;
        width: 54px; height: 54px; display: flex; align-items: center; justify-content: center;
        background: linear-gradient(135deg, var(--primary-soft), rgba(139,92,246,.06));
        border-radius: var(--radius-lg); border: 1px solid rgba(99,102,241,.12);
        transition: box-shadow var(--transition);
    }
    .af-icongrid__label { font-size: 1rem; font-weight: 700; color: var(--text); margin-bottom: .375rem; letter-spacing: -.01em; }
    .af-icongrid__text  { font-size: .85rem; color: var(--text-muted); line-height: 1.65; }
    .af-icongrid--cards .af-icongrid__item {
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 1.75rem; box-shadow: var(--shadow-xs);
        transition: box-shadow var(--transition), transform var(--transition), border-color var(--transition);
    }
    .af-icongrid--cards .af-icongrid__item:hover {
        box-shadow: var(--shadow-lg); transform: translateY(-3px); border-color: rgba(99,102,241,.2);
    }
    .af-icongrid--cards .af-icongrid__item:hover .af-icongrid__icon { box-shadow: 0 0 16px rgba(99,102,241,.3); }
    [data-theme="dark"] .af-icongrid--cards .af-icongrid__item { background: var(--bg-subtle); }
    @media(max-width:768px){ .af-icongrid__grid { grid-template-columns: repeat(2,1fr) !important; } }
    @media(max-width:420px){ .af-icongrid__grid { grid-template-columns: 1fr !important; } }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: tabs
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-tabs { padding: var(--section-y) 0; }
    .af-tabs__nav { display: flex; flex-wrap: wrap; gap: .5rem; border-bottom: 2px solid var(--border); margin-bottom: 1.75rem; padding-bottom: 0; }
    .af-tabs__tab { padding: .625rem 1.125rem; font-size: .875rem; font-weight: 600; color: var(--text-muted); background: none; border: none; border-bottom: 2px solid transparent; margin-bottom: -2px; cursor: pointer; transition: color var(--transition), border-color var(--transition); border-radius: var(--radius-sm) var(--radius-sm) 0 0; }
    .af-tabs__tab:hover { color: var(--primary); }
    .af-tabs__tab.is-active { color: var(--primary); border-bottom-color: var(--primary); }
    .af-tabs__panel { display: none; }
    .af-tabs__panel.is-active { display: block; animation: fadeIn .18s ease; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: timeline
    ═══════════════════════════════════════════════════════════════════════════ */
    @keyframes af-dot-pulse {
        0%,100% { box-shadow: 0 0 0 0 rgba(99,102,241,.5), 0 0 0 3px var(--primary); }
        50%      { box-shadow: 0 0 0 6px rgba(99,102,241,.0), 0 0 0 3px var(--primary); }
    }
    .af-timeline { padding: var(--section-py) 0; }
    .af-timeline__heading {
        text-align: center; font-size: clamp(1.75rem, 3.5vw, 2.5rem);
        font-weight: 800; letter-spacing: -.03em; margin-bottom: 3rem; color: var(--text);
    }
    .af-timeline__track { position: relative; padding: 1rem 0; }
    .af-timeline__track::before {
        content: ''; position: absolute; left: 50%; top: 0; bottom: 0; width: 2px;
        background: linear-gradient(to bottom, transparent, var(--primary) 15%, var(--border) 85%, transparent);
        transform: translateX(-50%);
    }
    .af-timeline__item { display: flex; justify-content: flex-end; width: 50%; padding-right: 2.75rem; position: relative; margin-bottom: 2.25rem; }
    .af-timeline__item--right { justify-content: flex-start; margin-left: 50%; padding-right: 0; padding-left: 2.75rem; }
    .af-timeline__dot {
        position: absolute; right: -10px; top: 1rem;
        width: 20px; height: 20px; border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), var(--accent));
        border: 3px solid var(--bg);
        box-shadow: 0 0 0 3px var(--primary);
        animation: af-dot-pulse 2.5s ease-in-out infinite;
        z-index: 2;
    }
    .af-timeline__item--right .af-timeline__dot { right: auto; left: -10px; }
    .af-timeline__card {
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 1.375rem 1.625rem; max-width: 380px;
        box-shadow: var(--shadow-md);
        transition: box-shadow var(--transition), transform var(--transition), border-color var(--transition);
    }
    .af-timeline__card:hover { box-shadow: var(--shadow-lg); transform: translateY(-2px); border-color: rgba(99,102,241,.25); }
    [data-theme="dark"] .af-timeline__card { background: var(--bg-subtle); }
    .af-timeline__date {
        display: inline-flex; align-items: center; gap: .35rem;
        font-size: .72rem; font-weight: 700; text-transform: uppercase; letter-spacing: .07em;
        color: var(--primary); margin-bottom: .5rem;
        background: var(--primary-soft); padding: .2rem .6rem; border-radius: 99px;
    }
    .af-timeline__card h3 { font-size: 1.0625rem; font-weight: 700; color: var(--text); margin-bottom: .4rem; }
    .af-timeline__card p  { font-size: .875rem; color: var(--text-muted); line-height: 1.7; }
    @media(max-width:640px){
        .af-timeline__track::before { left: 16px; }
        .af-timeline__item, .af-timeline__item--right { width: 100%; margin-left: 0; padding-left: 3rem; padding-right: 0; justify-content: flex-start; }
        .af-timeline__dot, .af-timeline__item--right .af-timeline__dot { left: 6px; right: auto; }
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: banner
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-banner { padding: .75rem 0; font-size: .875rem; font-weight: 500; }
    .af-banner__inner { display: flex; align-items: center; justify-content: center; gap: 1rem; flex-wrap: wrap; }
    .af-banner--info    { background: #eff6ff; color: #1e40af; border-bottom: 1px solid #bfdbfe; }
    .af-banner--success { background: #f0fdf4; color: #166534; border-bottom: 1px solid #bbf7d0; }
    .af-banner--warning { background: #fffbeb; color: #92400e; border-bottom: 1px solid #fde68a; }
    .af-banner--danger  { background: #fef2f2; color: #991b1b; border-bottom: 1px solid #fecaca; }
    .af-banner--promo   { background: var(--primary); color: #fff; }
    .af-banner__link { font-weight: 700; text-decoration: underline; color: inherit; white-space: nowrap; }
    [data-theme="dark"] .af-banner--info    { background: #1e3a5f; border-color: #2d5a9e; }
    [data-theme="dark"] .af-banner--success { background: #14442a; border-color: #1e6b3e; }
    [data-theme="dark"] .af-banner--warning { background: #422006; border-color: #92400e; }
    [data-theme="dark"] .af-banner--danger  { background: #450a0a; border-color: #991b1b; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: cards
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-cards { padding: var(--section-y) 0; }
    .af-cards__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 1.75rem; }
    .af-cards--cols-2 .af-cards__grid { grid-template-columns: repeat(2,1fr); }
    .af-cards--cols-4 .af-cards__grid { grid-template-columns: repeat(4,1fr); }
    .af-cards__card { background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl); overflow: hidden; box-shadow: var(--shadow); transition: transform var(--transition), box-shadow var(--transition); display: flex; flex-direction: column; }
    .af-cards__card:hover { transform: translateY(-4px); box-shadow: var(--shadow-xl); }
    .af-cards__image { aspect-ratio: 16/9; overflow: hidden; background: var(--bg-alt); }
    .af-cards__image img { width: 100%; height: 100%; object-fit: cover; transition: transform .35s; }
    .af-cards__card:hover .af-cards__image img { transform: scale(1.04); }
    .af-cards__body { padding: 1.25rem 1.5rem; display: flex; flex-direction: column; flex: 1; }
    .af-cards__tag  { font-size: .7rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; color: var(--primary); margin-bottom: .5rem; }
    .af-cards__title { font-size: 1.05rem; font-weight: 700; color: var(--text); margin-bottom: .5rem; line-height: 1.4; }
    .af-cards__text  { font-size: .875rem; color: var(--text-muted); line-height: 1.65; flex: 1; margin-bottom: .875rem; }
    .af-cards__link  { font-size: .85rem; font-weight: 600; color: var(--primary); text-decoration: none; align-self: flex-start; }
    .af-cards__link:hover { text-decoration: underline; }
    @media(max-width:768px){
        .af-cards__grid { grid-template-columns: 1fr !important; }
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: quote
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-quote { padding: var(--section-y) 0; }
    .af-quote__figure { max-width: 820px; margin: 0 auto; text-align: center; }
    .af-quote__figure blockquote { font-size: 1.6rem; font-weight: 700; line-height: 1.45; color: var(--text); margin: 0 0 1.25rem; }
    .af-quote--large .af-quote__figure blockquote { font-size: 2rem; }
    .af-quote--bordered { border-left: 4px solid var(--primary); text-align: left; padding-left: 2rem; }
    .af-quote--bordered .af-quote__figure blockquote { font-size: 1.25rem; }
    .af-quote--card .af-quote__figure { background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl); padding: 2.5rem; box-shadow: var(--shadow-xl); text-align: left; }
    .af-quote__caption { font-size: .88rem; color: var(--text-muted); }
    .af-quote__caption strong { color: var(--text); font-weight: 700; }
    .af-quote__caption cite { font-style: normal; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: map
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-map { padding: var(--section-y) 0; }
    .af-map__frame { border-radius: var(--radius-xl); overflow: hidden; border: 1px solid var(--border); }
    .af-map__placeholder { background: var(--bg-alt); border: 2px dashed var(--border); border-radius: var(--radius-xl); display: flex; align-items: center; justify-content: center; color: var(--text-muted); font-size: 1.25rem; }
    .af-map__address { text-align: center; font-size: .875rem; color: var(--text-muted); margin-top: .875rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: code
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-code { padding: var(--section-y) 0; }
    .af-code__block { position: relative; background: #0f1117; border-radius: var(--radius-xl); overflow: hidden; box-shadow: var(--shadow-xl); }
    .af-code__header { display: flex; align-items: center; justify-content: space-between; padding: .625rem 1.125rem; background: rgba(255,255,255,.05); border-bottom: 1px solid rgba(255,255,255,.07); }
    .af-code__filename { font-size: .8rem; color: rgba(255,255,255,.5); font-family: monospace; }
    .af-code__copy { font-size: .76rem; padding: .25rem .75rem; border-radius: var(--radius-sm); background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.15); color: rgba(255,255,255,.7); cursor: pointer; transition: background var(--transition); }
    .af-code__copy:hover { background: rgba(255,255,255,.18); }
    .af-code__copy--bare { position: absolute; top: .75rem; right: .75rem; }
    .af-code__pre { margin: 0; padding: 1.5rem; overflow-x: auto; font-size: .875rem; line-height: 1.7; color: #e8edf5; }
    .af-code__pre code { font-family: 'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: comparison
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-comparison { padding: var(--section-y) 0; }
    .af-comparison__scroll { overflow-x: auto; }
    .af-comparison__table { width: 100%; border-collapse: collapse; font-size: .9rem; }
    .af-comparison__table th { padding: 1rem 1.25rem; text-align: center; font-weight: 700; background: var(--bg-alt); border-bottom: 2px solid var(--border); color: var(--text); }
    .af-comparison__table td { padding: .875rem 1.25rem; text-align: center; border-bottom: 1px solid var(--border); color: var(--text-muted); }
    .af-comparison__feature-col,.af-comparison__feature-name { text-align: left !important; font-weight: 500; color: var(--text); }
    .af-comparison__col--highlight th,
    .af-comparison__col--highlight    { background: var(--primary-soft) !important; position: relative; }
    .af-comparison__col--highlight th { color: var(--primary); }
    .af-comparison__yes { color: #16a34a; font-weight: 700; font-size: 1.1rem; }
    .af-comparison__no  { color: #ef4444; font-size: 1.1rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: countdown
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-countdown { padding: var(--section-py) 0; }
    .af-countdown__heading {
        text-align: center; font-size: clamp(1.75rem, 3.5vw, 2.5rem);
        font-weight: 800; letter-spacing: -.03em; margin-bottom: .75rem; color: var(--text);
    }
    .af-countdown__sub { text-align: center; font-size: 1.05rem; color: var(--text-muted); margin-bottom: 2.5rem; }
    .af-countdown__display { display: flex; align-items: center; justify-content: center; gap: 1rem; flex-wrap: wrap; }
    .af-countdown__unit {
        text-align: center; min-width: 90px;
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 1.5rem 1.25rem 1.25rem;
        box-shadow: var(--shadow-md);
        position: relative; overflow: hidden;
        transition: transform var(--transition), box-shadow var(--transition);
    }
    .af-countdown__unit::before {
        content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px;
        background: linear-gradient(90deg, var(--primary), var(--accent));
    }
    .af-countdown__unit:hover { transform: translateY(-3px); box-shadow: var(--shadow-lg); }
    [data-theme="dark"] .af-countdown__unit { background: var(--bg-subtle); border-color: var(--border); }
    .af-countdown__value {
        display: block; font-size: clamp(2.5rem, 6vw, 3.75rem); font-weight: 900; line-height: 1;
        letter-spacing: -.04em;
        background: linear-gradient(135deg, var(--primary), var(--accent));
        -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
    }
    .af-countdown__label {
        display: block; font-size: .7rem; font-weight: 700; text-transform: uppercase;
        letter-spacing: .1em; color: var(--text-muted); margin-top: .5rem;
    }
    .af-countdown__sep { font-size: 2.5rem; font-weight: 900; color: var(--border-strong); line-height: 1; align-self: center; margin: 0 -.25rem; }
    .af-countdown__expired { font-size: 1.5rem; font-weight: 700; color: var(--primary); text-align: center; }
    /* Dark variant */
    .af-countdown--dark {
        background: linear-gradient(160deg, #080d1a, #110a2e); border-radius: var(--radius-2xl); padding: 3.5rem 2rem;
    }
    .af-countdown--dark .af-countdown__unit { background: rgba(255,255,255,.05); border-color: rgba(255,255,255,.08); }
    .af-countdown--dark .af-countdown__label { color: rgba(255,255,255,.45); }
    .af-countdown--dark .af-countdown__sep  { color: rgba(255,255,255,.15); }
    .af-countdown--dark .af-countdown__heading,
    .af-countdown--dark .af-countdown__sub { color: #f0f4ff; }
    .af-countdown--dark .af-countdown__sub { color: #8fa3c4; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: progress
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-progress { padding: var(--section-py) 0; }
    .af-progress__heading {
        text-align: center; font-size: clamp(1.75rem, 3.5vw, 2.5rem);
        font-weight: 800; letter-spacing: -.03em; margin-bottom: .75rem; color: var(--text);
    }
    .af-progress__sub { text-align: center; font-size: 1.05rem; color: var(--text-muted); margin-bottom: 2.5rem; }
    .af-progress__list { display: flex; flex-direction: column; gap: 1.5rem; max-width: 680px; margin: 0 auto; }
    .af-progress__item {
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-lg);
        padding: 1.25rem 1.5rem; box-shadow: var(--shadow-xs);
        transition: box-shadow var(--transition);
    }
    .af-progress__item:hover { box-shadow: var(--shadow-md); }
    [data-theme="dark"] .af-progress__item { background: var(--bg-subtle); }
    .af-progress__meta { display: flex; justify-content: space-between; align-items: center; margin-bottom: .75rem; }
    .af-progress__name,
    .af-progress__label { font-size: .9rem; font-weight: 700; color: var(--text); }
    .af-progress__pct {
        font-size: .82rem; font-weight: 800; padding: .18rem .6rem; border-radius: 99px;
        background: var(--primary-soft); color: var(--primary);
    }
    .af-progress__track {
        height: 10px; background: var(--bg-muted); border-radius: 9999px; overflow: hidden;
    }
    [data-theme="dark"] .af-progress__track { background: rgba(255,255,255,.06); }
    .af-progress__bar {
        height: 100%;
        background: linear-gradient(90deg, var(--primary), var(--accent));
        border-radius: 9999px; transition: width .8s cubic-bezier(.4,0,.2,1);
        position: relative; overflow: hidden;
    }
    .af-progress__bar::after {
        content: ''; position: absolute; top: 0; left: -100%; right: -100%; bottom: 0;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,.25), transparent);
        animation: af-shimmer 2s linear infinite;
    }
    .af-progress--rounded .af-progress__track { height: 14px; }
    .af-progress--thin .af-progress__track { height: 5px; }
    .af-progress--thin .af-progress__item { background: transparent; border: none; box-shadow: none; padding: .5rem 0; }
    .af-progress--thin .af-progress__item:hover { box-shadow: none; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: embed
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-embed { padding: var(--section-y) 0; }
    .af-embed__frame { border-radius: var(--radius-xl); overflow: hidden; border: 1px solid var(--border); }
    .af-embed__placeholder { display: flex; align-items: center; justify-content: center; font-size: 1rem; color: var(--text-muted); height: 100%; background: var(--bg-alt); }
    .af-embed__caption { text-align: center; font-size: .82rem; color: var(--text-muted); margin-top: .75rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: breadcrumb
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-breadcrumb { padding: .75rem 0; border-bottom: 1px solid var(--border); font-size: .82rem; }
    .af-breadcrumb__list { display: flex; flex-wrap: wrap; align-items: center; gap: .25rem; list-style: none; padding: 0; margin: 0; }
    .af-breadcrumb__item { display: flex; align-items: center; gap: .25rem; }
    .af-breadcrumb__item a { color: var(--text-muted); text-decoration: none; }
    .af-breadcrumb__item a:hover { color: var(--primary); text-decoration: underline; }
    .af-breadcrumb__item:last-child span { color: var(--text); font-weight: 500; }
    .af-breadcrumb__sep { color: var(--border); font-size: .75rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: social_links
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-social-links { text-align: center; }
    .af-social-links__heading {
        font-size: clamp(1.5rem, 3vw, 2rem); font-weight: 800; letter-spacing: -.03em;
        margin-bottom: .5rem; color: var(--text);
    }
    .af-social-links__sub { font-size: 1rem; color: var(--text-muted); margin-bottom: 1.75rem; }
    .af-social-links__grid { display: flex; flex-wrap: wrap; justify-content: center; gap: .75rem; }
    .af-social-links__item a {
        display: flex; align-items: center; gap: .55rem; padding: .65rem 1.15rem;
        border-radius: var(--radius-lg); border: 1.5px solid var(--border);
        text-decoration: none; color: var(--text); background: var(--bg);
        font-size: .9rem; font-weight: 600;
        box-shadow: var(--shadow-xs);
        transition: all .2s ease;
    }
    .af-social-links__item a:hover {
        background: var(--sl-color, var(--primary)); color: #fff; border-color: transparent;
        transform: translateY(-2px); box-shadow: 0 6px 18px rgba(0,0,0,.15);
        text-decoration: none;
    }
    [data-theme="dark"] .af-social-links__item a { background: var(--bg-subtle); }
    .af-social-links--cards .af-social-links__item a { flex-direction: column; padding: 1.5rem 1.25rem; min-width: 100px; gap: .6rem; }
    .af-social-links--pills .af-social-links__item a { border-radius: 999px; }
    .af-social-links__icon { font-size: 1.25rem; flex-shrink: 0; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: social_feed
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-social-feed__embed { border: 1px solid var(--border); border-radius: var(--radius-lg); overflow: hidden; }
    .af-social-feed__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem; margin-top: 1.5rem; }
    .af-social-feed__post { border: 1px solid var(--border); border-radius: var(--radius-md); overflow: hidden; background: var(--bg-alt); }
    .af-social-feed__post img { width: 100%; aspect-ratio: 1; object-fit: cover; }
    .af-social-feed__post-body { padding: .75rem; font-size: .85rem; color: var(--text); }
    .af-social-feed__follow { margin-top: 1.5rem; text-align: center; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: social_share
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-social-share { text-align: center; }
    .af-social-share__btns { display: flex; flex-wrap: wrap; justify-content: center; gap: .75rem; margin-top: 1.25rem; }
    .af-share-btn { display: inline-flex; align-items: center; gap: .4rem; padding: .5rem 1rem; border-radius: var(--radius-md); font-size: .875rem; font-weight: 600; cursor: pointer; border: none; text-decoration: none; transition: var(--transition); color: #fff; }
    .af-share-btn:hover { opacity: .9; transform: translateY(-1px); }
    .af-share-btn--copy { background: var(--bg-alt); color: var(--text); border: 1px solid var(--border); }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: social_counters
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-social-counters__grid { display: flex; flex-wrap: wrap; justify-content: center; gap: 1.25rem; margin-top: 1.5rem; }
    .af-social-counter {
        display: flex; flex-direction: column; align-items: center; gap: .5rem;
        padding: 1.75rem 1.5rem; min-width: 140px;
        background: var(--bg); border: 1.5px solid var(--border); border-radius: var(--radius-xl);
        box-shadow: var(--shadow-sm);
        transition: all .22s ease; position: relative; overflow: hidden;
    }
    .af-social-counter::before {
        content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px;
        background: var(--sc-color, linear-gradient(90deg, var(--primary), var(--accent)));
    }
    .af-social-counter:hover { box-shadow: var(--shadow-lg); transform: translateY(-3px); border-color: transparent; }
    [data-theme="dark"] .af-social-counter { background: var(--bg-subtle); }
    .af-social-counter__icon { font-size: 2rem; margin-bottom: .25rem; }
    .af-social-counter__count { font-size: 2rem; font-weight: 900; color: var(--sc-color, var(--primary)); letter-spacing: -.03em; line-height: 1; }
    .af-social-counter__label { font-size: .76rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: .07em; font-weight: 600; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: social_proof_bar
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-social-proof-bar {
        padding: 1.375rem 0;
        background: linear-gradient(135deg, var(--bg-subtle) 0%, var(--bg) 100%);
        border-top: 1px solid var(--border); border-bottom: 1px solid var(--border);
    }
    [data-theme="dark"] .af-social-proof-bar { background: var(--bg-subtle); }
    .af-spb__inner { display: flex; flex-wrap: wrap; align-items: center; justify-content: center; gap: 1.25rem 2.5rem; }
    .af-spb__item {
        display: flex; align-items: center; gap: .5rem;
        font-size: .875rem; font-weight: 500; color: var(--text-2);
    }
    .af-spb__item strong { color: var(--primary); font-weight: 800; font-size: 1rem; }
    .af-spb__item-icon { font-size: 1rem; }
    .af-spb__sep { color: var(--border-strong); font-size: .75rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: review_widget
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-review-widget { text-align: center; }
    .af-review-widget__summary {
        display: inline-flex; flex-direction: column; align-items: center;
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 2rem 3rem; box-shadow: var(--shadow-lg); margin-bottom: 1.5rem;
    }
    [data-theme="dark"] .af-review-widget__summary { background: var(--bg-subtle); }
    .af-review-widget__score { font-size: 4rem; font-weight: 900; color: var(--text); letter-spacing: -.05em; line-height: 1; }
    .af-review-widget__stars { font-size: 1.4rem; color: #f59e0b; letter-spacing: .1rem; margin: .5rem 0; }
    .af-review-widget__count { font-size: .875rem; color: var(--text-muted); font-weight: 500; }
    .af-review-widget__platform {
        display: inline-flex; align-items: center; gap: .35rem; margin-top: .75rem;
        font-size: .76rem; font-weight: 600; color: var(--text-muted);
        background: var(--bg-subtle); padding: .3rem .75rem; border-radius: 99px; border: 1px solid var(--border);
    }
    .af-review-widget__embed { border: 1px solid var(--border); border-radius: var(--radius-xl); overflow: hidden; box-shadow: var(--shadow-sm); }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: ai_chatbox
    ═══════════════════════════════════════════════════════════════════════════ */
    @keyframes af-typing { 0%,60%,100% { transform: translateY(0); } 30% { transform: translateY(-5px); } }
    .af-ai-chatbox { max-width: 680px; margin: 0 auto; }
    .af-aicb__window {
        border: 1px solid var(--border); border-radius: var(--radius-xl); background: var(--bg);
        overflow: hidden; box-shadow: var(--shadow-lg);
    }
    [data-theme="dark"] .af-aicb__window { background: var(--bg-subtle); border-color: var(--border); }
    .af-aicb__header {
        padding: 1rem 1.25rem;
        background: linear-gradient(135deg, var(--primary), var(--accent));
        color: #fff; font-weight: 700; display: flex; align-items: center; gap: .625rem; font-size: .95rem;
    }
    .af-aicb__header-dot { width: 8px; height: 8px; background: rgba(255,255,255,.6); border-radius: 50%; animation: af-typing 1.4s ease-in-out infinite; }
    .af-aicb__header-dot:nth-child(2) { animation-delay: .15s; }
    .af-aicb__header-dot:nth-child(3) { animation-delay: .3s; }
    .af-aicb__messages { min-height: 240px; max-height: 380px; overflow-y: auto; padding: 1.25rem; display: flex; flex-direction: column; gap: .875rem; }
    .af-aicb__msg {
        padding: .7rem 1rem; border-radius: var(--radius-lg); font-size: .9rem; line-height: 1.55; max-width: 82%;
    }
    .af-aicb__msg--bot {
        background: var(--bg-subtle); color: var(--text); align-self: flex-start;
        border-bottom-left-radius: .375rem; border: 1px solid var(--border);
    }
    .af-aicb__msg--user {
        background: linear-gradient(135deg, var(--primary), var(--accent)); color: #fff;
        align-self: flex-end; border-bottom-right-radius: .375rem;
        box-shadow: 0 2px 10px rgba(99,102,241,.3);
    }
    .af-aicb__msg--typing { background: var(--bg-subtle); color: var(--text-muted); font-style: italic; display: flex; align-items: center; gap: .4rem; }
    .af-aicb__suggestions { display: flex; flex-wrap: wrap; gap: .5rem; padding: .875rem 1.25rem 0; }
    .af-aicb__suggestion {
        padding: .38rem .875rem; border-radius: 999px;
        border: 1.5px solid rgba(99,102,241,.3); color: var(--primary);
        font-size: .8rem; font-weight: 600; cursor: pointer; background: var(--primary-soft);
        transition: all .18s ease;
    }
    .af-aicb__suggestion:hover { background: var(--primary); color: #fff; border-color: transparent; transform: translateY(-1px); }
    .af-aicb__input-row { display: flex; padding: .875rem 1.25rem; gap: .625rem; border-top: 1px solid var(--border); background: var(--bg-subtle); }
    .af-aicb__input {
        flex: 1; border: 1.5px solid var(--border); border-radius: var(--radius-lg);
        padding: .55rem .875rem; font-size: .9rem; outline: none;
        background: var(--bg); color: var(--text); font-family: var(--font);
        transition: border-color .18s, box-shadow .18s;
    }
    .af-aicb__input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px var(--primary-soft); }
    .af-aicb__send {
        padding: .55rem 1.1rem;
        background: linear-gradient(135deg, var(--primary), var(--accent));
        color: #fff; border: none; border-radius: var(--radius-lg); cursor: pointer;
        font-weight: 700; font-family: var(--font); font-size: .85rem;
        transition: box-shadow .18s, transform .15s;
        box-shadow: 0 2px 10px rgba(99,102,241,.3);
    }
    .af-aicb__send:hover { box-shadow: 0 4px 16px rgba(99,102,241,.5); transform: translateY(-1px); }
    .af-aicb__send:disabled { opacity: .5; cursor: default; transform: none; box-shadow: none; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: ai_recommendations
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-ai-recommendations__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 1.5rem; margin-top: 1.5rem; }
    .af-ai-rec__card { border: 1px solid var(--border); border-radius: var(--radius-lg); overflow: hidden; background: var(--bg-alt); }
    .af-ai-rec__img { width: 100%; aspect-ratio: 16/9; object-fit: cover; }
    .af-ai-rec__body { padding: 1rem; }
    .af-ai-rec__label { font-size: .75rem; font-weight: 600; color: var(--primary); text-transform: uppercase; letter-spacing: .05em; }
    .af-ai-rec__title { font-size: 1rem; font-weight: 600; color: var(--text); margin: .25rem 0 .5rem; }
    .af-ai-rec__desc { font-size: .875rem; color: var(--text-muted); }
    .af-ai-rec__badge { display: inline-block; margin-top: .75rem; padding: .25rem .6rem; background: var(--primary-soft); color: var(--primary); font-size: .75rem; border-radius: 999px; font-weight: 600; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: ai_summary
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-ai-summary {
        max-width: 760px; margin: 0 auto;
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 2rem 2.25rem; box-shadow: var(--shadow-md);
        position: relative; overflow: hidden;
    }
    .af-ai-summary::before {
        content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px;
        background: linear-gradient(90deg, var(--primary), var(--accent), var(--primary));
        background-size: 200%; animation: af-shimmer 3s linear infinite;
    }
    @keyframes af-shimmer { to { background-position: 200% center; } }
    [data-theme="dark"] .af-ai-summary { background: var(--bg-subtle); }
    .af-ai-summary__badge {
        display: inline-flex; align-items: center; gap: .4rem; padding: .35rem .875rem;
        background: linear-gradient(135deg, var(--primary-soft), rgba(139,92,246,.08));
        color: var(--primary); border-radius: 999px; font-size: .78rem; font-weight: 700;
        margin-bottom: 1.25rem; border: 1px solid rgba(99,102,241,.15);
        letter-spacing: .03em;
    }
    .af-ai-summary__text { font-size: 1.05rem; line-height: 1.78; color: var(--text-2); }
    .af-ai-summary__bullets { margin-top: 1.25rem; padding: 0; list-style: none; display: flex; flex-direction: column; gap: .6rem; }
    .af-ai-summary__bullets li {
        display: flex; align-items: flex-start; gap: .625rem;
        font-size: .9375rem; color: var(--text-2); line-height: 1.6;
    }
    .af-ai-summary__bullets li::before {
        content: ''; width: 6px; height: 6px; border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), var(--accent));
        flex-shrink: 0; margin-top: .5rem;
    }
    .af-ai-summary__by { margin-top: 1.25rem; font-size: .78rem; color: var(--text-muted); display: flex; align-items: center; gap: .35rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: ai_faq
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-ai-faq__badge { display: inline-flex; align-items: center; gap: .35rem; padding: .3rem .75rem; background: var(--primary-soft); color: var(--primary); border-radius: 999px; font-size: .8rem; font-weight: 600; margin-bottom: 1.25rem; }
    .af-ai-faq__item { border: 1px solid var(--border); border-radius: var(--radius-md); margin-bottom: .75rem; overflow: hidden; }
    .af-ai-faq__q { display: flex; justify-content: space-between; align-items: center; padding: 1rem 1.25rem; cursor: pointer; font-weight: 600; font-size: .95rem; color: var(--text); background: var(--bg-alt); user-select: none; }
    .af-ai-faq__chevron { transition: transform .25s; font-style: normal; }
    .af-ai-faq__a { display: none; padding: 1rem 1.25rem; font-size: .9rem; color: var(--text); line-height: 1.65; border-top: 1px solid var(--border); background: var(--bg); }
    .af-ai-faq__item.af-open .af-ai-faq__a { display: block; }
    .af-ai-faq__item.af-open .af-ai-faq__chevron { transform: rotate(180deg); }
    .af-ai-faq__conf { font-size: .75rem; font-weight: 600; padding: .15rem .5rem; border-radius: 999px; margin-left: .5rem; }
    .af-ai-faq__conf--high { background: #d1fae5; color: #059669; }
    .af-ai-faq__conf--medium { background: #fef3c7; color: #d97706; }
    .af-ai-faq__conf--low { background: #fee2e2; color: #dc2626; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: ai_search
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-ai-search { max-width: 680px; margin: 0 auto; }
    .af-ai-search__form { display: flex; gap: .5rem; }
    .af-ai-search__input { flex: 1; padding: .75rem 1rem; border: 1px solid var(--border); border-radius: var(--radius-md); font-size: 1rem; background: var(--bg); color: var(--text); outline: none; }
    .af-ai-search__input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px var(--primary-soft); }
    .af-ai-search__btn { padding: .75rem 1.25rem; background: var(--primary); color: #fff; border: none; border-radius: var(--radius-md); cursor: pointer; font-weight: 600; transition: var(--transition); }
    .af-ai-search__results { margin-top: 1.25rem; }
    .af-ai-search__result { padding: .875rem 1rem; border: 1px solid var(--border); border-radius: var(--radius-md); margin-bottom: .5rem; background: var(--bg-alt); }
    .af-ai-search__result a { text-decoration: none; color: var(--primary); font-weight: 600; }
    .af-ai-search__result-desc { font-size: .875rem; color: var(--text-muted); margin-top: .25rem; }
    .af-ai-search__empty { text-align: center; color: var(--text-muted); padding: 2rem 0; }
    .af-ai-search__spinner { display: none; text-align: center; padding: 1.5rem 0; color: var(--text-muted); font-size: .875rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: ai_personalized
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-ai-personalized__badge { display: inline-flex; align-items: center; gap: .35rem; padding: .3rem .75rem; background: var(--primary-soft); color: var(--primary); border-radius: 999px; font-size: .8rem; font-weight: 600; margin-bottom: 1rem; }
    .af-ai-personalized__segment { display: inline-block; padding: .2rem .6rem; background: var(--bg-alt); border: 1px solid var(--border); border-radius: 999px; font-size: .75rem; color: var(--text-muted); margin-left: .5rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: form_builder
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-form-builder__wrap {
        max-width: 660px; margin: 0 auto;
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 2.5rem 2.25rem; box-shadow: var(--shadow-md);
    }
    [data-theme="dark"] .af-form-builder__wrap { background: var(--bg-subtle); }
    .af-form-builder__heading { font-size: 1.5rem; font-weight: 800; color: var(--text); margin-bottom: .375rem; letter-spacing: -.025em; }
    .af-form-builder__sub { font-size: .9rem; color: var(--text-muted); margin-bottom: 2rem; }
    .af-form-builder__form { display: flex; flex-direction: column; gap: 1.375rem; }
    .af-form-field { display: flex; flex-direction: column; gap: .45rem; }
    .af-form-field label { font-weight: 600; font-size: .84rem; color: var(--text-2); letter-spacing: .01em; }
    .af-form-field__req { color: var(--primary); margin-left: .15rem; }
    .af-form-field input,
    .af-form-field textarea,
    .af-form-field select {
        padding: .72rem 1rem; border: 1.5px solid var(--border); border-radius: var(--radius);
        font-size: .9375rem; background: var(--bg); color: var(--text); outline: none;
        font-family: var(--font); transition: border-color .18s, box-shadow .18s;
        width: 100%;
    }
    [data-theme="dark"] .af-form-field input,
    [data-theme="dark"] .af-form-field textarea,
    [data-theme="dark"] .af-form-field select { background: var(--bg-muted); border-color: var(--border); }
    .af-form-field input:focus,
    .af-form-field textarea:focus,
    .af-form-field select:focus {
        border-color: var(--primary); box-shadow: 0 0 0 3px var(--primary-soft);
    }
    .af-form-field textarea { resize: vertical; min-height: 110px; }
    .af-form-field__check { display: flex; align-items: center; gap: .5rem; font-size: .9rem; cursor: pointer; accent-color: var(--primary); }
    .af-form-builder__feedback {
        font-size: .875rem; margin-top: .5rem; padding: .65rem 1rem;
        border-radius: var(--radius); display: flex; align-items: center; gap: .5rem;
    }
    .af-form-builder__feedback--ok { background: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
    .af-form-builder__feedback--err { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
    [data-theme="dark"] .af-form-builder__feedback--ok { background: rgba(16,185,129,.12); color: #34d399; border-color: rgba(16,185,129,.25); }
    [data-theme="dark"] .af-form-builder__feedback--err { background: rgba(239,68,68,.12); color: #f87171; border-color: rgba(239,68,68,.25); }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: popup
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-popup-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.55); z-index: 9000; align-items: center; justify-content: center; }
    .af-popup-overlay.af-open { display: flex; }
    .af-popup { background: var(--bg); border-radius: var(--radius-xl); padding: 2.5rem; max-width: 520px; width: 90%; position: relative; box-shadow: var(--shadow-xl); animation: afPopIn .25s ease; }
    @keyframes afPopIn { from { opacity:0; transform:scale(.94); } to { opacity:1; transform:scale(1); } }
    .af-popup__close { position: absolute; top: .75rem; right: .875rem; background: none; border: none; font-size: 1.25rem; cursor: pointer; color: var(--text-muted); line-height: 1; }
    .af-popup__image { width: 100%; border-radius: var(--radius-md); margin-bottom: 1.25rem; }
    .af-popup__title { font-size: 1.375rem; font-weight: 700; color: var(--text); margin-bottom: .5rem; }
    .af-popup__text { font-size: .9375rem; color: var(--text-muted); line-height: 1.6; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: sticky_cta
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-sticky-cta { position: fixed; bottom: 0; left: 0; right: 0; z-index: 8000; background: var(--primary); color: #fff; padding: .875rem 1.5rem; display: flex; align-items: center; justify-content: center; gap: 1rem; flex-wrap: wrap; transform: translateY(100%); transition: transform .35s ease; box-shadow: 0 -4px 24px rgba(0,0,0,.18); }
    .af-sticky-cta.af-visible { transform: translateY(0); }
    .af-sticky-cta--top { top: 0; bottom: auto; transform: translateY(-100%); }
    .af-sticky-cta--top.af-visible { transform: translateY(0); }
    .af-sticky-cta__text { font-weight: 600; font-size: .9375rem; }
    .af-sticky-cta__btn { padding: .45rem 1.25rem; border-radius: 999px; background: #fff; color: var(--primary); font-weight: 700; font-size: .875rem; text-decoration: none; white-space: nowrap; }
    .af-sticky-cta__dismiss { background: none; border: none; color: rgba(255,255,255,.7); cursor: pointer; font-size: 1rem; padding: 0 .25rem; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: file_download
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-file-download { max-width: 720px; margin: 0 auto; }
    .af-fdl__card {
        display: flex; align-items: center; gap: 1.5rem; padding: 1.75rem;
        border: 1px solid var(--border); border-radius: var(--radius-xl);
        background: var(--bg); box-shadow: var(--shadow-md);
        transition: all .2s ease; position: relative; overflow: hidden;
    }
    .af-fdl__card::before {
        content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
        background: linear-gradient(to bottom, var(--primary), var(--accent));
    }
    .af-fdl__card:hover { box-shadow: var(--shadow-xl); transform: translateY(-2px); border-color: rgba(99,102,241,.25); }
    [data-theme="dark"] .af-fdl__card { background: var(--bg-subtle); }
    .af-fdl__icon-wrap {
        width: 60px; height: 60px; flex-shrink: 0; border-radius: var(--radius-lg);
        background: var(--primary-soft); display: flex; align-items: center; justify-content: center;
        font-size: 2rem; border: 1px solid rgba(99,102,241,.15);
    }
    .af-fdl__body { flex: 1; min-width: 0; }
    .af-fdl__title { font-size: 1.125rem; font-weight: 700; color: var(--text); margin-bottom: .2rem; }
    .af-fdl__meta { font-size: .8rem; color: var(--text-muted); margin-top: .2rem; }
    .af-fdl__desc { font-size: .875rem; color: var(--text-2); margin-top: .5rem; line-height: 1.6; }
    @media (max-width: 520px) { .af-fdl__card { flex-direction: column; align-items: flex-start; } }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: before_after
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-before-after { }
    .af-ba__slider { position: relative; overflow: hidden; border-radius: var(--radius-lg); border: 1px solid var(--border); user-select: none; max-height: 560px; }
    .af-ba__after, .af-ba__before { position: absolute; inset: 0; overflow: hidden; }
    .af-ba__after { inset: 0; }
    .af-ba__before { right: auto; width: 50%; }
    .af-ba__after img, .af-ba__before img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .af-ba__slider > .af-ba__after img { min-height: 300px; }
    .af-ba__label { position: absolute; bottom: .75rem; padding: .2rem .6rem; background: rgba(0,0,0,.55); color: #fff; border-radius: 999px; font-size: .75rem; font-weight: 600; }
    .af-ba__label--before { left: .75rem; }
    .af-ba__label--after { right: .75rem; }
    .af-ba__handle { position: absolute; top: 0; bottom: 0; left: 50%; width: 3px; background: #fff; cursor: ew-resize; display: flex; align-items: center; transform: translateX(-50%); }
    .af-ba__handle-icon { position: absolute; width: 36px; height: 36px; background: #fff; border-radius: 50%; box-shadow: 0 2px 10px rgba(0,0,0,.25); display: flex; align-items: center; justify-content: center; font-size: 1rem; transform: translateX(-50%); margin-left: 1.5px; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: data_table
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-dt__wrap { overflow-x: auto; margin-top: 1.5rem; border: 1px solid var(--border); border-radius: var(--radius-lg); }
    .af-dt__table { width: 100%; border-collapse: collapse; font-size: .9rem; }
    .af-dt__table th { padding: .75rem 1rem; background: var(--bg-alt); text-align: left; font-weight: 600; font-size: .8rem; text-transform: uppercase; letter-spacing: .04em; color: var(--text-muted); border-bottom: 1px solid var(--border); white-space: nowrap; }
    .af-dt__table td { padding: .75rem 1rem; border-bottom: 1px solid var(--border); color: var(--text); }
    .af-dt__table tbody tr:last-child td { border-bottom: none; }
    .af-dt__table--striped tbody tr:nth-child(even) td { background: var(--bg-alt); }
    .af-dt__table tbody tr:hover td { background: var(--primary-soft); }
    .af-dt__sort-icon { margin-left: .25rem; opacity: .5; }
    .af-dt__sortable:hover .af-dt__sort-icon { opacity: 1; color: var(--primary); }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: events_list
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-events { display: flex; flex-direction: column; gap: 1rem; margin-top: 1.5rem; }
    .af-events--cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); }
    .af-event { display: flex; gap: 1.25rem; padding: 1.25rem; border: 1px solid var(--border); border-radius: var(--radius-lg); background: var(--bg-alt); }
    .af-event--past { opacity: .55; }
    .af-event__date { display: flex; flex-direction: column; align-items: center; justify-content: center; min-width: 52px; height: 52px; background: var(--primary); color: #fff; border-radius: var(--radius-md); flex-shrink: 0; }
    .af-event__month { font-size: .65rem; font-weight: 700; text-transform: uppercase; line-height: 1; }
    .af-event__day { font-size: 1.375rem; font-weight: 800; line-height: 1; }
    .af-event__body { flex: 1; }
    .af-event__tag { display: inline-block; padding: .15rem .5rem; background: var(--primary-soft); color: var(--primary); font-size: .72rem; font-weight: 600; border-radius: 999px; margin-bottom: .35rem; }
    .af-event__title { font-size: 1rem; font-weight: 700; color: var(--text); margin: 0 0 .35rem; }
    .af-event__meta { font-size: .8rem; color: var(--text-muted); display: flex; gap: .75rem; flex-wrap: wrap; margin-bottom: .35rem; }
    .af-event__desc { font-size: .875rem; color: var(--text); margin-bottom: .5rem; }
    .af-events__empty { text-align: center; color: var(--text-muted); padding: 2rem 0; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: anchor_nav
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-anchor-nav { background: var(--bg-alt); border-bottom: 1px solid var(--border); }
    .af-anchor-nav--sticky { position: sticky; top: 0; z-index: 500; }
    .af-anchor-nav__list { display: flex; flex-wrap: wrap; gap: .25rem; list-style: none; padding: .5rem 0; margin: 0; }
    .af-anchor-nav__link { display: block; padding: .45rem .875rem; border-radius: var(--radius-md); font-size: .875rem; font-weight: 500; color: var(--text-muted); text-decoration: none; transition: var(--transition); }
    .af-anchor-nav__link:hover { color: var(--primary); background: var(--primary-soft); }
    .af-anchor-nav__link--active { color: var(--primary) !important; background: var(--primary-soft) !important; font-weight: 600; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: cookie_banner
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-cookie-banner { position: fixed; bottom: 1.25rem; left: 50%; transform: translateX(-50%); z-index: 8500; background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-lg); box-shadow: var(--shadow-xl); padding: 1.25rem 1.5rem; max-width: 520px; width: 92%; display: none; }
    .af-cookie-banner.af-show { display: block; animation: afSlideUp .3s ease; }
    @keyframes afSlideUp { from { opacity:0; transform: translateX(-50%) translateY(12px); } to { opacity:1; transform: translateX(-50%) translateY(0); } }
    .af-cookie-banner__title { font-weight: 700; font-size: .95rem; color: var(--text); margin-bottom: .35rem; }
    .af-cookie-banner__text { font-size: .85rem; color: var(--text-muted); line-height: 1.55; }
    .af-cookie-banner__btns { display: flex; gap: .75rem; margin-top: 1rem; flex-wrap: wrap; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: product_card
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-product-card__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 1.5rem; margin-top: 1.75rem; }
    .af-product {
        border: 1px solid var(--border); border-radius: var(--radius-xl); overflow: hidden;
        background: var(--bg); box-shadow: var(--shadow-sm);
        transition: box-shadow .25s ease, transform .22s ease, border-color .2s ease;
        display: flex; flex-direction: column;
    }
    .af-product:hover { box-shadow: var(--shadow-xl); transform: translateY(-4px); border-color: rgba(99,102,241,.2); }
    [data-theme="dark"] .af-product { background: var(--bg-subtle); }
    .af-product__img-wrap { position: relative; overflow: hidden; }
    .af-product__img { width: 100%; aspect-ratio: 4/3; object-fit: cover; display: block; transition: transform .4s ease; }
    .af-product:hover .af-product__img { transform: scale(1.05); }
    .af-product__badge {
        position: absolute; top: .875rem; left: .875rem;
        padding: .28rem .75rem;
        background: linear-gradient(135deg, var(--primary), var(--accent));
        color: #fff; border-radius: 999px; font-size: .72rem; font-weight: 800;
        box-shadow: 0 2px 8px rgba(99,102,241,.35);
    }
    .af-product__body { padding: 1.25rem 1.25rem .875rem; flex: 1; }
    .af-product__category { font-size: .72rem; font-weight: 700; letter-spacing: .07em; text-transform: uppercase; color: var(--primary); margin-bottom: .4rem; }
    .af-product__name { font-size: 1.05rem; font-weight: 700; color: var(--text); margin-bottom: .4rem; line-height: 1.35; }
    .af-product__desc { font-size: .84rem; color: var(--text-muted); margin-bottom: 1rem; line-height: 1.6; }
    .af-product__pricing { display: flex; align-items: baseline; gap: .5rem; }
    .af-product__price { font-size: 1.375rem; font-weight: 900; color: var(--primary); letter-spacing: -.03em; }
    .af-product__orig { font-size: .875rem; color: var(--text-muted); text-decoration: line-through; }
    .af-product__footer { padding: 1rem 1.25rem; border-top: 1px solid var(--border); background: var(--bg-subtle); margin-top: auto; }
    [data-theme="dark"] .af-product__footer { background: rgba(255,255,255,.03); }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: job_listing
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-job-listing__filters { display: flex; flex-wrap: wrap; gap: .5rem; margin-bottom: 1.75rem; }
    .af-job-filter-btn {
        padding: .42rem .9rem; border-radius: 999px;
        border: 1.5px solid var(--border); background: var(--bg); color: var(--text-2);
        font-size: .84rem; font-weight: 600; cursor: pointer;
        transition: all .18s ease;
    }
    .af-job-filter-btn.af-active, .af-job-filter-btn:hover {
        background: linear-gradient(135deg, var(--primary), var(--accent));
        color: #fff; border-color: transparent;
        box-shadow: 0 3px 10px rgba(99,102,241,.3);
    }
    .af-jobs { display: flex; flex-direction: column; gap: .875rem; }
    .af-job {
        display: flex; align-items: center; gap: 1.375rem; padding: 1.375rem 1.5rem;
        border: 1px solid var(--border); border-radius: var(--radius-xl);
        background: var(--bg); box-shadow: var(--shadow-xs);
        transition: all .2s ease;
    }
    .af-job:hover { border-color: var(--primary); box-shadow: var(--shadow-md); transform: translateX(3px); }
    [data-theme="dark"] .af-job { background: var(--bg-subtle); }
    .af-job__logo {
        width: 46px; height: 46px; border-radius: var(--radius-lg);
        border: 1px solid var(--border); overflow: hidden; flex-shrink: 0;
        display: flex; align-items: center; justify-content: center;
        background: var(--primary-soft); color: var(--primary); font-weight: 800; font-size: 1.1rem;
    }
    .af-job__body { flex: 1; min-width: 0; }
    .af-job__title { font-size: 1.0625rem; font-weight: 700; color: var(--text); margin-bottom: .35rem; }
    .af-job__meta { display: flex; gap: .625rem; flex-wrap: wrap; font-size: .8rem; color: var(--text-muted); }
    .af-job__meta-item { display: inline-flex; align-items: center; gap: .25rem; }
    .af-job__type, .af-job__dept, .af-job__loc { display: inline-flex; align-items: center; gap: .25rem; }
    .af-job__badge {
        padding: .28rem .75rem;
        background: var(--primary-soft); color: var(--primary);
        border-radius: 999px; font-size: .74rem; font-weight: 700;
        white-space: nowrap; border: 1px solid rgba(99,102,241,.15);
    }
    .af-job__apply { flex-shrink: 0; }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: rating_widget
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-rating-widget {
        max-width: 500px; margin: 0 auto; text-align: center;
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 2.5rem 2rem; box-shadow: var(--shadow-md);
    }
    [data-theme="dark"] .af-rating-widget { background: var(--bg-subtle); }
    .af-rw__question { font-size: 1.25rem; font-weight: 700; color: var(--text); margin-bottom: 1.5rem; letter-spacing: -.02em; }
    .af-rw__stars { display: flex; justify-content: center; gap: .375rem; margin-bottom: .5rem; }
    .af-rw__star {
        font-size: 2.5rem; cursor: pointer; color: var(--border-strong);
        transition: color .12s ease, transform .12s ease;
        line-height: 1;
    }
    .af-rw__star:hover { transform: scale(1.2); }
    .af-rw__star.af-hovered, .af-rw__star.af-selected { color: #f59e0b; }
    .af-rw__result { margin-top: 1.5rem; }
    .af-rw__avg { font-size: 2.5rem; font-weight: 900; color: var(--text); letter-spacing: -.04em; }
    .af-rw__avg-label { font-size: .875rem; color: var(--text-muted); margin-top: .25rem; }
    .af-rw__voted-msg {
        margin-top: 1rem; color: var(--primary); font-size: .9rem; font-weight: 600;
        display: inline-flex; align-items: center; gap: .4rem;
        background: var(--primary-soft); padding: .4rem 1rem; border-radius: 999px;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: survey
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-survey {
        max-width: 580px; margin: 0 auto;
        background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-xl);
        padding: 2.25rem; box-shadow: var(--shadow-md);
    }
    [data-theme="dark"] .af-survey { background: var(--bg-subtle); }
    .af-survey__question { font-size: 1.2rem; font-weight: 700; color: var(--text); margin-bottom: 1.5rem; letter-spacing: -.02em; line-height: 1.45; }
    .af-survey__options { display: flex; flex-direction: column; gap: .75rem; }
    .af-survey__option {
        display: flex; align-items: center; gap: .875rem; padding: .875rem 1.125rem;
        border: 1.5px solid var(--border); border-radius: var(--radius-lg);
        cursor: pointer; background: var(--bg-subtle);
        transition: all .18s ease; position: relative; overflow: hidden;
    }
    .af-survey__option:hover { border-color: var(--primary); background: var(--primary-soft); transform: translateX(2px); }
    .af-survey__option.af-voted { cursor: default; transform: none; }
    .af-survey__option-letter {
        width: 30px; height: 30px; border-radius: 50%; flex-shrink: 0;
        background: var(--border); display: flex; align-items: center; justify-content: center;
        font-size: .8rem; font-weight: 800; color: var(--text-muted);
        transition: background .18s, color .18s;
    }
    .af-survey__option:hover .af-survey__option-letter { background: var(--primary); color: #fff; }
    .af-survey__option.af-winning .af-survey__option-letter {
        background: linear-gradient(135deg, var(--primary), var(--accent)); color: #fff;
    }
    .af-survey__option-text { flex: 1; font-size: .9375rem; font-weight: 500; color: var(--text); }
    .af-survey__bar-wrap { flex: 1; height: 7px; background: var(--border); border-radius: 999px; overflow: hidden; }
    .af-survey__bar { height: 100%; background: linear-gradient(90deg, var(--primary), var(--accent)); border-radius: 999px; transition: width .6s ease; }
    .af-survey__pct { font-size: .82rem; font-weight: 800; color: var(--primary); min-width: 40px; text-align: right; }
    .af-survey__total { font-size: .8rem; color: var(--text-muted); margin-top: 1.25rem; text-align: right; padding-top: .875rem; border-top: 1px solid var(--border); }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: media_kit
    ═══════════════════════════════════════════════════════════════════════════ */
    .af-media-kit { }
    .af-mk__section { margin-bottom: 2.5rem; }
    .af-mk__section-title { font-size: .8rem; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; color: var(--text-muted); margin-bottom: 1rem; }
    .af-mk__logos { display: flex; flex-wrap: wrap; gap: 1rem; align-items: center; }
    .af-mk__logo-card { padding: 1.5rem 2rem; border: 1px solid var(--border); border-radius: var(--radius-lg); background: var(--bg-alt); display: flex; flex-direction: column; align-items: center; gap: .5rem; }
    .af-mk__logo-card img { max-height: 48px; max-width: 160px; object-fit: contain; }
    .af-mk__logo-label { font-size: .75rem; color: var(--text-muted); }
    .af-mk__colors { display: flex; flex-wrap: wrap; gap: .75rem; }
    .af-mk__color { display: flex; flex-direction: column; align-items: center; gap: .5rem; }
    .af-mk__color-swatch { width: 64px; height: 64px; border-radius: var(--radius-md); border: 1px solid var(--border); }
    .af-mk__color-hex { font-size: .75rem; color: var(--text-muted); font-family: monospace; }
    .af-mk__color-name { font-size: .8rem; font-weight: 500; color: var(--text); }
    .af-mk__files { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1rem; }
    .af-mk__file { display: flex; align-items: center; gap: .875rem; padding: 1rem; border: 1px solid var(--border); border-radius: var(--radius-md); background: var(--bg-alt); text-decoration: none; color: var(--text); transition: var(--transition); }
    .af-mk__file:hover { border-color: var(--primary); background: var(--primary-soft); }
    .af-mk__file-icon { font-size: 1.75rem; flex-shrink: 0; }
    .af-mk__file-name { font-size: .875rem; font-weight: 600; color: var(--text); }
    .af-mk__file-size { font-size: .75rem; color: var(--text-muted); }

    /* ═══════════════════════════════════════════════════════════════════════════
       BLOCK: mcp_block
    ═══════════════════════════════════════════════════════════════════════════ */
    @keyframes mcp-spin { to { transform: rotate(360deg); } }
    .af-mcp-block { padding: var(--section-py) 0; }
    .af-mcp-block__label {
        display: inline-flex; align-items: center; gap: .4rem; margin-bottom: 1rem;
        font-size: .72rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase;
        color: var(--primary); background: var(--primary-soft); padding: .25rem .75rem;
        border-radius: 99px; border: 1px solid rgba(99,102,241,.15);
    }
    .af-mcp-block__heading { font-size: clamp(1.5rem, 3vw, 2rem); font-weight: 800; letter-spacing: -.03em; margin-bottom: 1.5rem; color: var(--text); }
    .af-mcp-block__loading {
        display: flex; align-items: center; gap: 1rem;
        padding: 2.5rem 2rem; color: var(--text-muted); font-size: .9rem;
        border: 1.5px dashed var(--border); border-radius: var(--radius-xl);
        background: var(--bg-subtle);
    }
    .af-mcp-spinner {
        width: 22px; height: 22px; flex-shrink: 0;
        border: 2.5px solid var(--border); border-top-color: var(--primary);
        border-radius: 50%; animation: mcp-spin .7s linear infinite;
    }
    .af-mcp-block__error {
        padding: 1.25rem 1.5rem; border: 1px solid rgba(239,68,68,.25);
        background: rgba(239,68,68,.06); border-radius: var(--radius-lg);
        color: #ef4444; font-size: .875rem; display: flex; align-items: center; gap: .625rem;
    }
    .af-mcp-block__empty {
        display: flex; flex-direction: column; align-items: center; justify-content: center;
        gap: .75rem; padding: 3.5rem 2rem; border: 2px dashed var(--border);
        border-radius: var(--radius-xl); color: var(--text-muted); font-size: .9rem; text-align: center;
    }
    .af-mcp-block__empty-icon { font-size: 2.5rem; }
    .af-mcp-text { line-height: 1.75; color: var(--text-2); }
    .af-mcp-text code {
        background: var(--bg-muted); padding: .15em .4em; border-radius: 4px;
        font-size: .85em; font-family: 'JetBrains Mono', 'Fira Code', monospace;
    }
    .af-mcp-list { padding: 0; list-style: none; display: flex; flex-direction: column; gap: .6rem; color: var(--text-2); }
    .af-mcp-list li { display: flex; align-items: flex-start; gap: .625rem; line-height: 1.65; }
    .af-mcp-list li::before { content: ''; width: 6px; height: 6px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--accent)); flex-shrink: 0; margin-top: .55rem; }
    .af-mcp-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1.25rem; }
    .af-mcp-card {
        padding: 1.5rem; border: 1px solid var(--border); border-radius: var(--radius-xl);
        background: var(--bg); display: flex; flex-direction: column; gap: .625rem;
        box-shadow: var(--shadow-sm);
        transition: box-shadow .2s, transform .18s, border-color .18s;
    }
    .af-mcp-card:hover { box-shadow: var(--shadow-lg); transform: translateY(-2px); border-color: rgba(99,102,241,.25); }
    [data-theme="dark"] .af-mcp-card { background: var(--bg-subtle); }
    .af-mcp-card__title { font-weight: 700; font-size: 1.0625rem; color: var(--text); }
    .af-mcp-card__text  { font-size: .875rem; color: var(--text-muted); line-height: 1.6; flex: 1; }
    .af-mcp-card__link  { margin-top: auto; font-size: .84rem; font-weight: 600; color: var(--primary); text-decoration: none; display: inline-flex; align-items: center; gap: .25rem; }
    .af-mcp-card__link:hover { text-decoration: underline; }
    .af-mcp-table-wrap { overflow-x: auto; border-radius: var(--radius-lg); border: 1px solid var(--border); box-shadow: var(--shadow-sm); }
    .af-mcp-table { width: 100%; border-collapse: collapse; font-size: .875rem; }
    .af-mcp-table th { padding: .75rem 1rem; background: var(--bg-muted); font-weight: 700; font-size: .8rem; text-align: left; border-bottom: 1px solid var(--border); color: var(--text-2); text-transform: uppercase; letter-spacing: .04em; }
    .af-mcp-table td { padding: .7rem 1rem; border-bottom: 1px solid var(--border); color: var(--text-2); }
    .af-mcp-table tbody tr:last-child td { border-bottom: none; }
    .af-mcp-table tbody tr:hover td { background: var(--primary-soft); }
    .af-mcp-raw {
        background: #0d1117; border: 1px solid rgba(255,255,255,.08);
        border-radius: var(--radius-xl); padding: 1.5rem; overflow-x: auto;
        box-shadow: var(--shadow-lg);
    }
    .af-mcp-raw code { color: #e6edf3; font-size: .82rem; font-family: 'JetBrains Mono', 'Fira Code', monospace; line-height: 1.7; }

    </style>

    @stack('head')

    @php
        $activeTheme = \App\Services\ThemeManager::active();
        $customCssPath = resource_path("views/theme/{$activeTheme}/custom.css");
    @endphp
    @if(file_exists($customCssPath))
        <style>
            {!! file_get_contents($customCssPath) !!}
        </style>
    @endif

    <style>
        /* ── Estilos de Layout Dinâmico AnimusFlow ── */
        :root {
            @php
                $maxWidthRaw = $theme->layout_config['max_width'] ?? '1120';
                $maxWidth = ($maxWidthRaw === 'full') ? '100%' : ($maxWidthRaw . 'px');
                $spacingRaw = $theme->layout_config['spacing'] ?? 'normal';
                $paddingY = ($spacingRaw === 'compact') ? '2.5rem' : (($spacingRaw === 'spacious') ? '7.5rem' : '5rem');
                
                // Color light tokens for companions
                $colors = $theme->colors ?? [];
                $light = $colors['light'] ?? [];
            @endphp
            --layout-max-width: {{ $maxWidth }};
            --section-padding-y: {{ $paddingY }};

            @foreach($light as $var => $value)
                @php $hx = ltrim(trim((string) $value), '#'); @endphp
                @if(preg_match('/^[0-9a-fA-F]{6}$/', $hx))
                    {{ $var }}-rgb: {{ hexdec(substr($hx, 0, 2)) }}, {{ hexdec(substr($hx, 2, 2)) }}, {{ hexdec(substr($hx, 4, 2)) }};
                @endif
            @endforeach
        }

        .layout-boxed {
            max-width: 1200px;
            margin: 0 auto;
            background: var(--color-background);
            box-shadow: 0 0 60px rgba(0,0,0,0.5);
            border-left: 1px solid var(--color-border);
            border-right: 1px solid var(--color-border);
            position: relative;
        }

        .layout-with-sidebar {
            display: flex;
            min-height: 100vh;
        }
        .layout-with-sidebar.pos-sidebar-left {
            flex-direction: row;
        }
        .layout-with-sidebar.pos-sidebar-right {
            flex-direction: row-reverse;
        }
        .layout-sidebar {
            width: 260px;
            flex-shrink: 0;
            background: var(--color-card);
            border-right: 1px solid var(--color-border);
            padding: 2rem 1.5rem;
            display: flex;
            flex-direction: column;
            gap: 2rem;
            z-index: 99;
        }
        .layout-with-sidebar.pos-sidebar-right .layout-sidebar {
            border-right: none;
            border-left: 1px solid var(--color-border);
        }
        .layout-main {
            flex: 1;
            min-width: 0;
        }
        .sidebar-widget h4 {
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--color-accent, var(--color-primary));
            margin-bottom: 0.75rem;
            font-family: var(--font-heading), monospace;
        }
        .sidebar-widget ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        .sidebar-widget a {
            color: var(--color-muted-foreground);
            text-decoration: none;
            font-size: 0.875rem;
            font-weight: 500;
            transition: color 0.2s;
        }
        .sidebar-widget a:hover {
            color: var(--color-foreground);
        }
        .sidebar-widget p {
            color: var(--color-muted-foreground);
            font-size: 0.8rem;
            margin: 0.25rem 0;
        }

        @media (max-width: 768px) {
            .layout-with-sidebar {
                flex-direction: column !important;
            }
            .layout-sidebar {
                width: 100% !important;
                border-right: none !important;
                border-left: none !important;
                border-bottom: 1px solid var(--color-border) !important;
            }
        }
    </style>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>

@if($hasMediaBg)
<div class="af-page-bg" aria-hidden="true">
    @if($contentBg === 'video')
        <video class="af-page-bg__vid" autoplay muted loop playsinline>
            <source src="{{ $bgMedia }}">
        </video>
    @else
        <div class="af-page-bg__img" style="background-image:url('{{ addslashes($bgMedia) }}')"></div>
    @endif
    <div class="af-page-bg__overlay" style="background:{{ $overlayColor }}"></div>
</div>
@endif

@php
    $navMenu      = $layout['header_menu']         ?? 'right';
    $navBg        = $layout['header_bg']           ?? 'glass';
    $navSticky    = $layout['header_sticky']       ?? true;
    $navCta       = $layout['header_cta_text']     ?? '';
    $navCtaUrl    = $layout['header_cta_url']      ?? '#';
    $navCta2      = $layout['header_cta2_text']    ?? '';        // item 5
    $navCta2Url   = $layout['header_cta2_url']     ?? '#';      // item 5
    $navCta2Style = $layout['header_cta2_style']   ?? 'outline'; // item 5
    $showToggle   = $layout['header_show_toggle']  ?? true;
    $siteLogo     = $site_logo      ?? '';
    $siteLogoDark = $site_logo_dark ?? '';                       // item 3
    $logoHeightPx = $layout['logo_height']         ?? '36';      // item 6
    $homepageUrl  = $site_homepage_url ?? '/';                   // item 10
    $currentPath  = rtrim(request()->getPathInfo(), '/');
    $navClass     = 'af-nav af-nav--menu-' . $navMenu
                  . ($navBg !== 'glass' ? ' af-nav--' . $navBg : '')
                  . (!$navSticky ? ' af-nav--relative' : '');
@endphp

<nav class="{{ $navClass }}">
    <div class="af-container" style="width:100%">
        <div class="af-nav__inner">

            {{-- Brand / Logo (items 3, 6, 10) --}}
            <a href="{{ $homepageUrl }}" class="af-nav__brand" data-tooltip="Página inicial">
                @if(!empty($siteLogo))
                    <img id="af-nav-logo"
                         src="{{ $siteLogo }}"
                         data-logo-light="{{ $siteLogo }}"
                         data-logo-dark="{{ !empty($siteLogoDark) ? $siteLogoDark : $siteLogo }}"
                         alt="{{ $site_name ?? 'AnimusFlow' }}"
                         class="af-nav__logo"
                         style="height:{{ $logoHeightPx }}px"
                         loading="eager">
                @else
                    {{ $site_name ?? 'AnimusFlow' }}
                @endif
            </a>

            {{-- Navigation links (item 7: dropdown support) --}}
            @if(!empty($nav_links))
            <div class="af-nav__links" id="nav-links">
                @foreach($nav_links as $link)
                    @php
                        $linkUrl  = $link['url'] ?? '#';
                        $children = $link['children'] ?? [];
                        $linkPath = rtrim(parse_url($linkUrl, PHP_URL_PATH) ?? '', '/');
                        $isActive = $linkPath !== '' && $linkPath !== '#' && $linkPath === $currentPath;
                    @endphp
                    @if(!empty($children))
                    <div class="af-nav__item">
                        <button type="button" class="af-nav__item--trigger" aria-haspopup="true" aria-expanded="false" data-tooltip="{{ $link['label'] }}">
                            {{ $link['label'] }}
                            <span class="af-nav__caret" aria-hidden="true"></span>
                        </button>
                        <div class="af-nav__dropdown" role="menu">
                            @foreach($children as $child)
                            <a href="{{ $child['url'] ?? '#' }}"
                               target="{{ $child['target'] ?? '_self' }}"
                               class="af-nav__dropdown-link"
                               role="menuitem"
                               data-tooltip="{{ $child['label'] }}">{{ $child['label'] }}</a>
                            @endforeach
                        </div>
                    </div>
                    @else
                    <a href="{{ $linkUrl }}"
                       target="{{ $link['target'] ?? '_self' }}"
                       class="af-nav__link{{ $isActive ? ' af-nav__link--active' : '' }}"
                       data-tooltip="{{ $link['label'] }}">{{ $link['label'] }}</a>
                    @endif
                @endforeach
            </div>
            @endif

            {{-- Right side: dual CTAs (item 5) + theme toggle + hamburger --}}
            @if($navCta2 || $navCta || $showToggle || !empty($nav_links))
            <div class="af-nav__right">
                @if($navCta2)
                    <a href="{{ $navCta2Url }}"
                       class="af-btn af-btn--{{ $navCta2Style }}"
                       data-tooltip="{{ $navCta2 }}"
                       style="padding:.4rem 1.1rem;font-size:.82rem;border-radius:var(--radius)">{{ $navCta2 }}</a>
                @endif
                @if($navCta)
                    <a href="{{ $navCtaUrl }}"
                       class="af-btn af-btn--primary"
                       data-tooltip="{{ $navCta }}"
                       style="padding:.4rem 1.1rem;font-size:.82rem;border-radius:var(--radius)">{{ $navCta }}</a>
                @endif
                @if($showToggle)
                <button class="af-theme-toggle" id="theme-toggle" aria-label="Alternar tema" data-tooltip="Modo escuro">
                    <span id="theme-icon">🌙</span>
                </button>
                @endif
                @if(!empty($nav_links))
                <button class="af-nav__hamburger" id="nav-hamburger" aria-label="Menu de navegação" aria-expanded="false" data-tooltip="Menu">
                    <span></span><span></span><span></span>
                </button>
                @endif
            </div>
            @endif
        </div>
    </div>
</nav>

{{-- Item 4 — mobile backdrop overlay --}}
<div class="af-nav__backdrop" id="nav-backdrop" aria-hidden="true"></div>

@php
    $layoutType = $theme->layout_config['layout_type'] ?? 'full-width';
@endphp
<div class="theme-layout-wrapper @if($layoutType === 'boxed') layout-boxed @elseif(str_contains($layoutType, 'sidebar')) layout-with-sidebar pos-{{ $layoutType }} @endif">
    @if(str_contains($layoutType, 'sidebar'))
        <aside class="layout-sidebar">
            <div class="sidebar-widget">
                <h4>Navegação</h4>
                <ul>
                    @foreach($nav_links as $link)
                        <li><a href="{{ $link['url'] ?? '#' }}">{{ $link['label'] ?? '' }}</a></li>
                    @endforeach
                </ul>
            </div>
            <div class="sidebar-widget">
                <h4>Telemetria</h4>
                <p>Status: Operacional</p>
                <p>Conexão: Segura</p>
                <p>Sede: Luanda, AO</p>
            </div>
        </aside>
        <main class="layout-main">
    @endif

    @yield('content')

    @if(str_contains($layoutType, 'sidebar'))
        </main>
    @endif
</div>

<footer class="af-footer af-footer--{{ $layout['footer_bg'] ?? 'default' }}">
    <div class="af-container">

        @if(($layout['footer_mode'] ?? 'simple') === 'columns' && !empty($layout['footer_columns']))
        {{-- ══ COLUMN MODE ══════════════════════════════════════════ --}}
        @php $colCount = count($layout['footer_columns']); @endphp
        <div class="af-footer-grid af-footer-grid--{{ $colCount }}">
            @foreach($layout['footer_columns'] as $col)
            @php $colType = $col['type'] ?? 'text'; $colData = $col['data'] ?? []; @endphp
            <div class="af-footer-col">

                {{-- Section label (not shown for brand type) --}}
                @if(!empty($col['title']) && $colType !== 'brand')
                    <div class="af-footer-col__label">{{ $col['title'] }}</div>
                @endif

                @switch($colType)

                    @case('brand')
                        @if(!empty($layout['footer_show_logo']) && !empty($site_logo))
                            <img src="{{ $site_logo }}" alt="{{ $site_name ?? '' }}" class="af-footer__logo" style="margin-bottom:.75rem">
                        @else
                            <div class="af-footer__brand" style="font-size:1rem;margin-bottom:.6rem">{{ $site_name ?? 'AnimusFlow' }}</div>
                        @endif
                        @if(!empty($colData['tagline']))
                            <p class="af-footer-text" style="margin:0">{{ $colData['tagline'] }}</p>
                        @endif
                    @break

                    @case('links')
                        @if(!empty($colData['links']))
                        <nav class="af-footer-col__links" aria-label="{{ $col['title'] ?? 'Links' }}">
                            @foreach($colData['links'] as $lnk)
                                <a href="{{ htmlspecialchars($lnk['url'] ?? '#', ENT_QUOTES, 'UTF-8') }}">{{ $lnk['label'] ?? '' }}</a>
                            @endforeach
                        </nav>
                        @endif
                    @break

                    @case('social')
                        @php
                            $colSocials = array_filter([
                                'twitter'   => $colData['twitter']   ?? '',
                                'linkedin'  => $colData['linkedin']  ?? '',
                                'github'    => $colData['github']    ?? '',
                                'instagram' => $colData['instagram'] ?? '',
                                'youtube'   => $colData['youtube']   ?? '',
                            ], fn($v) => trim($v) !== '');
                        @endphp
                        @if(!empty($colSocials))
                        <div class="af-footer-social-col">
                            @foreach($colSocials as $net => $sUrl)
                            <a href="{{ htmlspecialchars($sUrl, ENT_QUOTES, 'UTF-8') }}" target="_blank" rel="noopener noreferrer" class="af-footer__social-icon" aria-label="{{ ucfirst($net) }}">
                                @if($net === 'twitter')<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.748l7.73-8.835L1.254 2.25H8.08l4.262 5.639 5.902-5.639zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                                @elseif($net === 'linkedin')<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                                @elseif($net === 'github')<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
                                @elseif($net === 'instagram')<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
                                @elseif($net === 'youtube')<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>@endif
                            </a>
                            @endforeach
                        </div>
                        @endif
                    @break

                    @case('contact')
                        <div class="af-footer-contact">
                            @if(!empty($colData['address']))<p style="margin:0 0 .3rem;white-space:pre-line">{{ $colData['address'] }}</p>@endif
                            @if(!empty($colData['phone']))<a href="tel:{{ preg_replace('/[\s\-()]/', '', $colData['phone']) }}">{{ $colData['phone'] }}</a>@endif
                            @if(!empty($colData['email']))<a href="mailto:{{ $colData['email'] }}">{{ $colData['email'] }}</a>@endif
                        </div>
                    @break

                    @case('map')
                        @if(!empty($colData['embed_url']))
                        <div class="af-footer-map">
                            <iframe src="{{ htmlspecialchars($colData['embed_url'], ENT_QUOTES, 'UTF-8') }}"
                                    loading="lazy" allowfullscreen
                                    referrerpolicy="no-referrer-when-downgrade"
                                    title="Mapa"></iframe>
                        </div>
                        @endif
                    @break

                    @case('text')
                    @default
                        @if(!empty($colData['content']))
                        <div class="af-footer-text">{!! nl2br(e($colData['content'])) !!}</div>
                        @endif
                    @break

                @endswitch
            </div>
            @endforeach
        </div>

        {{-- Bottom bar: copyright --}}
        <div class="af-footer-bottom">
            <span class="af-footer__brand">{{ $site_name ?? 'AnimusFlow' }}</span>
            <span class="af-footer__copy">
                @if(!empty($layout['footer_copyright']))
                    {!! e($layout['footer_copyright']) !!}
                @else
                    &copy; {{ date('Y') }} {{ $site_name ?? 'AnimusFlow' }}
                    @if($layout['footer_show_brand'] ?? true) &mdash; Built with AnimusFlow @endif
                @endif
            </span>
        </div>

        @else
        {{-- ══ SIMPLE MODE ══════════════════════════════════════════ --}}
        <div class="af-footer__inner">

            <div>
                @if(!empty($layout['footer_show_logo']) && !empty($site_logo))
                    <img src="{{ $site_logo }}" alt="{{ $site_name ?? '' }}" class="af-footer__logo">
                @else
                    <span class="af-footer__brand">{{ $site_name ?? 'AnimusFlow' }}</span>
                @endif
            </div>

            @if(!empty($layout['footer_links']))
            <nav class="af-footer__links" aria-label="Footer navigation">
                @foreach($layout['footer_links'] as $link)
                    <a href="{{ htmlspecialchars($link['url'] ?? '#', ENT_QUOTES, 'UTF-8') }}">{{ $link['label'] ?? '' }}</a>
                @endforeach
            </nav>
            @endif

            <div class="af-footer__right">
                @php
                    $socialItems = array_filter([
                        'twitter'   => $layout['footer_social_twitter']   ?? '',
                        'linkedin'  => $layout['footer_social_linkedin']  ?? '',
                        'github'    => $layout['footer_social_github']    ?? '',
                        'instagram' => $layout['footer_social_instagram'] ?? '',
                        'youtube'   => $layout['footer_social_youtube']   ?? '',
                    ], fn($v) => trim($v) !== '');
                @endphp
                @if(!empty($socialItems))
                <div class="af-footer__social">
                    @foreach($socialItems as $network => $socialUrl)
                    <a href="{{ htmlspecialchars($socialUrl, ENT_QUOTES, 'UTF-8') }}" target="_blank" rel="noopener noreferrer" aria-label="{{ ucfirst($network) }}">
                        @if($network === 'twitter')<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.748l7.73-8.835L1.254 2.25H8.08l4.262 5.639 5.902-5.639zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                        @elseif($network === 'linkedin')<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                        @elseif($network === 'github')<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
                        @elseif($network === 'instagram')<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
                        @elseif($network === 'youtube')<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>@endif
                    </a>
                    @endforeach
                </div>
                @endif
                <span class="af-footer__copy">
                    @if(!empty($layout['footer_copyright']))
                        {!! e($layout['footer_copyright']) !!}
                    @else
                        &copy; {{ date('Y') }} {{ $site_name ?? 'AnimusFlow' }}
                        @if($layout['footer_show_brand'] ?? true) &mdash; Built with AnimusFlow @endif
                    @endif
                </span>
            </div>
        </div>
        @endif

    </div>
</footer>

@if(!empty($preview))
    <div class="af-preview-bar">⚡ Preview mode — page not published</div>
@endif

@if(!empty($plugin_html))
    {!! $plugin_html !!}
@endif

@stack('scripts')

{{-- Theme toggle + item 3 (logo dark/light swap) --}}
@if($showToggle)
<script>
(function () {
    var root = document.documentElement;
    var btn  = document.getElementById('theme-toggle');
    var icon = document.getElementById('theme-icon');
    var logo = document.getElementById('af-nav-logo');

    function applyTheme(t) {
        root.setAttribute('data-theme', t);
        icon.textContent = t === 'dark' ? '☀️' : '🌙';
        // Update tooltip label to reflect the action (toggle to opposite)
        if (btn) btn.setAttribute('data-tooltip', t === 'dark' ? 'Modo claro' : 'Modo escuro');
        try { localStorage.setItem('af_scheme', t); } catch(e){}
        // Item 3 — swap logo src for dark/light variant
        if (logo) {
            logo.src = (t === 'dark')
                ? (logo.dataset.logoDark  || logo.src)
                : (logo.dataset.logoLight || logo.src);
        }
    }

    applyTheme(root.getAttribute('data-theme') || 'light');
    btn.addEventListener('click', function () {
        applyTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
    });
})();
</script>
@else
{{-- No toggle button — still apply logo variant based on current theme --}}
<script>
(function(){
    var logo = document.getElementById('af-nav-logo');
    if (!logo) return;
    var t = document.documentElement.getAttribute('data-theme') || 'light';
    logo.src = (t === 'dark')
        ? (logo.dataset.logoDark  || logo.src)
        : (logo.dataset.logoLight || logo.src);
})();
</script>
@endif

{{-- Scroll animations --}}
@if($contentAnims)
<script>
(function(){
    if (!window.IntersectionObserver) {
        document.querySelectorAll('.af-block-wrapper').forEach(function(el){ el.classList.add('af-in'); });
        return;
    }
    var io = new IntersectionObserver(function(entries){
        entries.forEach(function(e){
            if (e.isIntersecting) { e.target.classList.add('af-in'); io.unobserve(e.target); }
        });
    }, { threshold: 0.06 });
    document.querySelectorAll('.af-block-wrapper').forEach(function(el){ io.observe(el); });
})();
</script>
@endif

{{-- Overlay editor --}}
<script>
(function(){
    var wants = new URLSearchParams(location.search).has('edit');
    var was   = localStorage.getItem('af_editor_active') === '1';
    if (wants || was) {
        var s = document.createElement('script');
        s.src = '{{ asset('editor/overlay.js') }}';
        document.head.appendChild(s);
    }
})();
</script>

{{-- Item 4 — hamburger + backdrop + item 7 mobile dropdowns --}}
<script>
(function(){
    var btn      = document.getElementById('nav-hamburger');
    var links    = document.getElementById('nav-links');
    var backdrop = document.getElementById('nav-backdrop');
    if (!btn || !links) return;

    function openMenu() {
        links.classList.add('is-open');
        btn.classList.add('is-open');
        btn.setAttribute('aria-expanded', 'true');
        if (backdrop) backdrop.classList.add('is-open');
        document.body.style.overflow = 'hidden';
    }
    function closeMenu() {
        links.classList.remove('is-open');
        btn.classList.remove('is-open');
        btn.setAttribute('aria-expanded', 'false');
        if (backdrop) backdrop.classList.remove('is-open');
        document.body.style.overflow = '';
    }

    btn.addEventListener('click', function(e) {
        e.stopPropagation();
        links.classList.contains('is-open') ? closeMenu() : openMenu();
    });
    if (backdrop) backdrop.addEventListener('click', closeMenu);
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && links.classList.contains('is-open')) closeMenu();
    });

    // Item 7 — mobile accordion dropdowns
    links.querySelectorAll('.af-nav__item--trigger').forEach(function(trigger) {
        trigger.addEventListener('click', function(e) {
            e.stopPropagation();
            var item    = trigger.closest('.af-nav__item');
            var wasOpen = item.classList.contains('is-open');
            links.querySelectorAll('.af-nav__item.is-open').forEach(function(i) {
                i.classList.remove('is-open');
                i.querySelector('.af-nav__item--trigger').setAttribute('aria-expanded', 'false');
            });
            if (!wasOpen) {
                item.classList.add('is-open');
                trigger.setAttribute('aria-expanded', 'true');
            }
        });
    });
})();
</script>

{{-- Items 1 + transparent-scroll: compact height on scroll --}}
<script>
(function(){
    var nav = document.querySelector('.af-nav');
    if (!nav) return;
    var isTransparent = nav.classList.contains('af-nav--transparent');

    function check() {
        var scrolled = window.scrollY > 60;
        nav.classList.toggle('af-nav--compact', scrolled);
        // Update --nav-h so mobile menu top tracks the actual nav height
        document.documentElement.style.setProperty('--nav-h', scrolled ? '52px' : '68px');
        if (isTransparent) nav.classList.toggle('af-nav--scrolled', scrolled);
    }

    window.addEventListener('scroll', check, { passive: true });
    check();
})();
</script>

{{-- AnimusFlow — visitor analytics tracker --}}
@unless($preview ?? false)
<script>
(function(){
    // Read or create a persistent visitor ID (1-year cookie)
    var vid = (document.cookie.match(/af_vid=([^;]+)/) || [])[1];
    if (!vid) {
        vid = Math.random().toString(36).slice(2) + Date.now().toString(36);
        document.cookie = 'af_vid=' + vid + '; path=/; max-age=31536000; SameSite=Lax';
    }
    var dev = /Mobi|Android/i.test(navigator.userAgent) ? 'mobile'
            : /iPad|Tablet/i.test(navigator.userAgent) ? 'tablet' : 'desktop';
    fetch('/api/v1/events', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ event: 'pageview', visitor_id: vid, page_id: {{ $page->id ?? 0 }}, device: dev }),
        keepalive: true
    }).catch(function(){});
})();
</script>
@endunless
    @php
        $activeTheme = \App\Services\ThemeManager::active();
        $customJsPath = resource_path("views/theme/{$activeTheme}/custom.js");
    @endphp
    @if(file_exists($customJsPath))
        <script>
            {!! file_get_contents($customJsPath) !!}
        </script>
    @endif
</body>
</html>
